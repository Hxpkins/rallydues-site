import { createClient } from "@supabase/supabase-js"

// Check if Supabase environment variables are available
export const isSupabaseConfigured =
  typeof process.env.SUPABASE_URL === "string" &&
  process.env.SUPABASE_URL.length > 0 &&
  typeof process.env.SUPABASE_SERVICE_ROLE_KEY === "string" &&
  process.env.SUPABASE_SERVICE_ROLE_KEY.length > 0

// Create admin client with service role key for server-side operations
export const createAdminClient = () => {
  if (!isSupabaseConfigured) {
    throw new Error("Supabase environment variables are not configured")
  }

  return createClient(process.env.SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  })
}

// Helper function to find user by PayCode and last name
export async function findUserByPayCode(paycode: string, lastName: string) {
  const supabase = createAdminClient()

  const { data, error } = await supabase
    .from("users")
    .select(`
      *,
      organization:organizations(*)
    `)
    .eq("paycode", paycode.toUpperCase())
    .ilike("last_name", lastName)
    .single()

  if (error) {
    console.error("Error finding user by PayCode:", error)
    return null
  }

  return data
}

// Helper function to get member dues for Quick Pay
export async function getMemberDuesForQuickPay(userId: string) {
  const supabase = createAdminClient()

  const { data, error } = await supabase
    .from("member_dues")
    .select(`
      *,
      dues_cycle:dues_cycles(*),
      user:users(first_name, last_name, organization_id)
    `)
    .eq("user_id", userId)
    .in("status", ["pending", "partial", "overdue"])
    .order("created_at", { ascending: true })

  if (error) {
    console.error("Error getting member dues:", error)
    return []
  }

  return data || []
}

// Helper function to get fee settings for organization
export async function getFeeSettings(organizationId: string) {
  const supabase = createAdminClient()

  const { data, error } = await supabase.from("fee_settings").select("*").eq("organization_id", organizationId).single()

  if (error) {
    console.error("Error getting fee settings:", error)
    // Return default fee settings if none exist
    return {
      stripe_fee_percentage: 0.029,
      stripe_fee_fixed: 0.3,
      platform_fee_percentage: 0.01,
      platform_fee_fixed: 0.0,
      pass_fees_to_payer: true,
    }
  }

  return data
}

// Helper function to calculate total amount with fees
export function calculateTotalWithFees(
  amount: number,
  feeSettings: any,
): { subtotal: number; processingFee: number; total: number } {
  const subtotal = amount

  if (!feeSettings.pass_fees_to_payer) {
    return {
      subtotal,
      processingFee: 0,
      total: subtotal,
    }
  }

  // Calculate Stripe + platform fees
  const stripeFee = subtotal * feeSettings.stripe_fee_percentage + feeSettings.stripe_fee_fixed
  const platformFee = subtotal * feeSettings.platform_fee_percentage + feeSettings.platform_fee_fixed
  const processingFee = stripeFee + platformFee

  return {
    subtotal,
    processingFee: Math.round(processingFee * 100) / 100, // Round to 2 decimal places
    total: subtotal + processingFee,
  }
}
