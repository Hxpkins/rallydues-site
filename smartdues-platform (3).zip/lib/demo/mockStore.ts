"use client"

import { create } from "zustand"
import type {
  CollectionsPoint,
  AgingBucket,
  ForecastPoint,
  ReminderPoint,
  CohortCell,
  OverdueRow,
  UpcomingRow,
  PaymentRow,
  PaymentMethod,
} from "./types"

type DemoState = {
  // charts
  collections60d: CollectionsPoint[]
  aging: AgingBucket[]
  forecast12w: ForecastPoint[]
  reminders12w: ReminderPoint[]
  cohortGrid: CohortCell[]
  // tables
  topOverdue: OverdueRow[]
  upcoming7d: UpcomingRow[]
  recentPayments: PaymentRow[]
  // actions (for table interactions)
  markUpcomingPaid: (id: string) => void
  sendReminder: (ids: string[]) => void
}

const SEED = 42

// small seeded RNG so data is deterministic
function rng(seed = SEED) {
  let s = seed >>> 0
  return () => (s = (s * 1664525 + 1013904223) >>> 0) / 2 ** 32
}
const r = rng()

// helpers
const iso = (d: Date) => d.toISOString().slice(0, 10)
const clamp = (n: number, min: number, max: number) => Math.max(min, Math.min(max, n))

// generate non-empty arrays
function genCollections60d(): CollectionsPoint[] {
  const out: CollectionsPoint[] = []
  const today = new Date()
  let collected = 0
  const dailyTargetBase = 12000 / 60 // tweak if needed
  for (let i = 59; i >= 0; i--) {
    const d = new Date(today)
    d.setDate(d.getDate() - i)
    const push = 100 + Math.floor(r() * 400)
    collected += push
    const target = Math.round((60 - i) * dailyTargetBase * (0.95 + r() * 0.1))
    out.push({ date: iso(d), collected, target })
  }
  return out
}

function genAging(): AgingBucket[] {
  // ensure all buckets have at least 3 members and > 0 amount
  const labels: Record<string, string> = {
    "0_7": "0–7 days",
    "8_14": "8–14 days",
    "15_30": "15–30 days",
    "30_plus": "30+ days",
  }
  const keys = ["0_7", "8_14", "15_30", "30_plus"] as const
  const amounts = keys.map(() => 2000 + Math.round(r() * 8000))
  const members = keys.map(() => 3 + Math.floor(r() * 25))
  return keys.map((k, i) => ({
    key: k,
    label: labels[k],
    amount: amounts[i],
    memberCount: members[i],
  }))
}

function genForecast12w(): ForecastPoint[] {
  const out: ForecastPoint[] = []
  const start = new Date()
  for (let w = 0; w < 12; w++) {
    const d = new Date(start)
    d.setDate(d.getDate() + w * 7)
    const expected = 2000 + Math.round(r() * 7000)
    out.push({ weekStart: iso(d), expected })
  }
  return out
}

function genReminders12w(): ReminderPoint[] {
  const out: ReminderPoint[] = []
  const start = new Date()
  for (let w = 0; w < 12; w++) {
    const d = new Date(start)
    d.setDate(d.getDate() - (11 - w) * 7)
    out.push({ weekStart: iso(d), respondedPct: Math.round(35 + r() * 20) })
  }
  return out
}

function genCohortGrid(): CohortCell[] {
  const cohorts = ["Fall 2023", "Spring 2024", "Fall 2024", "Spring 2025"]
  const cells: CohortCell[] = []
  cohorts.forEach((c) => {
    for (let w = 0; w <= 8; w++) {
      cells.push({ cohort: c, week: w, pct: Math.round(35 + r() * 55) })
    }
  })
  return cells
}

function pickMethod(): PaymentMethod {
  return r() < 0.3 ? "ach" : "card" // ~30% ACH
}

function name(): string {
  const first = ["Parker", "Avery", "Jordan", "Taylor", "Riley", "Morgan", "Casey", "Quinn", "Rowan", "Hayden"]
  const last = ["Baker", "Cruz", "Nguyen", "Kim", "Lopez", "Patel", "Green", "Price", "Kelly", "Ross"]
  return `${first[Math.floor(r() * first.length)]} ${last[Math.floor(r() * last.length)]}`
}

function genPayments(n = 14): PaymentRow[] {
  const out: PaymentRow[] = []
  const today = new Date()
  for (let i = 0; i < n; i++) {
    const d = new Date(today)
    d.setDate(d.getDate() - Math.floor(r() * 30))
    out.push({
      id: `p_${i}`,
      member: name(),
      paidAt: iso(d),
      amount: 75 + Math.round(r() * 525),
      method: pickMethod(),
    })
  }
  return out.sort((a, b) => b.paidAt.localeCompare(a.paidAt))
}

function genUpcoming(n = 12): UpcomingRow[] {
  const out: UpcomingRow[] = []
  const today = new Date()
  for (let i = 0; i < n; i++) {
    const d = new Date(today)
    d.setDate(d.getDate() + 1 + Math.floor(r() * 6)) // next 7 days
    out.push({
      id: `u_${i}`,
      member: name(),
      installmentNo: 1 + Math.floor(r() * 6),
      dueDate: iso(d),
      amount: 100 + Math.round(r() * 400),
      method: pickMethod(),
    })
  }
  return out.sort((a, b) => a.dueDate.localeCompare(b.dueDate))
}

function genOverdue(n = 10): OverdueRow[] {
  const out: OverdueRow[] = []
  for (let i = 0; i < n; i++) {
    out.push({
      id: `o_${i}`,
      member: name(),
      amount: 150 + Math.round(r() * 600),
      daysLate: 1 + Math.floor(r() * 40),
      onPlan: r() < 0.35,
      email: "member@example.com",
    })
  }
  // sort by days late desc
  return out.sort((a, b) => b.daysLate - a.daysLate)
}

export const useDemoStore = create<DemoState>((set, get) => ({
  collections60d: genCollections60d(),
  aging: genAging(),
  forecast12w: genForecast12w(),
  reminders12w: genReminders12w(),
  cohortGrid: genCohortGrid(),
  topOverdue: genOverdue(),
  upcoming7d: genUpcoming(),
  recentPayments: genPayments(),
  markUpcomingPaid: (id) => {
    const { upcoming7d, recentPayments } = get()
    const row = upcoming7d.find((x) => x.id === id)
    if (!row) return
    set({
      upcoming7d: upcoming7d.filter((x) => x.id !== id),
      recentPayments: [
        { id: `p_${Date.now()}`, member: row.member, paidAt: iso(new Date()), amount: row.amount, method: row.method },
        ...recentPayments,
      ],
    })
  },
  sendReminder: () => {
    /* no-op + toast handled in UI */
  },
}))
