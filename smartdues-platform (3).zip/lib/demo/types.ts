export type PaymentMethod = "card" | "ach"

export type CollectionsPoint = {
  date: string // ISO yyyy-mm-dd
  collected: number // cumulative dollars
  target: number // cumulative dollars
}

export type AgingBucketKey = "0_7" | "8_14" | "15_30" | "30_plus"

export type AgingBucket = {
  key: AgingBucketKey
  label: string
  amount: number // outstanding dollars
  memberCount: number
}

export type ForecastPoint = {
  weekStart: string // ISO
  expected: number
}

export type ReminderPoint = {
  weekStart: string // ISO
  respondedPct: number // 0-100
}

export type CohortCell = {
  cohort: string // e.g., 'Spring 2024'
  week: number // 0..8
  pct: number // 0-100
}

export type OverdueRow = {
  id: string
  member: string
  amount: number
  daysLate: number
  onPlan: boolean
  email: string
}

export type UpcomingRow = {
  id: string
  member: string
  installmentNo: number
  dueDate: string // ISO
  amount: number
  method: PaymentMethod
}

export type PaymentRow = {
  id: string
  member: string
  paidAt: string // ISO
  amount: number
  method: PaymentMethod
}
