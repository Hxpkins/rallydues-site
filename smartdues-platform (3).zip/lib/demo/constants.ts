export const FEE_COPY = "Card includes 3.1% surcharge • ACH has no fee."

export const METHOD_LABELS = {
  card: "Card (includes fee)",
  ach: "ACH (no fee)",
}

export const METHOD_COLORS = {
  card: "#2563eb", // blue
  ach: "#10b981", // green
}

export type PaymentMethod = "card" | "ach"
