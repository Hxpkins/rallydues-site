// CSV export helpers for treasurer demo

export function arrayToCSV<T extends Record<string, any>>(
  data: T[],
  headers: { key: keyof T; label: string }[],
): string {
  const csvHeaders = headers.map((h) => h.label).join(",")
  const csvRows = data.map((row) =>
    headers
      .map((h) => {
        const value = row[h.key]
        // Escape commas and quotes in CSV values
        if (typeof value === "string" && (value.includes(",") || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`
        }
        return value?.toString() || ""
      })
      .join(","),
  )

  return [csvHeaders, ...csvRows].join("\n")
}

export function downloadCSV(content: string, filename: string) {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" })
  const link = document.createElement("a")

  if (link.download !== undefined) {
    const url = URL.createObjectURL(blob)
    link.setAttribute("href", url)
    link.setAttribute("download", filename)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }
}

export function exportOverdueCSV(data: any[], options: { term?: string } = {}) {
  const csvData = data.map((item) => ({
    member: item.member || "Unknown Member",
    email: item.email || "member@example.com",
    amount: `$${item.amount?.toFixed(2) || "0.00"}`,
    daysLate: item.daysLate || 0,
    onPlan: item.onPlan ? "Yes" : "No",
  }))

  const headers = [
    { key: "member" as const, label: "Member" },
    { key: "email" as const, label: "Email" },
    { key: "amount" as const, label: "Outstanding Amount" },
    { key: "daysLate" as const, label: "Days Late" },
    { key: "onPlan" as const, label: "Payment Plan" },
  ]

  const csv = arrayToCSV(csvData, headers)
  const term = options.term ? `-${options.term.toLowerCase().replace(/\s+/g, "-")}` : ""
  downloadCSV(csv, `overdue-members${term}-${new Date().toISOString().split("T")[0]}.csv`)
}

export function exportUpcomingCSV(data: any[], options: { term?: string } = {}) {
  const csvData = data.map((item) => ({
    member: item.member || "Unknown Member",
    installmentNo: item.installmentNo || 1,
    dueDate: item.dueDate || new Date().toISOString().split("T")[0],
    amount: `$${item.amount?.toFixed(2) || "0.00"}`,
    method: item.method?.toUpperCase() || "CARD",
  }))

  const headers = [
    { key: "member" as const, label: "Member" },
    { key: "installmentNo" as const, label: "Installment #" },
    { key: "dueDate" as const, label: "Due Date" },
    { key: "amount" as const, label: "Amount" },
    { key: "method" as const, label: "Method" },
  ]

  const csv = arrayToCSV(csvData, headers)
  const term = options.term ? `-${options.term.toLowerCase().replace(/\s+/g, "-")}` : ""
  downloadCSV(csv, `upcoming-installments${term}-${new Date().toISOString().split("T")[0]}.csv`)
}

export function exportPaymentsCSV(data: any[], options: { term?: string } = {}) {
  const csvData = data.map((item) => ({
    member: item.member || "Unknown Member",
    paidAt: item.paidAt || new Date().toISOString().split("T")[0],
    amount: `$${item.amount?.toFixed(2) || "0.00"}`,
    method: item.method?.toUpperCase() || "CARD",
  }))

  const headers = [
    { key: "member" as const, label: "Member" },
    { key: "paidAt" as const, label: "Payment Date" },
    { key: "amount" as const, label: "Amount" },
    { key: "method" as const, label: "Method" },
  ]

  const csv = arrayToCSV(csvData, headers)
  const term = options.term ? `-${options.term.toLowerCase().replace(/\s+/g, "-")}` : ""
  downloadCSV(csv, `recent-payments${term}-${new Date().toISOString().split("T")[0]}.csv`)
}
