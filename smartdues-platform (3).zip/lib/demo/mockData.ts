// Mock data generation with deterministic seeded RNG for treasurer demo
// Ensures consistent data across page refreshes

class SeededRandom {
  private seed: number

  constructor(seed: number) {
    this.seed = seed
  }

  next(): number {
    this.seed = (this.seed * 9301 + 49297) % 233280
    return this.seed / 233280
  }

  nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min
  }

  nextFloat(min: number, max: number): number {
    return this.next() * (max - min) + min
  }

  choice<T>(array: T[]): T {
    return array[Math.floor(this.next() * array.length)]
  }
}

const SMARTDUES_DEMO_SEED = 42

export interface Member {
  id: string
  firstName: string
  lastName: string
  pledgeClass: string
  email: string
  paycode: string
}

export interface DuesCycle {
  id: string
  name: string
  dueDate: string
  goal: number
  amountPerMember: number
  lateFee: number
  launchDate: string
}

export interface Payment {
  id: string
  memberId: string
  date: string
  amount: number
  method: "card" | "ach"
  succeeded: boolean
  processingFee: number
}

export interface PaymentPlan {
  memberId: string
  schedule: Array<{
    date: string
    amount: number
    completed: boolean
  }>
}

export interface Reminder {
  date: string
  type: "upcoming" | "overdue1" | "overdue2"
  count: number
  responseRate: number
}

export interface DemoData {
  members: Member[]
  duesCycle: DuesCycle
  payments: Payment[]
  plans: PaymentPlan[]
  reminders: Reminder[]
}

const firstNames = [
  "Alex",
  "Blake",
  "Cameron",
  "Drew",
  "Emerson",
  "Finley",
  "Gray",
  "Harper",
  "Indigo",
  "Jordan",
  "Kai",
  "Logan",
  "Morgan",
  "Noah",
  "Oakley",
  "Parker",
  "Quinn",
  "River",
  "Sage",
  "Taylor",
  "Vale",
  "Winter",
  "Xander",
  "Yarrow",
  "Zion",
  "Avery",
  "Bailey",
  "Casey",
  "Dakota",
  "Ellis",
  "Frankie",
]

const lastNames = [
  "Anderson",
  "Brown",
  "Chen",
  "Davis",
  "Evans",
  "Foster",
  "Garcia",
  "Harris",
  "Johnson",
  "Kim",
  "Lee",
  "Martinez",
  "Nelson",
  "O'Connor",
  "Patel",
  "Quinn",
  "Rodriguez",
  "Smith",
  "Thompson",
  "Underwood",
  "Valdez",
  "Williams",
  "Young",
  "Zhang",
  "Adams",
  "Baker",
  "Clark",
  "Diaz",
  "Edwards",
  "Fisher",
  "Green",
]

const pledgeClasses = [
  "Spring 2022",
  "Fall 2022",
  "Spring 2023",
  "Fall 2023",
  "Spring 2024",
  "Fall 2024",
  "Spring 2025",
]

export function generateDemoData(): DemoData {
  const rng = new SeededRandom(SMARTDUES_DEMO_SEED)

  // Generate 120 members
  const members: Member[] = []
  for (let i = 0; i < 120; i++) {
    const firstName = rng.choice(firstNames)
    const lastName = rng.choice(lastNames)
    const pledgeClass = rng.choice(pledgeClasses)

    members.push({
      id: `member-${i + 1}`,
      firstName,
      lastName,
      pledgeClass,
      email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@university.edu`,
      paycode: Math.random().toString(36).substring(2, 12).toUpperCase(),
    })
  }

  // Current dues cycle (due ~30 days ago)
  const dueDate = new Date()
  dueDate.setDate(dueDate.getDate() - 30)

  const duesCycle: DuesCycle = {
    id: "fall-2025",
    name: "Fall 2025",
    dueDate: dueDate.toISOString().split("T")[0],
    goal: 60000, // $500 * 120 members
    amountPerMember: 500,
    lateFee: 25,
    launchDate: new Date(dueDate.getTime() - 60 * 24 * 60 * 60 * 1000).toISOString().split("T")[0],
  }

  // Generate payments over last 120 days with aging distribution
  const payments: Payment[] = []
  const today = new Date()

  // Ensure aging buckets have at least 3 members each
  const agingBuckets = {
    "0-7": { members: [], count: 0 },
    "8-14": { members: [], count: 0 },
    "15-30": { members: [], count: 0 },
    "30+": { members: [], count: 0 },
  }

  // Distribute members across aging buckets
  const shuffledMembers = [...members].sort(() => rng.next() - 0.5)
  shuffledMembers.forEach((member, index) => {
    const bucketIndex = index % 4
    const bucketKeys = Object.keys(agingBuckets) as Array<keyof typeof agingBuckets>
    const bucket = bucketKeys[bucketIndex]
    agingBuckets[bucket].members.push(member)
  })

  // Generate payments ensuring proper aging distribution
  for (let i = 0; i < 180; i++) {
    const paymentDate = new Date(today)
    paymentDate.setDate(paymentDate.getDate() - rng.nextInt(0, 120))

    const member = rng.choice(members)
    const method = rng.next() < 0.7 ? "card" : "ach" // 70% card, 30% ACH
    const amount = rng.nextInt(75, 600)
    const succeeded = rng.next() > 0.05 // 95% success rate

    let processingFee = 0
    if (succeeded && method === "card") {
      processingFee = Math.round(amount * 0.031 * 100) / 100
    }

    payments.push({
      id: `payment-${i + 1}`,
      memberId: member.id,
      date: paymentDate.toISOString().split("T")[0],
      amount,
      method,
      succeeded,
      processingFee,
    })
  }

  // Generate payment plans for ~25% of members
  const plans: PaymentPlan[] = []
  const planMembers = members.slice(0, Math.floor(members.length * 0.25))

  planMembers.forEach((member) => {
    const installments = rng.nextInt(2, 4)
    const baseAmount = Math.floor(duesCycle.amountPerMember / installments)
    const schedule = []

    for (let i = 0; i < installments; i++) {
      const installmentDate = new Date(duesCycle.launchDate)
      installmentDate.setDate(installmentDate.getDate() + i * 14) // Every 2 weeks

      const amount = i === installments - 1 ? duesCycle.amountPerMember - baseAmount * (installments - 1) : baseAmount

      const completed = installmentDate < today && rng.next() > 0.2

      schedule.push({
        date: installmentDate.toISOString().split("T")[0],
        amount,
        completed,
      })
    }

    plans.push({
      memberId: member.id,
      schedule,
    })
  })

  // Generate reminder history with response rates
  const reminders: Reminder[] = [
    { date: "2025-09-15", type: "upcoming", count: 85, responseRate: 45 },
    { date: "2025-10-16", type: "overdue1", count: 42, responseRate: 38 },
    { date: "2025-10-23", type: "overdue1", count: 38, responseRate: 35 },
    { date: "2025-11-01", type: "overdue2", count: 28, responseRate: 42 },
    { date: "2025-11-08", type: "overdue2", count: 22, responseRate: 48 },
  ]

  return {
    members,
    duesCycle,
    payments,
    plans,
    reminders,
  }
}

// Analytics helper functions
export function calcKpis(data: DemoData) {
  const { payments, duesCycle, members, plans } = data
  const today = new Date()

  const successfulPayments = payments.filter((p) => p.succeeded)
  const totalCollected = successfulPayments.reduce((sum, p) => sum + p.amount, 0)
  const outstanding = duesCycle.amountPerMember * members.length - totalCollected
  const collectionRate = (totalCollected / duesCycle.goal) * 100

  // Generate sparkline data (last 30 days)
  const sparklineData = []
  for (let i = 29; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    const dayPayments = successfulPayments.filter((p) => p.date === date.toISOString().split("T")[0])
    sparklineData.push(dayPayments.reduce((sum, p) => sum + p.amount, 0))
  }

  return {
    totalCollected,
    outstanding,
    activeMembers: members.length,
    collectionRate,
    avgDaysToPay: 12, // Mock calculation
    onPlans: plans.length,
    failedPayments7d: payments.filter(
      (p) => !p.succeeded && new Date(p.date) >= new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000),
    ).length,
    sparklineData,
  }
}

export function getCollectionsVsTarget(data: DemoData, rangeDays = 60) {
  const { payments, duesCycle } = data
  const today = new Date()
  const series = []

  let cumulativeCollected = 0
  const launchDate = new Date(duesCycle.launchDate)
  const dueDate = new Date(duesCycle.dueDate)
  const totalDays = Math.ceil((dueDate.getTime() - launchDate.getTime()) / (1000 * 60 * 60 * 24))

  for (let i = 0; i < rangeDays; i++) {
    const date = new Date(today)
    date.setDate(date.getDate() - (rangeDays - 1 - i))

    const dayPayments = payments.filter((p) => p.succeeded && p.date === date.toISOString().split("T")[0])
    cumulativeCollected += dayPayments.reduce((sum, p) => sum + p.amount, 0)

    // Calculate target based on linear progression
    const daysSinceLaunch = Math.max(0, Math.ceil((date.getTime() - launchDate.getTime()) / (1000 * 60 * 60 * 24)))
    const targetProgress = Math.min(1, daysSinceLaunch / totalDays)
    const target = duesCycle.goal * targetProgress * 0.95 // 95% target

    series.push({
      date: date.toISOString().split("T")[0],
      collected: cumulativeCollected,
      target: Math.max(0, target),
    })
  }

  return series
}

export function getAgingBuckets(data: DemoData) {
  const { payments, members, duesCycle } = data
  const today = new Date()
  const dueDate = new Date(duesCycle.dueDate)

  const buckets = { "0-7": 0, "8-14": 0, "15-30": 0, "30+": 0 }
  const memberCounts = { "0-7": 0, "8-14": 0, "15-30": 0, "30+": 0 }

  members.forEach((member) => {
    const memberPayments = payments.filter((p) => p.memberId === member.id && p.succeeded)
    const totalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0)
    const outstanding = Math.max(0, duesCycle.amountPerMember - totalPaid)

    if (outstanding > 0 && today > dueDate) {
      const daysOverdue = Math.ceil((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24))

      if (daysOverdue <= 7) {
        buckets["0-7"] += outstanding
        memberCounts["0-7"]++
      } else if (daysOverdue <= 14) {
        buckets["8-14"] += outstanding
        memberCounts["8-14"]++
      } else if (daysOverdue <= 30) {
        buckets["15-30"] += outstanding
        memberCounts["15-30"]++
      } else {
        buckets["30+"] += outstanding
        memberCounts["30+"]++
      }
    }
  })

  return { buckets, memberCounts }
}

export function getMethodBreakdown(data: DemoData, rangeDays = 30) {
  const { payments } = data
  const today = new Date()
  const rangeStart = new Date(today)
  rangeStart.setDate(rangeStart.getDate() - rangeDays)

  const rangePayments = payments.filter((p) => p.succeeded && new Date(p.date) >= rangeStart)

  const breakdown = { card: 0, ach: 0 }
  rangePayments.forEach((payment) => {
    breakdown[payment.method] += payment.amount
  })

  return breakdown
}

export function getCashForecast(data: DemoData, weeks = 12) {
  const { plans } = data
  const today = new Date()
  const forecast = []

  for (let week = 0; week < weeks; week++) {
    const weekStart = new Date(today)
    weekStart.setDate(weekStart.getDate() + week * 7)
    const weekEnd = new Date(weekStart)
    weekEnd.setDate(weekEnd.getDate() + 6)

    let weekTotal = 0

    plans.forEach((plan) => {
      plan.schedule.forEach((installment) => {
        const installmentDate = new Date(installment.date)
        if (!installment.completed && installmentDate >= weekStart && installmentDate <= weekEnd) {
          weekTotal += installment.amount
        }
      })
    })

    forecast.push({
      week: `Week ${week + 1}`,
      weekStart: weekStart.toISOString().split("T")[0],
      amount: weekTotal,
    })
  }

  return forecast
}

export function getReminderImpact(data: DemoData) {
  return data.reminders.map((reminder) => ({
    date: reminder.date,
    remindersSent: reminder.count,
    paymentsWithin48h: Math.round((reminder.count * reminder.responseRate) / 100),
    responseRate: reminder.responseRate,
    type: reminder.type,
  }))
}

export type CohortGridCell = { cohort: string; week: number; pct: number }

// Non-empty fallback so the heatmap is never blank in demo mode.
const FALLBACK_GRID: CohortGridCell[] = [
  { cohort: "Fall 2024", week: 0, pct: 42 },
  { cohort: "Fall 2024", week: 1, pct: 47 },
  { cohort: "Fall 2024", week: 2, pct: 53 },
  { cohort: "Fall 2024", week: 3, pct: 58 },
  { cohort: "Spring 2025", week: 0, pct: 36 },
  { cohort: "Spring 2025", week: 1, pct: 41 },
  { cohort: "Spring 2025", week: 2, pct: 48 },
  { cohort: "Spring 2025", week: 3, pct: 54 },
]

type MemberWithPaymentInfo = { pledgeClass?: string; paidWeeks?: number[] }

/**
 * Builds a cohort x week completion matrix for the heatmap.
 * - Safe defaults to avoid destructuring undefined
 * - Returns fallback demo data if members are missing/empty
 */
export function getCohortMatrix(input: { members?: MemberWithPaymentInfo[] } = { members: [] }): CohortGridCell[] {
  const members = input.members ?? []

  if (members.length === 0) {
    return FALLBACK_GRID
  }

  const cohorts = Array.from(new Set(members.map((m) => m.pledgeClass ?? "Unknown")))
  const weeks = Array.from({ length: 9 }, (_, i) => i) // 0..8 weeks
  const grid: CohortGridCell[] = []

  for (const cohort of cohorts) {
    const cohortMembers = members.filter((m) => (m.pledgeClass ?? "Unknown") === cohort)
    for (const w of weeks) {
      const paid = cohortMembers.filter((m) => (m.paidWeeks ?? []).includes(w)).length
      const pct = Math.round((paid / Math.max(1, cohortMembers.length)) * 100)
      grid.push({ cohort, week: w, pct })
    }
  }

  return grid.length ? grid : FALLBACK_GRID
}

export function getTopOverdue(data: DemoData, limit = 8) {
  const { members, payments, duesCycle, plans } = data
  const today = new Date()
  const dueDate = new Date(duesCycle.dueDate)

  return members
    .map((member) => {
      const memberPayments = payments.filter((p) => p.memberId === member.id && p.succeeded)
      const totalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0)
      const outstanding = duesCycle.amountPerMember - totalPaid
      const hasPaymentPlan = plans.some((p) => p.memberId === member.id)
      const daysLate = today > dueDate ? Math.ceil((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)) : 0

      return { member, outstanding, daysLate, hasPaymentPlan }
    })
    .filter((item) => item.outstanding > 0 && item.daysLate > 0)
    .sort((a, b) => b.outstanding - a.outstanding)
    .slice(0, limit)
}

export function getUpcomingInstallments(data: DemoData, days = 7) {
  const { plans, members } = data
  const today = new Date()
  const endDate = new Date(today)
  endDate.setDate(endDate.getDate() + days)

  const upcoming: Array<{
    member: Member
    date: string
    amount: number
    planStage: string
  }> = []

  plans.forEach((plan) => {
    const member = members.find((m) => m.id === plan.memberId)
    if (!member) return

    plan.schedule.forEach((installment, index) => {
      const installmentDate = new Date(installment.date)
      if (!installment.completed && installmentDate >= today && installmentDate <= endDate) {
        upcoming.push({
          member,
          date: installment.date,
          amount: installment.amount,
          planStage: `${index + 1}/${plan.schedule.length}`,
        })
      }
    })
  })

  return upcoming.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
}

export function getRecentPayments(data: DemoData, days = 30) {
  const { payments, members } = data
  const today = new Date()
  const startDate = new Date(today)
  startDate.setDate(startDate.getDate() - days)

  return payments
    .filter((p) => p.succeeded && new Date(p.date) >= startDate)
    .map((payment) => {
      const member = members.find((m) => m.id === payment.memberId)
      return { payment, member }
    })
    .filter((item) => item.member)
    .sort((a, b) => new Date(b.payment.date).getTime() - new Date(a.payment.date).getTime())
}
