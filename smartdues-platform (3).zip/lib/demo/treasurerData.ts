// Mock data generation and helpers for treasurer analytics demo
// Uses deterministic RNG for consistent data across refreshes

class SeededRandom {
  private seed: number

  constructor(seed: number) {
    this.seed = seed
  }

  next(): number {
    this.seed = (this.seed * 9301 + 49297) % 233280
    return this.seed / 233280
  }

  nextInt(min: number, max: number): number {
    return Math.floor(this.next() * (max - min + 1)) + min
  }

  nextFloat(min: number, max: number): number {
    return this.next() * (max - min) + min
  }

  choice<T>(array: T[]): T {
    return array[Math.floor(this.next() * array.length)]
  }
}

export interface Member {
  id: string
  firstName: string
  lastName: string
  classYear: number
  pledgeClass: string
  email: string
}

export interface DuesCycle {
  id: string
  name: string
  dueDate: string
  goal: number
  amountPerMember: number
  lateFee: number
  launchDate: string
}

import type { PaymentMethod } from "./constants"

export interface Payment {
  id: string
  memberId: string
  date: string
  amount: number
  method: PaymentMethod // Updated to use PaymentMethod type without Venmo
  succeeded: boolean
  processingFee: number
}

export interface PaymentPlan {
  memberId: string
  schedule: Array<{
    date: string
    amount: number
    completed: boolean
  }>
}

export interface Reminder {
  date: string
  type: "upcoming" | "overdue1" | "overdue2"
  count: number
}

export interface DemoData {
  members: Member[]
  duesCycle: DuesCycle
  payments: Payment[]
  plans: PaymentPlan[]
  reminders: Reminder[]
}

const firstNames = [
  "Alex",
  "Blake",
  "Cameron",
  "Drew",
  "Emerson",
  "Finley",
  "Gray",
  "Harper",
  "Indigo",
  "Jordan",
  "Kai",
  "Logan",
  "Morgan",
  "Noah",
  "Oakley",
  "Parker",
  "Quinn",
  "River",
  "Sage",
  "Taylor",
  "Unique",
  "Vale",
  "Winter",
  "Xander",
  "Yarrow",
  "Zion",
  "Avery",
  "Bailey",
  "Casey",
  "Dakota",
  "Ellis",
  "Frankie",
]

const lastNames = [
  "Anderson",
  "Brown",
  "Chen",
  "Davis",
  "Evans",
  "Foster",
  "Garcia",
  "Harris",
  "Johnson",
  "Kim",
  "Lee",
  "Martinez",
  "Nelson",
  "O'Connor",
  "Patel",
  "Quinn",
  "Rodriguez",
  "Smith",
  "Thompson",
  "Underwood",
  "Valdez",
  "Williams",
  "Young",
  "Zhang",
  "Adams",
  "Baker",
  "Clark",
  "Diaz",
  "Edwards",
  "Fisher",
  "Green",
]

const pledgeClasses = [
  "Spring 2022",
  "Fall 2022",
  "Spring 2023",
  "Fall 2023",
  "Spring 2024",
  "Fall 2024",
  "Spring 2025",
]

export function seededDemoData(cycleId = "fall-2025"): DemoData {
  const rng = new SeededRandom(1234)

  // Generate members
  const members: Member[] = []
  for (let i = 0; i < 120; i++) {
    const firstName = rng.choice(firstNames)
    const lastName = rng.choice(lastNames)
    const classYear = rng.nextInt(2022, 2028)
    const pledgeClass = rng.choice(pledgeClasses)

    members.push({
      id: `member-${i + 1}`,
      firstName,
      lastName,
      classYear,
      pledgeClass,
      email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@university.edu`,
    })
  }

  // Dues cycle
  const duesCycle: DuesCycle = {
    id: cycleId,
    name: "Fall 2025",
    dueDate: "2025-10-15",
    goal: 60000,
    amountPerMember: 500,
    lateFee: 25,
    launchDate: "2025-08-15",
  }

  // Generate payments over last 120 days
  const payments: Payment[] = []
  const today = new Date()
  const startDate = new Date(today)
  startDate.setDate(startDate.getDate() - 120)

  for (let i = 0; i < 180; i++) {
    const paymentDate = new Date(startDate)
    paymentDate.setDate(paymentDate.getDate() + rng.nextInt(0, 120))

    const member = rng.choice(members)
    const method = rng.choice(["card", "ach"] as const) // Removed Venmo
    const amount = rng.nextInt(50, 500)
    const succeeded = rng.next() > 0.05 // 95% success rate

    let processingFee = 0
    if (succeeded && method === "card") {
      processingFee = Math.round(amount * 0.031 * 100) / 100
    }

    payments.push({
      id: `payment-${i + 1}`,
      memberId: member.id,
      date: paymentDate.toISOString().split("T")[0],
      amount,
      method,
      succeeded,
      processingFee,
    })
  }

  // Generate payment plans for ~30% of members
  const plans: PaymentPlan[] = []
  const planMembers = members.slice(0, Math.floor(members.length * 0.3))

  planMembers.forEach((member) => {
    const installments = rng.nextInt(2, 4)
    const baseAmount = Math.floor(duesCycle.amountPerMember / installments)
    const schedule = []

    for (let i = 0; i < installments; i++) {
      const installmentDate = new Date("2025-09-01")
      installmentDate.setDate(installmentDate.getDate() + i * 14)

      const amount = i === installments - 1 ? duesCycle.amountPerMember - baseAmount * (installments - 1) : baseAmount

      const completed = installmentDate < today && rng.next() > 0.2

      schedule.push({
        date: installmentDate.toISOString().split("T")[0],
        amount,
        completed,
      })
    }

    plans.push({
      memberId: member.id,
      schedule,
    })
  })

  // Generate reminder history
  const reminders: Reminder[] = [
    { date: "2025-09-15", type: "upcoming", count: 85 },
    { date: "2025-10-16", type: "overdue1", count: 42 },
    { date: "2025-10-23", type: "overdue1", count: 38 },
    { date: "2025-11-01", type: "overdue2", count: 28 },
    { date: "2025-11-08", type: "overdue2", count: 22 },
  ]

  return {
    members,
    duesCycle,
    payments,
    plans,
    reminders,
  }
}

// Helper functions for analytics

export function calcKpis(data: DemoData, rangeDays = 30) {
  const { payments, duesCycle, members, plans } = data
  const today = new Date()
  const rangeStart = new Date(today)
  rangeStart.setDate(rangeStart.getDate() - rangeDays)

  // Filter payments in range
  const rangePayments = payments.filter((p) => p.succeeded && new Date(p.date) >= rangeStart)

  // Calculate totals
  const totalCollected = payments.filter((p) => p.succeeded).reduce((sum, p) => sum + p.amount, 0)

  const outstanding = duesCycle.amountPerMember * members.length - totalCollected
  const collectionRate = (totalCollected / duesCycle.goal) * 100

  // Average days to pay (simplified)
  const avgDaysToPay = 12 // Mock calculation

  const onPlans = plans.length

  const failedPayments7d = payments.filter(
    (p) => !p.succeeded && new Date(p.date) >= new Date(today.getTime() - 7 * 24 * 60 * 60 * 1000),
  ).length

  // Generate sparkline data (last 30 days)
  const sparklineData = []
  for (let i = 29; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    const dayPayments = payments.filter((p) => p.succeeded && p.date === date.toISOString().split("T")[0])
    sparklineData.push(dayPayments.reduce((sum, p) => sum + p.amount, 0))
  }

  return {
    totalCollected,
    outstanding,
    collectionRate,
    avgDaysToPay,
    onPlans,
    failedPayments7d,
    sparklineData,
  }
}

export function seriesCollectionsVsTarget(data: DemoData, rangeDays = 90) {
  const { payments, duesCycle } = data
  const today = new Date()
  const series = []

  let cumulativeCollected = 0
  const launchDate = new Date(duesCycle.launchDate)
  const dueDate = new Date(duesCycle.dueDate)
  const totalDays = Math.ceil((dueDate.getTime() - launchDate.getTime()) / (1000 * 60 * 60 * 24))

  for (let i = 0; i < rangeDays; i++) {
    const date = new Date(today)
    date.setDate(date.getDate() - (rangeDays - 1 - i))

    const dayPayments = payments.filter((p) => p.succeeded && p.date === date.toISOString().split("T")[0])

    cumulativeCollected += dayPayments.reduce((sum, p) => sum + p.amount, 0)

    // Calculate target based on linear progression to due date
    const daysSinceLaunch = Math.max(0, Math.ceil((date.getTime() - launchDate.getTime()) / (1000 * 60 * 60 * 24)))
    const targetProgress = Math.min(1, daysSinceLaunch / totalDays)
    const target = duesCycle.goal * targetProgress

    series.push({
      date: date.toISOString().split("T")[0],
      collected: cumulativeCollected,
      target: Math.max(0, target),
    })
  }

  return series
}

export function agingBuckets(data: DemoData, asOfDate: Date = new Date()) {
  const { payments, members, duesCycle } = data
  const dueDate = new Date(duesCycle.dueDate)

  const buckets = {
    "0-7": 0,
    "8-14": 0,
    "15-30": 0,
    "30+": 0,
  }

  members.forEach((member) => {
    const memberPayments = payments.filter((p) => p.memberId === member.id && p.succeeded)
    const totalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0)
    const outstanding = Math.max(0, duesCycle.amountPerMember - totalPaid)

    if (outstanding > 0 && asOfDate > dueDate) {
      const daysOverdue = Math.ceil((asOfDate.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24))

      if (daysOverdue <= 7) buckets["0-7"] += outstanding
      else if (daysOverdue <= 14) buckets["8-14"] += outstanding
      else if (daysOverdue <= 30) buckets["15-30"] += outstanding
      else buckets["30+"] += outstanding
    }
  })

  return buckets
}

export function methodBreakdown(data: DemoData, rangeDays = 30) {
  const { payments } = data
  const today = new Date()
  const rangeStart = new Date(today)
  rangeStart.setDate(rangeStart.getDate() - rangeDays)

  const rangePayments = payments.filter((p) => p.succeeded && new Date(p.date) >= rangeStart)

  const breakdown = { card: 0, ach: 0 } // Removed Venmo from breakdown

  rangePayments.forEach((payment) => {
    breakdown[payment.method] += payment.amount
  })

  return breakdown
}

export function cashForecast(data: DemoData, weeks = 12) {
  const { plans } = data
  const today = new Date()
  const forecast = []

  for (let week = 0; week < weeks; week++) {
    const weekStart = new Date(today)
    weekStart.setDate(weekStart.getDate() + week * 7)
    const weekEnd = new Date(weekStart)
    weekEnd.setDate(weekEnd.getDate() + 6)

    let weekTotal = 0

    plans.forEach((plan) => {
      plan.schedule.forEach((installment) => {
        const installmentDate = new Date(installment.date)
        if (!installment.completed && installmentDate >= weekStart && installmentDate <= weekEnd) {
          weekTotal += installment.amount
        }
      })
    })

    forecast.push({
      week: `Week ${week + 1}`,
      weekStart: weekStart.toISOString().split("T")[0],
      amount: weekTotal,
    })
  }

  return forecast
}

export function reminderImpact(data: DemoData) {
  const { reminders, payments } = data

  return reminders.map((reminder) => {
    const reminderDate = new Date(reminder.date)
    const followupStart = new Date(reminderDate)
    const followupEnd = new Date(reminderDate)
    followupEnd.setDate(followupEnd.getDate() + 2)

    const paymentsWithin48h = payments.filter((p) => {
      const paymentDate = new Date(p.date)
      return p.succeeded && paymentDate > followupStart && paymentDate <= followupEnd
    }).length

    return {
      date: reminder.date,
      remindersSent: reminder.count,
      paymentsWithin48h,
      type: reminder.type,
    }
  })
}

export function cohortMatrix(data: DemoData) {
  const { members, payments, duesCycle } = data
  const launchDate = new Date(duesCycle.launchDate)

  const cohorts = pledgeClasses.map((pledgeClass) => {
    const cohortMembers = members.filter((m) => m.pledgeClass === pledgeClass)
    const weeks = []

    for (let week = 0; week < 9; week++) {
      const weekEnd = new Date(launchDate)
      weekEnd.setDate(weekEnd.getDate() + (week + 1) * 7)

      const paidMembers = cohortMembers.filter((member) => {
        const memberPayments = payments.filter(
          (p) => p.memberId === member.id && p.succeeded && new Date(p.date) <= weekEnd,
        )
        const totalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0)
        return totalPaid >= duesCycle.amountPerMember
      })

      const percentage = cohortMembers.length > 0 ? (paidMembers.length / cohortMembers.length) * 100 : 0

      weeks.push(Math.round(percentage))
    }

    return {
      pledgeClass,
      weeks,
      totalMembers: cohortMembers.length,
    }
  })

  return cohorts
}

export function topOverdue(data: DemoData, limit = 8) {
  const { members, payments, duesCycle, plans } = data
  const today = new Date()
  const dueDate = new Date(duesCycle.dueDate)

  const overdueMembers = members
    .map((member) => {
      const memberPayments = payments.filter((p) => p.memberId === member.id && p.succeeded)
      const totalPaid = memberPayments.reduce((sum, p) => sum + p.amount, 0)
      const outstanding = duesCycle.amountPerMember - totalPaid

      const hasPaymentPlan = plans.some((p) => p.memberId === member.id)
      const daysLate = today > dueDate ? Math.ceil((today.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)) : 0

      return {
        member,
        outstanding,
        daysLate,
        hasPaymentPlan,
      }
    })
    .filter((item) => item.outstanding > 0 && item.daysLate > 0)
    .sort((a, b) => b.outstanding - a.outstanding)
    .slice(0, limit)

  return overdueMembers
}

export function upcomingInstallments(data: DemoData, days = 7) {
  const { plans, members } = data
  const today = new Date()
  const endDate = new Date(today)
  endDate.setDate(endDate.getDate() + days)

  const upcoming = []

  plans.forEach((plan) => {
    const member = members.find((m) => m.id === plan.memberId)
    if (!member) return

    plan.schedule.forEach((installment, index) => {
      const installmentDate = new Date(installment.date)
      if (!installment.completed && installmentDate >= today && installmentDate <= endDate) {
        upcoming.push({
          member,
          date: installment.date,
          amount: installment.amount,
          planStage: `${index + 1}/${plan.schedule.length}`,
        })
      }
    })
  })

  return upcoming.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
}

export function recentPayments(data: DemoData, days = 30) {
  const { payments, members } = data
  const today = new Date()
  const startDate = new Date(today)
  startDate.setDate(startDate.getDate() - days)

  const recent = payments
    .filter((p) => p.succeeded && new Date(p.date) >= startDate)
    .map((payment) => {
      const member = members.find((m) => m.id === payment.memberId)
      return {
        payment,
        member,
      }
    })
    .filter((item) => item.member)
    .sort((a, b) => new Date(b.payment.date).getTime() - new Date(a.payment.date).getTime())

  return recent
}
