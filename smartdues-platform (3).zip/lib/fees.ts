export type PayMethod = "card" | "ach"

export function calculateTotalWithFees(subtotal: number, method: PayMethod) {
  // round to cents
  const round = (n: number) => Math.round(n * 100) / 100

  if (method === "card") {
    // Credit Card: 3.1% processing surcharge
    const fee = round(subtotal * 0.031)
    return { subtotal: round(subtotal), processingFee: fee, total: round(subtotal + fee) }
  }

  // ACH/Bank Transfer: No processing surcharge
  return { subtotal: round(subtotal), processingFee: 0, total: round(subtotal) }
}
