"use server"

import { createClient } from "@/lib/supabase/server"
import { isSupabaseConfigured } from "@/lib/supabase/server"
import { generateChapterCode } from "@/lib/ids"

export async function signIn(prevState: any, formData: FormData) {
  if (!isSupabaseConfigured) {
    return { error: "Authentication is not configured. Please contact support." }
  }

  if (!formData) {
    return { error: "Form data is missing" }
  }

  const email = formData.get("email")
  const password = formData.get("password")

  if (!email || !password) {
    return { error: "Email and password are required" }
  }

  const supabase = createClient()

  try {
    const { error } = await supabase.auth.signInWithPassword({
      email: email.toString(),
      password: password.toString(),
    })

    if (error) {
      return { error: error.message }
    }

    return { success: true }
  } catch (error) {
    console.error("Login error:", error)
    return { error: "An unexpected error occurred. Please try again." }
  }
}

export async function signUp(prevState: any, formData: FormData) {
  if (!isSupabaseConfigured) {
    return { error: "Authentication is not configured. Please contact support." }
  }

  if (!formData) {
    return { error: "Form data is missing" }
  }

  const organizationName = formData.get("organizationName")
  const university = formData.get("university") // Added university field
  const email = formData.get("email")
  const password = formData.get("password")

  if (!organizationName || !email || !password) {
    return { error: "Organization name, email, and password are required" }
  }

  const supabase = createClient()

  try {
    let chapterCode = generateChapterCode(10)
    let attempts = 0
    const maxAttempts = 5

    // Ensure chapter code is unique
    while (attempts < maxAttempts) {
      const { data: existingOrg } = await supabase
        .from("organizations")
        .select("id")
        .eq("chapter_code", chapterCode)
        .single()

      if (!existingOrg) break

      chapterCode = generateChapterCode(10)
      attempts++
    }

    if (attempts >= maxAttempts) {
      return { error: "Failed to generate unique chapter code. Please try again." }
    }

    // Create user account
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: email.toString(),
      password: password.toString(),
      options: {
        emailRedirectTo:
          process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${process.env.NEXT_PUBLIC_SITE_URL}/app/home`,
      },
    })

    if (authError) {
      return { error: authError.message }
    }

    if (!authData.user) {
      return { error: "Failed to create user account" }
    }

    const { data: orgData, error: orgError } = await supabase
      .from("organizations")
      .insert({
        name: organizationName.toString(),
        slug: chapterCode.toLowerCase(), // Use chapter code as slug
        chapter_code: chapterCode,
        chapter_code_rotated_at: new Date().toISOString(),
        type: "fraternity", // Default type
        card_fee_percent: 3.1,
        ach_fee_percent: 1.0,
        ach_fee_cap_cents: 500, // $5.00
      })
      .select()
      .single()

    if (orgError) {
      console.error("Organization creation error:", orgError)
      return { error: "Failed to create organization. Please try again." }
    }

    // Update user with organization and role
    const { error: userUpdateError } = await supabase
      .from("users")
      .update({
        organization_id: orgData.id,
        role: "treasurer",
      })
      .eq("id", authData.user.id)

    if (userUpdateError) {
      console.error("User update error:", userUpdateError)
      return { error: "Account created but failed to set up organization. Please contact support." }
    }

    console.log(`Welcome email should be sent to ${email} with chapter code: ${chapterCode}`)

    // If user needs email confirmation, show message
    if (!authData.session) {
      return { success: "Please check your email to confirm your account before signing in." }
    }

    // User is automatically signed in, redirect to home
    return { success: true, redirect: true }
  } catch (error) {
    console.error("Sign up error:", error)
    return { error: "An unexpected error occurred. Please try again." }
  }
}

export async function signOut() {
  const supabase = createClient()
  await supabase.auth.signOut()
}
