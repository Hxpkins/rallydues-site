// OTP generation and hashing utilities for Quick Pay verification

import crypto from "crypto"

// Generate a 6-digit OTP code
export function newOtp(): string {
  // 6-digit, no leading zero issues
  return String(Math.floor(100000 + Math.random() * 900000))
}

// Hash an OTP code for secure storage
export function hashOtp(code: string): string {
  return crypto.createHash("sha256").update(code).digest("base64url")
}

// Verify an OTP code against its hash
export function verifyOtp(code: string, hash: string): boolean {
  const codeHash = hashOtp(code)
  return codeHash === hash
}

// Generate a secure salt for additional entropy
export function generateSalt(): string {
  return crypto.randomBytes(16).toString("base64url")
}
