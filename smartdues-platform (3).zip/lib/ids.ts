// Chapter code generator for organizations
// Generates high-entropy, unguessable codes avoiding ambiguous characters

export function generateChapterCode(len = 10): string {
  // High-entropy, unguessable, avoid ambiguous chars (no I/O/0/1)
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
  const bytes = crypto.getRandomValues(new Uint8Array(len))
  let out = ""
  for (const b of bytes) {
    out += alphabet[b % alphabet.length]
  }
  return out
}

// Generate a secure request ID for OTP requests
export function generateRequestId(): string {
  return crypto.randomUUID()
}

// Generate a secure session token
export function generateSessionToken(): string {
  const bytes = crypto.getRandomValues(new Uint8Array(32))
  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("")
}
