// Short-lived signed token utilities for Quick Pay payment step
// Prevents enumeration and ensures secure payment flow

import crypto from "crypto"

const SECRET = process.env.QUICKPAY_SIGNING_SECRET!

if (!SECRET) {
  throw new Error("QUICKPAY_SIGNING_SECRET environment variable is required")
}

export interface PaymentTokenPayload {
  orgId: string
  memberId?: string
  email: string
  amountDue?: number
  exp?: number
}

export interface MemberTokenPayload {
  orgId: string
  memberId: string
  email: string
  amountDue: number
  exp?: number
}

// Sign a token with payload and TTL
export function signToken(payload: PaymentTokenPayload | MemberTokenPayload, ttlSeconds = 600): string {
  const data = {
    ...payload,
    exp: Math.floor(Date.now() / 1000) + ttlSeconds,
  }
  const json = JSON.stringify(data)
  const sig = crypto.createHmac("sha256", SECRET).update(json).digest("base64url")
  return Buffer.from(json).toString("base64url") + "." + sig
}

// Verify and decode a signed token
export function verifyToken(token: string): PaymentTokenPayload | MemberTokenPayload | null {
  try {
    const [b64, sig] = token.split(".")
    if (!b64 || !sig) return null

    const json = Buffer.from(b64, "base64url").toString()
    const expected = crypto.createHmac("sha256", SECRET).update(json).digest("base64url")

    // Constant-time comparison to prevent timing attacks
    if (sig !== expected) return null

    const data = JSON.parse(json)

    // Check expiration
    if (data.exp < Math.floor(Date.now() / 1000)) return null

    return data
  } catch (error) {
    return null
  }
}

// Create a payment token for single member
export function createPaymentToken(orgId: string, memberId: string, email: string, amountDue: number): string {
  return signToken({ orgId, memberId, email, amountDue })
}

// Create a member selection token for multiple members with same email
export function createMemberToken(orgId: string, memberId: string, email: string, amountDue: number): string {
  return signToken({ orgId, memberId, email, amountDue })
}
