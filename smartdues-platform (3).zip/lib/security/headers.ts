// Security headers middleware for enhanced protection
// Implements OWASP security headers recommendations

import type { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function addSecurityHeaders(request: NextRequest, response: NextResponse): NextResponse {
  // Content Security Policy
  const csp = [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://js.stripe.com https://checkout.stripe.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com",
    "img-src 'self' data: https: blob:",
    "connect-src 'self' https://api.stripe.com https://*.supabase.co wss://*.supabase.co",
    "frame-src 'self' https://js.stripe.com https://checkout.stripe.com",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
    "upgrade-insecure-requests",
  ].join("; ")

  // Set security headers
  response.headers.set("Content-Security-Policy", csp)
  response.headers.set("X-Frame-Options", "DENY")
  response.headers.set("X-Content-Type-Options", "nosniff")
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin")
  response.headers.set("X-XSS-Protection", "1; mode=block")
  response.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()")

  // HSTS (only in production with HTTPS)
  if (process.env.NODE_ENV === "production") {
    response.headers.set("Strict-Transport-Security", "max-age=31536000; includeSubDomains; preload")
  }

  // Remove server information
  response.headers.delete("Server")
  response.headers.delete("X-Powered-By")

  return response
}

// Validate environment variables for security
export function validateSecurityEnvironment(): { valid: boolean; errors: string[] } {
  const errors: string[] = []
  const required = [
    "NEXT_PUBLIC_SUPABASE_URL",
    "NEXT_PUBLIC_SUPABASE_ANON_KEY",
    "SUPABASE_SERVICE_ROLE_KEY",
    "STRIPE_SECRET_KEY",
    "STRIPE_WEBHOOK_SECRET",
    "QUICKPAY_SIGNING_SECRET",
  ]

  for (const envVar of required) {
    if (!process.env[envVar]) {
      errors.push(`Missing required environment variable: ${envVar}`)
    }
  }

  // Validate secret lengths
  if (process.env.QUICKPAY_SIGNING_SECRET && process.env.QUICKPAY_SIGNING_SECRET.length < 32) {
    errors.push("QUICKPAY_SIGNING_SECRET must be at least 32 characters")
  }

  // Validate URLs
  if (process.env.NEXT_PUBLIC_SUPABASE_URL && !process.env.NEXT_PUBLIC_SUPABASE_URL.startsWith("https://")) {
    errors.push("NEXT_PUBLIC_SUPABASE_URL must use HTTPS")
  }

  return { valid: errors.length === 0, errors }
}
