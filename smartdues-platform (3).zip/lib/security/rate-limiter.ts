// Centralized rate limiting utility with abuse monitoring
// Provides consistent rate limiting across all API endpoints

interface RateLimitConfig {
  windowMs: number // Time window in milliseconds
  maxRequests: number // Maximum requests per window
  keyGenerator?: (identifier: string) => string // Custom key generator
  skipSuccessfulRequests?: boolean // Don't count successful requests
  skipFailedRequests?: boolean // Don't count failed requests
}

interface RateLimitEntry {
  count: number
  resetTime: number
  firstRequest: number
  violations: number
}

// Global rate limit storage (in production, use Redis)
const rateLimitStore = new Map<string, RateLimitEntry>()
const abuseLog = new Map<string, { violations: number; lastViolation: number; blocked: boolean }>()

// Cleanup expired entries every 5 minutes
setInterval(
  () => {
    const now = Date.now()
    for (const [key, entry] of rateLimitStore.entries()) {
      if (now > entry.resetTime) {
        rateLimitStore.delete(key)
      }
    }

    // Cleanup old abuse logs (older than 24 hours)
    for (const [key, entry] of abuseLog.entries()) {
      if (now - entry.lastViolation > 24 * 60 * 60 * 1000) {
        abuseLog.delete(key)
      }
    }
  },
  5 * 60 * 1000,
)

export class RateLimiter {
  private config: RateLimitConfig

  constructor(config: RateLimitConfig) {
    this.config = config
  }

  check(identifier: string): { allowed: boolean; remaining: number; resetTime: number; requiresCaptcha: boolean } {
    const key = this.config.keyGenerator ? this.config.keyGenerator(identifier) : identifier
    const now = Date.now()

    // Check if identifier is blocked due to abuse
    const abuseEntry = abuseLog.get(identifier)
    if (abuseEntry?.blocked && now - abuseEntry.lastViolation < 60 * 60 * 1000) {
      // 1 hour block
      return {
        allowed: false,
        remaining: 0,
        resetTime: abuseEntry.lastViolation + 60 * 60 * 1000,
        requiresCaptcha: true,
      }
    }

    let entry = rateLimitStore.get(key)

    if (!entry || now > entry.resetTime) {
      entry = {
        count: 1,
        resetTime: now + this.config.windowMs,
        firstRequest: now,
        violations: entry?.violations || 0,
      }
      rateLimitStore.set(key, entry)
      return {
        allowed: true,
        remaining: this.config.maxRequests - 1,
        resetTime: entry.resetTime,
        requiresCaptcha: false,
      }
    }

    if (entry.count >= this.config.maxRequests) {
      // Rate limit exceeded - log potential abuse
      entry.violations++
      this.logAbuse(identifier, "rate_limit_exceeded", {
        requests: entry.count,
        window: this.config.windowMs,
        violations: entry.violations,
      })

      // Determine if CAPTCHA is required (after 3 violations)
      const requiresCaptcha = entry.violations >= 3

      return { allowed: false, remaining: 0, resetTime: entry.resetTime, requiresCaptcha }
    }

    entry.count++
    return {
      allowed: true,
      remaining: this.config.maxRequests - entry.count,
      resetTime: entry.resetTime,
      requiresCaptcha: false,
    }
  }

  private logAbuse(identifier: string, type: string, metadata: any) {
    const now = Date.now()
    let abuseEntry = abuseLog.get(identifier)

    if (!abuseEntry) {
      abuseEntry = { violations: 0, lastViolation: now, blocked: false }
    }

    abuseEntry.violations++
    abuseEntry.lastViolation = now

    // Block after 10 violations in 24 hours
    if (abuseEntry.violations >= 10) {
      abuseEntry.blocked = true
    }

    abuseLog.set(identifier, abuseEntry)

    // Log to console (in production, send to monitoring service)
    console.warn(`[SECURITY] Abuse detected: ${type}`, {
      identifier,
      violations: abuseEntry.violations,
      blocked: abuseEntry.blocked,
      metadata,
      timestamp: new Date(now).toISOString(),
    })
  }

  // Get abuse statistics for monitoring
  static getAbuseStats() {
    const now = Date.now()
    const stats = {
      totalAbusers: abuseLog.size,
      blockedIPs: 0,
      recentViolations: 0,
    }

    for (const [key, entry] of abuseLog.entries()) {
      if (entry.blocked) stats.blockedIPs++
      if (now - entry.lastViolation < 60 * 60 * 1000) stats.recentViolations++ // Last hour
    }

    return stats
  }
}

// Predefined rate limiters for common use cases
export const rateLimiters = {
  // Quick Pay endpoints
  quickPayStart: new RateLimiter({ windowMs: 60 * 60 * 1000, maxRequests: 10 }), // 10/hour
  quickPayVerify: new RateLimiter({ windowMs: 15 * 60 * 1000, maxRequests: 5 }), // 5/15min
  quickPayPay: new RateLimiter({ windowMs: 15 * 60 * 1000, maxRequests: 5 }), // 5/15min

  // Email-based limits
  emailOTP: new RateLimiter({ windowMs: 60 * 1000, maxRequests: 1 }), // 1/minute per email

  // General API limits
  apiGeneral: new RateLimiter({ windowMs: 15 * 60 * 1000, maxRequests: 100 }), // 100/15min

  // Contact form
  contactForm: new RateLimiter({ windowMs: 15 * 60 * 1000, maxRequests: 10 }), // 10/15min
}

// Utility function to get client IP
export function getClientIP(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for")
  const realIP = request.headers.get("x-real-ip")
  const cfConnectingIP = request.headers.get("cf-connecting-ip")

  if (cfConnectingIP) return cfConnectingIP
  if (forwarded) return forwarded.split(",")[0].trim()
  if (realIP) return realIP
  return "unknown"
}
