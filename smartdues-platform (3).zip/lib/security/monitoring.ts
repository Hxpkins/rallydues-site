// Security monitoring and logging utilities
// Provides centralized security event logging and monitoring

interface SecurityEvent {
  type: "rate_limit_exceeded" | "invalid_token" | "failed_auth" | "suspicious_activity" | "payment_fraud"
  identifier: string // IP, email, or user ID
  metadata: Record<string, any>
  timestamp: number
  severity: "low" | "medium" | "high" | "critical"
}

class SecurityMonitor {
  private events: SecurityEvent[] = []
  private readonly maxEvents = 10000 // Keep last 10k events in memory

  logEvent(event: Omit<SecurityEvent, "timestamp">) {
    const securityEvent: SecurityEvent = {
      ...event,
      timestamp: Date.now(),
    }

    this.events.push(securityEvent)

    // Keep only recent events
    if (this.events.length > this.maxEvents) {
      this.events = this.events.slice(-this.maxEvents)
    }

    // Log to console (in production, send to monitoring service)
    const logLevel = this.getLogLevel(event.severity)
    console[logLevel](`[SECURITY] ${event.type}:`, {
      identifier: event.identifier,
      severity: event.severity,
      metadata: event.metadata,
      timestamp: new Date(securityEvent.timestamp).toISOString(),
    })

    // Send alerts for critical events
    if (event.severity === "critical") {
      this.sendAlert(securityEvent)
    }
  }

  private getLogLevel(severity: string): "log" | "warn" | "error" {
    switch (severity) {
      case "critical":
      case "high":
        return "error"
      case "medium":
        return "warn"
      default:
        return "log"
    }
  }

  private sendAlert(event: SecurityEvent) {
    // In production, integrate with alerting service (PagerDuty, Slack, etc.)
    console.error(`[CRITICAL SECURITY ALERT] ${event.type}`, event)
  }

  getRecentEvents(minutes = 60): SecurityEvent[] {
    const cutoff = Date.now() - minutes * 60 * 1000
    return this.events.filter((event) => event.timestamp > cutoff)
  }

  getEventsByType(type: SecurityEvent["type"], hours = 24): SecurityEvent[] {
    const cutoff = Date.now() - hours * 60 * 60 * 1000
    return this.events.filter((event) => event.type === type && event.timestamp > cutoff)
  }

  getTopOffenders(hours = 24, limit = 10): Array<{ identifier: string; count: number }> {
    const cutoff = Date.now() - hours * 60 * 60 * 1000
    const recentEvents = this.events.filter((event) => event.timestamp > cutoff)

    const counts = new Map<string, number>()
    for (const event of recentEvents) {
      counts.set(event.identifier, (counts.get(event.identifier) || 0) + 1)
    }

    return Array.from(counts.entries())
      .map(([identifier, count]) => ({ identifier, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit)
  }

  getSecurityStats() {
    const now = Date.now()
    const lastHour = now - 60 * 60 * 1000
    const last24Hours = now - 24 * 60 * 60 * 1000

    const recentEvents = this.events.filter((event) => event.timestamp > lastHour)
    const dailyEvents = this.events.filter((event) => event.timestamp > last24Hours)

    return {
      eventsLastHour: recentEvents.length,
      eventsLast24Hours: dailyEvents.length,
      criticalEventsLastHour: recentEvents.filter((e) => e.severity === "critical").length,
      topEventTypes: this.getTopEventTypes(dailyEvents),
      topOffenders: this.getTopOffenders(24, 5),
    }
  }

  private getTopEventTypes(events: SecurityEvent[]): Array<{ type: string; count: number }> {
    const counts = new Map<string, number>()
    for (const event of events) {
      counts.set(event.type, (counts.get(event.type) || 0) + 1)
    }

    return Array.from(counts.entries())
      .map(([type, count]) => ({ type, count }))
      .sort((a, b) => b.count - a.count)
  }
}

// Global security monitor instance
export const securityMonitor = new SecurityMonitor()

// Convenience functions for common security events
export const logSecurityEvent = {
  rateLimitExceeded: (identifier: string, endpoint: string, attempts: number) => {
    securityMonitor.logEvent({
      type: "rate_limit_exceeded",
      identifier,
      severity: attempts > 20 ? "high" : "medium",
      metadata: { endpoint, attempts },
    })
  },

  invalidToken: (identifier: string, tokenType: string) => {
    securityMonitor.logEvent({
      type: "invalid_token",
      identifier,
      severity: "medium",
      metadata: { tokenType },
    })
  },

  failedAuth: (identifier: string, reason: string) => {
    securityMonitor.logEvent({
      type: "failed_auth",
      identifier,
      severity: "medium",
      metadata: { reason },
    })
  },

  suspiciousActivity: (identifier: string, activity: string, metadata: Record<string, any> = {}) => {
    securityMonitor.logEvent({
      type: "suspicious_activity",
      identifier,
      severity: "high",
      metadata: { activity, ...metadata },
    })
  },

  paymentFraud: (identifier: string, amount: number, metadata: Record<string, any> = {}) => {
    securityMonitor.logEvent({
      type: "payment_fraud",
      identifier,
      severity: "critical",
      metadata: { amount, ...metadata },
    })
  },
}
