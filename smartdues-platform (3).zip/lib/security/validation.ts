// Input validation and sanitization utilities
// Provides consistent validation across all API endpoints

import { z } from "zod"

// Common validation schemas
export const schemas = {
  email: z.string().email().max(255),
  chapterCode: z.string().regex(/^[A-Z0-9]{6,12}$/, "Chapter code must be 6-12 uppercase letters and numbers"),
  otp: z.string().regex(/^\d{6}$/, "OTP must be exactly 6 digits"),
  amount: z.number().min(0.01).max(10000),
  paymentMethod: z.enum(["card", "ach"]),
  organizationName: z.string().min(1).max(255).trim(),
  name: z.string().min(1).max(100).trim(),
  message: z.string().min(1).max(5000).trim(),
}

// Sanitization functions
export function sanitizeInput(input: string): string {
  return input
    .trim()
    .replace(/[<>]/g, "") // Remove potential XSS characters
    .replace(/\0/g, "") // Remove null bytes
    .slice(0, 10000) // Limit length
}

export function sanitizeEmail(email: string): string {
  return email.toLowerCase().trim().slice(0, 255)
}

// Rate limiting key generators
export function generateRateLimitKey(type: string, identifier: string, additional?: string): string {
  const parts = [type, identifier]
  if (additional) parts.push(additional)
  return parts.join(":")
}

// Generic error responses to prevent enumeration
export const genericResponses = {
  rateLimited: "Too many requests. Please try again later.",
  invalidInput: "Invalid input provided.",
  notFound: "Resource not found.",
  unauthorized: "Authentication required.",
  forbidden: "Insufficient permissions.",
  serverError: "An unexpected error occurred. Please try again.",
  serviceUnavailable: "Service temporarily unavailable.",
}

// Validation middleware
export function validateRequest<T>(
  schema: z.ZodSchema<T>,
  data: unknown,
): { success: true; data: T } | { success: false; error: string } {
  try {
    const result = schema.parse(data)
    return { success: true, data: result }
  } catch (error) {
    if (error instanceof z.ZodError) {
      const firstError = error.errors[0]
      return { success: false, error: firstError.message }
    }
    return { success: false, error: genericResponses.invalidInput }
  }
}
