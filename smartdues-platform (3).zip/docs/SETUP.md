# RallyDues Setup Guide

This guide will help you configure RallyDues for development and production use.

## Environment Variables

RallyDues requires several environment variables to function properly. You can add these in your v0 project settings or your deployment platform.

### Required Variables

#### Email Configuration (Contact Form)

- **RESEND_API_KEY**: Your Resend API key for sending emails
- **SUPPORT_EMAIL**: Email address where contact form submissions will be sent (e.g., `support@rallydues.com`)
- **EMAIL_FROM**: Email address used as the sender (e.g., `RallyDues <support@rallydues.com>`)
  - If not provided, defaults to `RallyDues <no-reply@rallydues.com>`

#### Database (Supabase)

- **NEXT_PUBLIC_SUPABASE_URL**: Your Supabase project URL
- **NEXT_PUBLIC_SUPABASE_ANON_KEY**: Your Supabase anonymous key
- **SUPABASE_SERVICE_ROLE_KEY**: Your Supabase service role key (for admin operations)

#### Payments (Stripe)

- **STRIPE_SECRET_KEY**: Your Stripe secret key
- **STRIPE_WEBHOOK_SECRET**: Your Stripe webhook endpoint secret
- **NEXT_PUBLIC_SITE_URL**: Your site's URL for Stripe redirects (e.g., `https://rallydues.com`)

### Adding Environment Variables in v0

1. Click on **Project Settings** in the top right corner of the v0 interface
2. Navigate to the **Environment Variables** section
3. Add each required variable with its corresponding value
4. Save the changes

### Adding Environment Variables in Vercel

1. Go to your Vercel dashboard
2. Select your project
3. Go to **Settings** → **Environment Variables**
4. Add each required variable for the appropriate environments (Development, Preview, Production)

## Email Setup with Resend

### Getting Started

1. Sign up for a [Resend account](https://resend.com)
2. Generate an API key from your Resend dashboard
3. Add the API key as `RESEND_API_KEY` in your environment variables

### Important Notes

- **Sandbox Mode**: By default, Resend operates in sandbox mode
- **Domain Verification**: To send emails to any address, you must verify your sender domain
- **Development**: In sandbox mode, emails are only sent to verified email addresses
- **Production**: Verify your domain (e.g., `rallydues.com`) to send emails to any recipient

### Domain Verification Steps

1. In your Resend dashboard, go to **Domains**
2. Click **Add Domain** and enter your domain (e.g., `rallydues.com`)
3. Add the required DNS records to your domain provider
4. Wait for verification (usually takes a few minutes to hours)
5. Once verified, you can send emails from addresses like `support@rallydues.com`

## Database Setup

RallyDues uses Supabase for data storage and authentication.

### Initial Setup

1. Create a new Supabase project
2. Run the database migration scripts in order:
   - `scripts/001_initial_schema.sql`
   - `scripts/002_add_payment_indexes.sql`
   - `scripts/003_add_kpi_function.sql`
   - `scripts/004_add_organization_fee_settings.sql`

### Running Migrations

In v0, you can run SQL scripts directly:
1. Navigate to the **Scripts** section
2. Select the migration file
3. Click **Run Script**

## Stripe Setup

RallyDues uses Stripe for payment processing with Connect for multi-tenant support.

### Configuration

1. Create a Stripe account
2. Get your API keys from the Stripe dashboard
3. Set up webhooks pointing to `/api/stripe/webhook`
4. Configure Stripe Connect for multi-tenant payments (if needed)

### Webhook Events

Ensure your Stripe webhook is configured to send these events:
- `checkout.session.completed`
- `payment_intent.succeeded`

## Development vs Production

### Development
- Use Stripe test keys
- Resend sandbox mode is acceptable
- Use development Supabase project

### Production
- Use Stripe live keys
- Verify your domain in Resend
- Use production Supabase project
- Ensure all environment variables are set

## Troubleshooting

### Contact Form Not Working
- Check that `RESEND_API_KEY` and `SUPPORT_EMAIL` are set
- Verify your domain in Resend for production use
- Check the browser console for error messages

### Payment Issues
- Verify Stripe keys are correct
- Check webhook configuration
- Ensure `STRIPE_WEBHOOK_SECRET` matches your webhook endpoint

### Database Errors
- Confirm Supabase environment variables are set
- Run all migration scripts in order
- Check Supabase logs for detailed error messages

## Support

For additional help:
- Check the application logs in your deployment platform
- Review Supabase logs for database issues
- Check Stripe dashboard for payment-related problems
- Contact support if you encounter persistent issues

---

**Note**: This setup guide covers the essential configuration for RallyDues. Always use secure, unique values for production environment variables and never commit sensitive keys to version control.
