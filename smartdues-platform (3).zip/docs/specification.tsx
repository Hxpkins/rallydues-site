export default function Specification() {
  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <h1 className="text-3xl font-bold">SmartDues Platform Specification</h1>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Goal</h2>
        <p>
          Generate a production-ready, multi-tenant dues platform ("SmartDues") for fraternities/sororities/HOAs. Each
          organization (chapter) onboards, invites members, sets a fixed due date (e.g., Oct 15), customizes
          amounts/late fees/grace period, optionally approves installment plans, and collects payments online. Members
          log in to view/pay. Minimal providers: Supabase (Auth/DB/Storage) and Stripe (Payments, Billing, Connect,
          hosted Checkout/Invoice emails). No refunds UI in v1. Exclude sponsorship/donations.
        </p>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Stack</h2>
        <ul className="space-y-2">
          <li>
            <strong>Frontend:</strong> Next.js (App Router, TypeScript), TailwindCSS, shadcn/ui, dark/light theme
            toggle, responsive and accessible.
          </li>
          <li>
            <strong>Auth/DB/Storage:</strong> Supabase (email+password auth only). Use RLS for multi-tenant isolation.
          </li>
          <li>
            <strong>Payments:</strong> Stripe Connect Standard (one connected Stripe account per org). Payment methods:
            Cards, ACH (Financial Connections/ACH Debit), Venmo, Apple Pay/Google Pay via Checkout.
          </li>
          <li>
            <strong>Scheduling:</strong> Vercel Cron (daily) to compute upcoming dues tasks & mark reminder intents.
          </li>
          <li>
            <strong>Analytics:</strong> PostHog env key if provided; otherwise omit.
          </li>
          <li>
            <strong>Timezone:</strong> Default to America/Phoenix everywhere (server and UI).
          </li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Tenancy & Roles</h2>
        <p>Multi-tenant from day one. Users belong to exactly one organization (transferable by Treasurer).</p>
        <p>
          <strong>Roles:</strong> member, treasurer, president, exec.
        </p>
        <ul className="space-y-2 mt-2">
          <li>
            <strong>member:</strong> view/pay own balances, see history, manage payment methods, request plan (until
            plan-request cutoff).
          </li>
          <li>
            <strong>treasurer/president/exec:</strong> full org dashboard, roster import, dues cycles, plans, late
            fees/grace, reminders config, exports, Stripe Connect onboarding.
          </li>
          <li>
            <strong>platform_admin:</strong> (seed only): manage orgs/impersonate for support.
          </li>
        </ul>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Data Model (Supabase/Postgres)</h2>
        <p>Create tables with RLS (org-scoped by organization_id). Provide SQL + policies.</p>
        <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg mt-4">
          <h3 className="font-semibold mb-2">Suggested Schema:</h3>
          <ul className="space-y-1 text-sm font-mono">
            <li>organizations (id, name, slug, stripe_connect_account_id, primary_color, theme_mode, created_at)</li>
            <li>
              profiles (id = auth.user_id UUID, email, first_name, last_name, role ENUM, organization_id, created_at)
            </li>
            <li>
              members (id, organization_id, profile_id, email, first_name, last_name, member_type ENUM, status ENUM,
              stripe_customer_id, custom_amount_cents, created_at)
            </li>
            <li>
              dues_cycles (id, organization_id, name, due_date, default_amount_cents, plan_request_cutoff,
              late_fee_cents, grace_days, created_at)
            </li>
            <li>
              member_dues (id, organization_id, dues_cycle_id, member_id, amount_cents, status ENUM, late_fee_applied,
              notes, created_at)
            </li>
            <li>
              payment_plans (id, organization_id, member_dues_id, type ENUM, installments_count, first_due_date,
              schedule_rule JSONB, stripe_subscription_id, status ENUM, created_at)
            </li>
            <li>
              plan_installments (id, payment_plan_id, due_date, amount_cents, status ENUM, stripe_invoice_id,
              created_at)
            </li>
            <li>reminder_settings (id, organization_id, email_enabled, sms_enabled, cadence JSONB, created_at)</li>
            <li>emails_log (id, organization_id, member_id, subject, channel ENUM, send_at, meta JSONB, created_at)</li>
            <li>audit_placeholder (create table but unused in v1, keep for easy v2 adoption)</li>
          </ul>
        </div>
      </section>

      <section>
        <h2 className="text-2xl font-semibold mb-4">Acceptance Criteria</h2>
        <ul className="space-y-2">
          <li>Multi-org RLS isolation verified</li>
          <li>
            Treasurer can: import roster, create Fall 2025 cycle (10/15 due), set cutoff (10/08), set late/grace,
            generate invoices with 3.1% card/Venmo fee and 1% ACH fee cap $5, and see hosted invoice links
          </li>
          <li>Member can: log in, see balance, pay via hosted invoice/Checkout, view history, manage PM</li>
          <li>
            Plan flow: Treasurer creates 3-installment schedule (15th monthly), first installment on 10/15, subsequent
            on 11/15, 12/15, invoices generated, emails sent by Stripe
          </li>
          <li>Webhooks mark payments paid/failed, dashboard KPIs update</li>
          <li>Theme toggle works, default dark with blue primary</li>
          <li>No refunds UI, Exports download CSVs</li>
        </ul>
      </section>
    </div>
  )
}
