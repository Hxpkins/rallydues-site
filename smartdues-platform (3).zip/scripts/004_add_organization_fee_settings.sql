-- Add fee configuration columns to organizations table
ALTER TABLE organizations 
ADD COLUMN IF NOT EXISTS card_fee_percent DECIMAL(5,4) DEFAULT 0.031,
ADD COLUMN IF NOT EXISTS ach_fee_percent DECIMAL(5,4) DEFAULT 0.01,
ADD COLUMN IF NOT EXISTS ach_fee_cap_cents INTEGER DEFAULT 500,
ADD COLUMN IF NOT EXISTS venmo_enabled BOOLEAN DEFAULT false;

-- Update existing organizations with default values
UPDATE organizations 
SET 
  card_fee_percent = 0.031,
  ach_fee_percent = 0.01,
  ach_fee_cap_cents = 500,
  venmo_enabled = false
WHERE card_fee_percent IS NULL;
