-- Added stored procedure for updating organization KPIs
CREATE OR REPLACE FUNCTION update_organization_kpis(
  org_id UUID,
  payment_amount DECIMAL,
  fee_amount DECIMAL
)
RETURNS VOID AS $$
BEGIN
  -- Update organization totals (you may need to add these columns)
  UPDATE organizations 
  SET 
    total_collected = COALESCE(total_collected, 0) + payment_amount,
    total_fees = COALESCE(total_fees, 0) + fee_amount,
    updated_at = NOW()
  WHERE id = org_id;
  
  -- Log the KPI update
  INSERT INTO organization_kpis (
    organization_id,
    metric_type,
    metric_value,
    recorded_at
  ) VALUES 
    (org_id, 'payment_received', payment_amount, NOW()),
    (org_id, 'processing_fee', fee_amount, NOW());
    
EXCEPTION WHEN OTHERS THEN
  -- Log error but don't fail the webhook
  RAISE NOTICE 'Error updating KPIs for org %: %', org_id, SQLERRM;
END;
$$ LANGUAGE plpgsql;

-- Create KPIs table if it doesn't exist
CREATE TABLE IF NOT EXISTS organization_kpis (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organizations(id) ON DELETE CASCADE,
  metric_type VARCHAR(50) NOT NULL,
  metric_value DECIMAL(10,2) NOT NULL,
  recorded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Add KPI columns to organizations table if they don't exist
ALTER TABLE organizations 
ADD COLUMN IF NOT EXISTS total_collected DECIMAL(10,2) DEFAULT 0,
ADD COLUMN IF NOT EXISTS total_fees DECIMAL(10,2) DEFAULT 0;
