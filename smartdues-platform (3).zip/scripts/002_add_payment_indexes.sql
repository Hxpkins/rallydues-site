-- Add additional indexes for payment processing performance
-- This script adds indexes to optimize webhook processing and payment queries

-- Index for webhook processing - finding payments by Stripe payment intent ID
CREATE INDEX IF NOT EXISTS idx_payments_stripe_payment_intent_lookup 
ON payments(stripe_payment_intent_id) 
WHERE stripe_payment_intent_id IS NOT NULL;

-- Index for member dues status queries
CREATE INDEX IF NOT EXISTS idx_member_dues_status_lookup 
ON member_dues(status, updated_at);

-- Index for payment status and timestamp queries
CREATE INDEX IF NOT EXISTS idx_payments_status_timestamp 
ON payments(status, paid_at);

-- Index for organization payment queries
CREATE INDEX IF NOT EXISTS idx_member_dues_organization_lookup 
ON member_dues(user_id) 
INCLUDE (amount_owed, amount_paid, status);

-- Composite index for quick pay lookups
CREATE INDEX IF NOT EXISTS idx_users_paycode_lastname_lookup 
ON users(paycode, last_name) 
WHERE paycode IS NOT NULL;

-- Add constraint to ensure payment amounts are positive
ALTER TABLE payments 
ADD CONSTRAINT check_payment_amount_positive 
CHECK (amount > 0);

-- Add constraint to ensure processing fees are non-negative
ALTER TABLE payments 
ADD CONSTRAINT check_processing_fee_non_negative 
CHECK (processing_fee >= 0);

-- Add constraint to ensure member dues amounts are consistent
ALTER TABLE member_dues 
ADD CONSTRAINT check_amount_paid_not_exceed_owed 
CHECK (amount_paid <= amount_owed);
