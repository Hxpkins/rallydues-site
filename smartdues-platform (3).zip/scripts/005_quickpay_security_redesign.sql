-- Quick Pay Security Redesign: Auto-generated chapter codes + OTP verification
-- Migration 005: Add chapter code fields to organizations and create quickpay_otps table

-- Add chapter code fields to organizations table
ALTER TABLE organizations
  ADD COLUMN chapter_code TEXT UNIQUE,
  ADD COLUMN chapter_code_rotated_at TIMESTAMPTZ,
  ADD COLUMN prev_chapter_code TEXT,
  ADD COLUMN prev_code_valid_until TIMESTAMPTZ;

-- Create index for chapter code lookups
CREATE INDEX IF NOT EXISTS idx_organizations_chapter_code ON organizations (chapter_code);
CREATE INDEX IF NOT EXISTS idx_organizations_prev_chapter_code ON organizations (prev_chapter_code);

-- QuickPay OTP table (ephemeral; can be cleaned on a schedule)
CREATE TABLE IF NOT EXISTS quickpay_otps (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  org_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  code_hash TEXT NOT NULL,
  request_id TEXT NOT NULL,
  attempts INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ,
  ip INET
);

-- Indexes for quickpay_otps
CREATE INDEX IF NOT EXISTS idx_quickpay_otps_org_email ON quickpay_otps (org_id, email);
CREATE INDEX IF NOT EXISTS idx_quickpay_otps_request ON quickpay_otps (request_id);
CREATE INDEX IF NOT EXISTS idx_quickpay_otps_expires ON quickpay_otps (expires_at);

-- Cleanup function for expired OTPs (can be called by a scheduled job)
CREATE OR REPLACE FUNCTION cleanup_expired_otps()
RETURNS INTEGER AS $$
DECLARE
  deleted_count INTEGER;
BEGIN
  DELETE FROM quickpay_otps 
  WHERE expires_at < now() - INTERVAL '1 hour';
  
  GET DIAGNOSTICS deleted_count = ROW_COUNT;
  RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Comment on the cleanup function
COMMENT ON FUNCTION cleanup_expired_otps() IS 'Removes expired OTP records older than 1 hour past expiration';
