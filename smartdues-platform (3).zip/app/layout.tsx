import "./globals.css"
import { Inter } from "next/font/google"
import type React from "react"
import type { Metadata } from "next"

const inter = Inter({ subsets: ["latin"], variable: "--font-sans", display: "swap" })

export const metadata: Metadata = {
  title: "RallyDues - Modern Dues Management for Greek Life",
  description:
    "Streamline your organization's finances with automated dues collection, payment plans, and comprehensive member management.",
  generator: "RallyDues",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${inter.variable} font-sans bg-slate-50 text-slate-900 antialiased`}>{children}</body>
    </html>
  )
}
