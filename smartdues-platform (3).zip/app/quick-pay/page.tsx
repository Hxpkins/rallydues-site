import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { QuickPayForm } from "@/components/quick-pay-form"
import { QuickPayResults } from "@/components/quick-pay-results"
import { Button } from "@/components/ui/button"
import { Loader2, DollarSign } from "lucide-react"
import Link from "next/link"
import { Navigation } from "@/components/navigation"

interface QuickPayPageProps {
  searchParams: { paycode?: string; lastname?: string; email?: string; canceled?: string }
}

export default function QuickPayPage({ searchParams }: QuickPayPageProps) {
  const { paycode, lastname, email, canceled } = searchParams

  // If we have search params, show results; otherwise show the form
  const showResults = paycode && lastname && email

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white border-b border-[var(--border)] sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)] rounded-lg"
          >
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>

          <Navigation />

          <div className="flex items-center space-x-4">
            <Link href="/signin">
              <Button variant="ghost" size="sm">
                Sign In
              </Button>
            </Link>
            <Link href="/signup">
              <Button size="sm" className="bg-orange-500 hover:bg-orange-600 text-white">
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-[var(--text)] mb-4">Quick Pay</h1>
            <p className="text-lg text-[var(--subtext)]">
              Pay your dues quickly and securely without creating an account
            </p>
          </div>

          {/* Canceled Payment Alert */}
          {canceled && (
            <div className="mb-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-yellow-800 text-center">Payment was canceled. You can try again below.</p>
            </div>
          )}

          {/* Main Content */}
          <Card className="shadow-xl border border-[var(--border)] bg-[var(--surface)]">
            <CardHeader className="text-center pb-6 bg-slate-50">
              <CardTitle className="text-2xl text-[var(--text)]">
                {showResults ? "Outstanding Dues" : "Enter Your Information"}
              </CardTitle>
              <CardDescription className="text-base text-[var(--subtext)]">
                {showResults
                  ? "Review and pay your outstanding dues below"
                  : "Enter your PayCode and last name to view your dues"}
              </CardDescription>
            </CardHeader>
            <CardContent className="bg-slate-50">
              {showResults ? (
                <Suspense
                  fallback={
                    <div className="flex items-center justify-center py-12">
                      <Loader2 className="h-8 w-8 animate-spin text-[var(--primary)]" />
                      <span className="ml-2 text-[var(--subtext)]">Loading your dues...</span>
                    </div>
                  }
                >
                  <QuickPayResults paycode={paycode} lastname={lastname} email={email} />
                </Suspense>
              ) : (
                <QuickPayForm />
              )}
            </CardContent>
          </Card>

          {/* Help Section */}
          <div className="mt-8 text-center">
            <Card className="bg-blue-50 border-blue-200">
              <CardContent className="pt-6">
                <h3 className="font-semibold text-blue-900 mb-2">Need Help?</h3>
                <p className="text-sm text-blue-700 mb-4">
                  Your PayCode is a unique code provided by your organization's treasurer.
                </p>
                <div className="space-y-2 text-sm text-blue-600">
                  <p>• PayCodes are case-insensitive</p>
                  <p>• Use the last name and email exactly as registered with your organization</p>
                  <p>• Contact your treasurer if you don't have your PayCode</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
