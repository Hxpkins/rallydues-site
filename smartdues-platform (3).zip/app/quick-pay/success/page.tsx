import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, Download, ArrowLeft } from "lucide-react"
import Link from "next/link"

interface SuccessPageProps {
  searchParams: { session_id?: string }
}

export default function QuickPaySuccessPage({ searchParams }: SuccessPageProps) {
  const { session_id } = searchParams

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-xl border-0">
            <CardHeader className="text-center pb-6">
              <div className="mx-auto w-16 h-16 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
              <CardTitle className="text-3xl text-gray-900 dark:text-white">Payment Successful!</CardTitle>
              <CardDescription className="text-lg">Your dues payment has been processed successfully.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
                <h3 className="font-semibold text-green-900 dark:text-green-100 mb-2">What happens next?</h3>
                <ul className="space-y-2 text-sm text-green-800 dark:text-green-200">
                  <li>• You'll receive a payment confirmation email shortly</li>
                  <li>• Your payment will be reflected in your organization's records</li>
                  <li>• A receipt will be available for download below</li>
                </ul>
              </div>

              {session_id && (
                <Suspense fallback={<div className="text-center">Loading receipt...</div>}>
                  <PaymentDetails sessionId={session_id} />
                </Suspense>
              )}

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button asChild className="flex-1">
                  <Link href="/quick-pay">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Make Another Payment
                  </Link>
                </Button>
                {session_id && (
                  <Button variant="outline" asChild className="flex-1 bg-transparent">
                    <a href={`/api/quick-pay/receipt?session_id=${session_id}`} target="_blank" rel="noreferrer">
                      <Download className="w-4 h-4 mr-2" />
                      Download Receipt
                    </a>
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

async function PaymentDetails({ sessionId }: { sessionId: string }) {
  // In a real implementation, you would fetch the session details from Stripe
  // For now, we'll show a placeholder
  return (
    <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
      <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Payment Details</h3>
      <div className="space-y-1 text-sm text-gray-600 dark:text-gray-300">
        <p>Session ID: {sessionId}</p>
        <p>Status: Completed</p>
        <p>Date: {new Date().toLocaleDateString()}</p>
      </div>
    </div>
  )
}
