import { SignUpForm } from "@/components/auth/signup-form"
import { DollarSign } from "lucide-react"
import Link from "next/link"

export default function SignUpPage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-slate-50">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <Link href="/" className="inline-flex items-center space-x-2 mb-8">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>
          <h1 className="text-3xl font-semibold tracking-tight text-[var(--text)]">Create your account</h1>
          <p className="text-[var(--subtext)] mt-2">Start managing your organization's dues today</p>
        </div>

        <SignUpForm />

        <div className="text-center text-[var(--subtext)]">
          Already have an account?{" "}
          <Link href="/signin" className="text-[var(--primary)] hover:underline font-medium text-orange-600">
            Sign in
          </Link>
        </div>
      </div>
    </div>
  )
}
