import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import RosterTable from "@/components/roster-table"
import ImportCsvDialog from "@/components/import-csv-dialog"
import { Button } from "@/components/ui/button"
import { Upload } from "lucide-react"

export default async function RosterPage() {
  const supabase = createClient()

  // Check authentication and role
  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser()

  if (authError || !user) {
    redirect("/auth/login")
  }

  // Get user's role and organization
  const { data: userData, error: userError } = await supabase
    .from("users")
    .select("role, organization_id")
    .eq("id", user.id)
    .single()

  if (userError || !userData || userData.role !== "treasurer") {
    redirect("/")
  }

  // Fetch all members in the organization
  const { data: members, error: membersError } = await supabase
    .from("users")
    .select("*")
    .eq("organization_id", userData.organization_id)
    .order("last_name", { ascending: true })

  if (membersError) {
    console.error("Error fetching members:", membersError)
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Member Roster</h1>
          <p className="text-slate-600 mt-2">Manage your organization's members and PayCodes</p>
        </div>
        <ImportCsvDialog>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white">
            <Upload className="w-4 h-4 mr-2" />
            Import CSV
          </Button>
        </ImportCsvDialog>
      </div>

      <RosterTable members={members || []} organizationId={userData.organization_id} />
    </div>
  )
}
