import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { ArrowLeft, Search, Plus, RefreshCw } from "lucide-react"
import Link from "next/link"
import { PayCodeGenerator } from "@/components/paycode-generator"

export default async function PayCodesPage() {
  // In a real implementation, you would fetch actual data from Supabase
  const mockMembers = [
    { id: "1", firstName: "John", lastName: "Smith", email: "john@example.com", paycode: "JS24", status: "active" },
    { id: "2", firstName: "Sarah", lastName: "Johnson", email: "sarah@example.com", paycode: "SJ25", status: "active" },
    { id: "3", firstName: "Mike", lastName: "Davis", email: "mike@example.com", paycode: null, status: "pending" },
    { id: "4", firstName: "Emily", lastName: "Wilson", email: "emily@example.com", paycode: "EW26", status: "active" },
  ]

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" asChild>
              <Link href="/admin">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">PayCode Management</h1>
              <p className="text-gray-600 dark:text-gray-300">Manage member PayCodes for Quick Pay feature</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Generate Missing
            </Button>
            <PayCodeGenerator />
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Label htmlFor="search">Search Members</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input id="search" placeholder="Search by name, email, or PayCode..." className="pl-10" />
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  All Members
                </Button>
                <Button variant="outline" size="sm">
                  Missing PayCodes
                </Button>
                <Button variant="outline" size="sm">
                  Active Only
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* PayCodes Table */}
        <Card>
          <CardHeader>
            <CardTitle>Member PayCodes</CardTitle>
            <CardDescription>
              PayCodes allow members and parents to pay dues without logging in. Each member needs a unique 4-character
              code.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mockMembers.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div>
                      <p className="font-medium">
                        {member.firstName} {member.lastName}
                      </p>
                      <p className="text-sm text-muted-foreground">{member.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    {member.paycode ? (
                      <div className="text-center">
                        <Badge variant="secondary" className="text-lg font-mono px-3 py-1">
                          {member.paycode}
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1">PayCode</p>
                      </div>
                    ) : (
                      <div className="text-center">
                        <Badge variant="outline" className="text-sm">
                          Not Assigned
                        </Badge>
                        <p className="text-xs text-muted-foreground mt-1">No PayCode</p>
                      </div>
                    )}

                    <Badge variant={member.status === "active" ? "default" : "secondary"}>{member.status}</Badge>

                    <div className="flex space-x-2">
                      {member.paycode ? (
                        <Button variant="outline" size="sm">
                          <RefreshCw className="w-4 h-4 mr-1" />
                          Regenerate
                        </Button>
                      ) : (
                        <Button size="sm">
                          <Plus className="w-4 h-4 mr-1" />
                          Generate
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Help Section */}
        <Card className="mt-6 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
          <CardContent className="pt-6">
            <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">PayCode Guidelines</h3>
            <ul className="space-y-1 text-sm text-blue-800 dark:text-blue-200">
              <li>• PayCodes are unique 4-character identifiers (letters and numbers)</li>
              <li>• Members use PayCode + Last Name to access Quick Pay</li>
              <li>• PayCodes are case-insensitive but displayed in uppercase</li>
              <li>• Share PayCodes with members via email or printed materials</li>
              <li>• Regenerate PayCodes if compromised or requested by member</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
