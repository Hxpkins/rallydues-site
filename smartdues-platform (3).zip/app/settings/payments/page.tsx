import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { PaymentSettingsForm } from "@/components/payment-settings-form"

export default async function PaymentSettingsPage() {
  const cookieStore = cookies()

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value
        },
      },
    },
  )

  // Check authentication
  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser()

  if (authError || !user) {
    redirect("/auth/login")
  }

  // Get user details and check role
  const { data: userData, error: userError } = await supabase
    .from("users")
    .select("role, organization_id")
    .eq("id", user.id)
    .single()

  if (userError || !userData || !["treasurer", "president", "exec"].includes(userData.role)) {
    redirect("/")
  }

  // Get organization payment settings
  const { data: orgData, error: orgError } = await supabase
    .from("organizations")
    .select("id, name, card_fee_percent, ach_fee_percent, ach_fee_cap_cents")
    .eq("id", userData.organization_id)
    .single()

  if (orgError || !orgData) {
    redirect("/")
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Payment Settings</h1>
          <p className="text-slate-600 mt-2">Configure processing fees and payment methods for {orgData.name}</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-lg p-6">
          <PaymentSettingsForm
            organizationId={orgData.id}
            initialSettings={{
              cardFeePercent: Number(orgData.card_fee_percent) * 100, // Convert to percentage
              achFeePercent: Number(orgData.ach_fee_percent) * 100,
              achFeeCap: Number(orgData.ach_fee_cap_cents) / 100, // Convert to dollars
            }}
          />
        </div>
      </div>
    </div>
  )
}
