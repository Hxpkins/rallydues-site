"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Shield, Lock, Eye, FileCheck, Mail, DollarSign } from "lucide-react"
import Link from "next/link"
import { Navigation } from "@/components/navigation"

export default function SecurityPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white border-b border-[var(--border)] sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>

          <Navigation />

          <div className="flex items-center space-x-3">
            <Link href="/signin">
              <Button
                variant="outline"
                size="sm"
                className="border border-[var(--border)] text-[var(--text)] hover:bg-[var(--surface-alt)] bg-transparent rounded-lg px-4 py-2.5"
              >
                Sign In
              </Button>
            </Link>
            <Link href="/quick-pay">
              <Button
                variant="outline"
                size="sm"
                className="border border-blue-200 hover:bg-blue-50 rounded-lg px-4 py-2.5 bg-blue-600 text-white"
              >
                Quick Pay
              </Button>
            </Link>
            <Link href="/signup">
              <Button
                size="sm"
                className="bg-[var(--accent)] text-white hover:brightness-110 rounded-lg px-4 py-2.5 bg-orange-500"
              >
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <section className="pt-12 px-4 bg-slate-50 pb-16">
        <div className="container mx-auto text-center max-w-4xl">
          <Badge variant="secondary" className="mb-4 bg-[var(--surface-alt)] text-[var(--text)]">
            Bank-Level Security
          </Badge>

          <h1 className="text-[40px] md:text-[56px] font-semibold leading-tight tracking-[-0.01em] text-[var(--text)] text-center mb-6">
            Security & <span className="text-black">Privacy</span> First
          </h1>

          <p className="mt-4 text-base md:text-lg text-[var(--subtext)] max-w-3xl mx-auto text-center mb-8">
            Your organization's financial data is protected with enterprise-grade security. Built on Stripe Connect with
            the same technology trusted by millions of businesses worldwide.
          </p>

          <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto">
            <Shield className="w-8 h-8 text-blue-600" />
          </div>
        </div>
      </section>

      <section className="px-4 bg-white py-16">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm text-center p-6">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-[var(--text)]">Data Encryption</h3>
              <p className="text-sm text-[var(--subtext)]">
                All data encrypted in transit and at rest using industry-standard AES-256 encryption with secure key
                management.
              </p>
            </div>

            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm text-center p-6">
              <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Eye className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-[var(--text)]">Privacy Protection</h3>
              <p className="text-sm text-[var(--subtext)]">
                GDPR and CCPA compliant. We never sell your data and provide complete transparency in data usage.
              </p>
            </div>

            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm text-center p-6">
              <div className="w-16 h-16 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <FileCheck className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-[var(--text)]">Compliance</h3>
              <p className="text-sm text-[var(--subtext)]">
                SOC 2 Type II certified with regular third-party security audits and penetration testing.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-semibold mb-6 text-[var(--text)]">
                Enterprise-Grade Security Infrastructure
              </h2>
              <p className="text-lg text-[var(--subtext)] mb-8">
                Built on Stripe Connect with multi-layered security controls, continuous monitoring, and instant threat
                detection to keep your organization's data safe.
              </p>

              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">PCI DSS Level 1 Compliance</h4>
                    <p className="text-sm text-[var(--subtext)]">
                      Highest level of payment card industry security standards
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">Multi-Factor Authentication</h4>
                    <p className="text-sm text-[var(--subtext)]">
                      Required for all admin accounts with support for TOTP and SMS
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">24/7 Security Monitoring</h4>
                    <p className="text-sm text-[var(--subtext)]">
                      Continuous threat detection with automated incident response
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">Data Isolation</h4>
                    <p className="text-sm text-[var(--subtext)]">
                      Complete multi-tenant isolation between organizations
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-[var(--border)] bg-blue-50 shadow-sm p-8">
              <div className="bg-white rounded-xl p-6 shadow-lg">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Shield className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-[var(--text)]">Security Certifications</h3>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-[var(--surface-alt)] rounded-lg">
                    <span className="text-sm font-medium text-[var(--text)]">SOC 2 Type II</span>
                    <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                      Certified
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-[var(--surface-alt)] rounded-lg">
                    <span className="text-sm font-medium text-[var(--text)]">ISO 27001</span>
                    <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                      Certified
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-[var(--surface-alt)] rounded-lg">
                    <span className="text-sm font-medium text-[var(--text)]">PCI DSS Level 1</span>
                    <Badge variant="secondary" className="bg-emerald-100 text-emerald-700">
                      Compliant
                    </Badge>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 px-4 bg-[var(--surface-alt)] bg-slate-50">
        <div className="container mx-auto text-center max-w-3xl">
          <Mail className="w-16 h-16 text-blue-600 mx-auto mb-6" />
          <h2 className="text-3xl md:text-4xl font-semibold mb-6 text-[var(--text)]">
            Security Questions or Concerns?
          </h2>
          <p className="text-lg text-[var(--subtext)] mb-8">
            Our security team is here to help. Report vulnerabilities, ask questions, or request security documentation.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="mailto:security@rallydues.com">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 rounded-lg py-2.5">
                Contact Security Team
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                size="lg"
                variant="outline"
                className="border border-[var(--border)] text-[var(--text)] hover:bg-[var(--surface-alt)] rounded-lg px-8 py-2.5 bg-transparent"
              >
                General Support
              </Button>
            </Link>
          </div>

          <p className="text-sm text-[var(--subtext)] mt-4">Response within 24 hours • Vulnerability reports welcome</p>
        </div>
      </section>

      <footer className="border-t border-[var(--border)] bg-[var(--surface-alt)] py-12 px-4 bg-slate-50">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
              </div>
              <p className="text-sm text-[var(--subtext)]">
                The modern dues management platform for Greek life organizations and membership groups.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-[var(--text)]">Product</h4>
              <ul className="space-y-2 text-sm text-[var(--subtext)]">
                <li>
                  <Link href="/pricing" className="hover:text-[var(--text)]">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="/quick-pay" className="hover:text-[var(--text)]">
                    Quick Pay
                  </Link>
                </li>
                <li>
                  <Link href="/demo/treasurer" className="hover:text-[var(--text)]">
                    Treasurer Demo
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-[var(--text)]">Company</h4>
              <ul className="space-y-2 text-sm text-[var(--subtext)]">
                <li>
                  <Link href="/about" className="hover:text-[var(--text)]">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-[var(--text)]">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/security" className="hover:text-[var(--text)]">
                    Security
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-[var(--text)]">Legal</h4>
              <ul className="space-y-2 text-sm text-[var(--subtext)]">
                <li>
                  <Link href="/legal/terms" className="hover:text-[var(--text)]">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/legal/privacy" className="hover:text-[var(--text)]">
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-[var(--border)] mt-8 pt-8 text-center text-sm text-[var(--subtext)]">
            <p>&copy; 2025 RallyDues. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
