import { Button } from "@/components/ui/button"
import { CheckCircle, Users, Zap, DollarSign, Target, Lightbulb, Lock, Heart } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white border-b border-[var(--border)] sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>

          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/pricing" className="text-sm text-[var(--subtext)] hover:text-[var(--text)] transition-colors">
              Pricing
            </Link>
            <Link
              href="/quick-pay"
              className="text-sm text-[var(--subtext)] hover:text-[var(--text)] transition-colors"
            >
              Quick Pay
            </Link>
            <Link
              href="/demo/treasurer"
              className="text-sm text-[var(--subtext)] hover:text-[var(--text)] transition-colors"
            >
              Demo
            </Link>
            <Link href="/contact" className="text-sm text-[var(--subtext)] hover:text-[var(--text)] transition-colors">
              Contact
            </Link>
          </nav>

          <div className="flex items-center space-x-3">
            <Link href="/signin">
              <Button
                variant="outline"
                size="sm"
                className="border border-[var(--border)] text-[var(--text)] hover:bg-[var(--surface-alt)] bg-transparent rounded-lg px-4 py-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)]"
              >
                Sign In
              </Button>
            </Link>
            <Link href="/signup">
              <Button
                size="sm"
                className="bg-orange-500 text-white hover:bg-orange-600 rounded-lg px-4 py-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-orange-500"
              >
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="py-12 px-4 bg-slate-50">
        <div className="container mx-auto max-w-4xl">
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-semibold mb-6 text-[var(--text)]">About RallyDues</h1>
            <p className="text-xl text-[var(--subtext)] max-w-3xl mx-auto">
              RallyDues is the modern way student groups, Greek organizations, and membership clubs manage money. We use
              AI to automate the busywork—so treasurers spend less time chasing payments and more time leading their
              chapters.
            </p>
          </div>

          <section className="mb-16">
            <div className="flex items-center mb-6">
              <Target className="w-8 h-8 text-[var(--primary)] mr-3 text-rose-600" />
              <h2 className="text-3xl font-semibold text-[var(--text)]">Our mission</h2>
            </div>
            <p className="text-lg text-[var(--subtext)] leading-relaxed">
              Deliver the simplest, smartest dues platform at the best price—accessible to every treasurer, from day
              one.
            </p>
          </section>

          <section className="mb-16">
            <div className="flex items-center mb-6">
              <Zap className="w-8 h-8 text-[var(--primary)] mr-3 text-yellow-500" />
              <h2 className="text-3xl font-semibold text-[var(--text)]">What we do</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-6">
                <h3 className="font-semibold mb-2 text-[var(--text)]">Collect faster</h3>
                <p className="text-sm text-[var(--subtext)]">
                  Share PayCodes and payment links that work on any device.
                </p>
              </div>
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-6">
                <h3 className="font-semibold mb-2 text-[var(--text)]">Automate the follow-up</h3>
                <p className="text-sm text-[var(--subtext)]">
                  Smart reminders nudge members at the right time and tone.
                </p>
              </div>
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-6">
                <h3 className="font-semibold mb-2 text-[var(--text)]">See everything at a glance</h3>
                <p className="text-sm text-[var(--subtext)]">
                  Real-time dashboards for collections, aging, cash-flow forecasts, and cohort trends.
                </p>
              </div>
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-6">
                <h3 className="font-semibold mb-2 text-[var(--text)]">Flexible plans</h3>
                <p className="text-sm text-[var(--subtext)]">
                  Installments, one-offs, and credits without spreadsheets.
                </p>
              </div>
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-6 md:col-span-2">
                <h3 className="font-semibold mb-2 text-[var(--text)]">Low-cost payments</h3>
                <p className="text-sm text-[var(--subtext)]">
                  Card (standard processing fees) and ACH with $0 platform fee.
                </p>
              </div>
            </div>
          </section>

          <section className="mb-16">
            <div className="flex items-center mb-6">
              <Lightbulb className="w-8 h-8 text-[var(--primary)] mr-3 text-blue-600" />
              <h2 className="text-3xl font-semibold text-[var(--text)]">Why AI matters here</h2>
            </div>
            <div className="space-y-6">
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-6">
                <h3 className="font-semibold mb-2 text-[var(--text)]">Predictive insights</h3>
                <p className="text-[var(--subtext)]">Spot who's likely to fall behind and intervene early.</p>
              </div>
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-6">
                <h3 className="font-semibold mb-2 text-[var(--text)]">Smart suggestions</h3>
                <p className="text-[var(--subtext)]">
                  "Send a second reminder now," "Offer a 2-installment plan," and other context-aware actions.
                </p>
              </div>
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-6">
                <h3 className="font-semibold mb-2 text-[var(--text)]">Auto-reconciliation</h3>
                <p className="text-[var(--subtext)]">Match payments to members and line items—no manual hunting.</p>
              </div>
              <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-6">
                <h3 className="font-semibold mb-2 text-[var(--text)]">Cleaner data</h3>
                <p className="text-[var(--subtext)]">Gentle anomaly checks reduce mistakes before they spread.</p>
              </div>
            </div>
          </section>

          <section className="mb-16 bg-[var(--surface-alt)] rounded-2xl p-8 px-0 py-0">
            <div className="flex items-center mb-6">
              <DollarSign className="w-8 h-8 text-[var(--primary)] mr-3 text-green-500" />
              <h2 className="text-3xl font-semibold text-[var(--text)]">Pricing you don't have to decode</h2>
            </div>
            <p className="text-lg text-[var(--subtext)] mb-6">
              Transparent, usage-based pricing with no setup fees and no long-term contracts. ACH has a $0 platform fee;
              cards carry standard processing fees. Start with a 30-day free trial—no credit card required.
            </p>
          </section>

          <section className="mb-16">
            <div className="flex items-center mb-6">
              <Lock className="w-8 h-8 text-[var(--primary)] mr-3 text-amber-900" />
              <h2 className="text-3xl font-semibold text-[var(--text)]">Security & privacy</h2>
            </div>
            <p className="text-lg text-[var(--subtext)] leading-relaxed">
              Bank-level security, least-privilege access, and encryption in transit and at rest. Role-based permissions
              keep member data private. We follow industry best practices so you can trust the numbers you see.
            </p>
          </section>

          <section className="mb-16">
            <div className="flex items-center mb-6">
              <Users className="w-8 h-8 text-[var(--primary)] mr-3 text-purple-800" />
              <h2 className="text-3xl font-semibold text-[var(--text)]">Who we serve</h2>
            </div>
            <p className="text-lg text-[var(--subtext)] leading-relaxed">
              Fraternities & sororities, club sports, student governments, professional societies, and community
              nonprofits—anywhere a treasurer needs clarity and control.
            </p>
          </section>

          <section className="mb-16">
            <div className="flex items-center mb-6">
              <Heart className="w-8 h-8 text-[var(--primary)] mr-3 text-pink-500" />
              <h2 className="text-3xl font-semibold text-[var(--text)]">Our story</h2>
            </div>
            <p className="text-lg text-[var(--subtext)] leading-relaxed mb-6">
              We were treasurers and officers first. After too many nights with spreadsheets and payment screenshots, we
              built the tool we wanted: fast to learn, hard to break, and smart enough to help.
            </p>

            <div className="bg-[var(--surface-alt)] rounded-2xl p-8">
              <h3 className="text-2xl font-semibold mb-4 text-[var(--text)]">How we work</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">Simple beats clever</h4>
                    <p className="text-sm text-[var(--subtext)]">Clear workflows win.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">Advice, not noise</h4>
                    <p className="text-sm text-[var(--subtext)]">AI should reduce clicks, not add them.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">Fair by default</h4>
                    <p className="text-sm text-[var(--subtext)]">Transparent pricing and plain-English policies.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">Built with users</h4>
                    <p className="text-sm text-[var(--subtext)]">We ship improvements weekly from real feedback.</p>
                  </div>
                </div>
              </div>
            </div>
          </section>

          <section className="text-center bg-[var(--primary)] rounded-2xl p-12 bg-blue-600 text-black">
            <h2 className="text-3xl font-semibold mb-4 text-slate-100">Let's get you set up</h2>
            <p className="text-lg mb-8 opacity-90 text-slate-100">
              Take the product for a spin with sample data, or connect your chapter in minutes. Start a free trial or
              book a quick demo—your future self (and your next treasurer) will thank you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/signup">
                <Button
                  size="lg"
                  className="bg-white text-[var(--primary)] hover:bg-gray-100 px-8 rounded-lg py-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white"
                >
                  Start Free Trial
                </Button>
              </Link>
              <Link href="/contact">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-white text-white hover:bg-white hover:text-[var(--primary)] rounded-lg px-8 py-2.5 bg-transparent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-white"
                >
                  Schedule Demo
                </Button>
              </Link>
            </div>
          </section>
        </div>
      </main>

      <footer className="border-t border-[var(--border)] bg-[var(--surface-alt)] py-12 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
              </div>
              <p className="text-sm text-[var(--subtext)]">
                The modern dues management platform for Greek life organizations and membership groups.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-[var(--text)]">Product</h4>
              <ul className="space-y-2 text-sm text-[var(--subtext)]">
                <li>
                  <Link href="/pricing" className="hover:text-[var(--text)]">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="/quick-pay" className="hover:text-[var(--text)]">
                    Quick Pay
                  </Link>
                </li>
                <li>
                  <Link href="/demo/treasurer" className="hover:text-[var(--text)]">
                    Treasurer Demo
                  </Link>
                </li>
                <li>
                  <Link href="/demo/member" className="hover:text-[var(--text)]">
                    Member Demo
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-[var(--text)]">Company</h4>
              <ul className="space-y-2 text-sm text-[var(--subtext)]">
                <li>
                  <Link href="/about" className="hover:text-[var(--text)]">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-[var(--text)]">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/security" className="hover:text-[var(--text)]">
                    Security
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-[var(--text)]">Legal</h4>
              <ul className="space-y-2 text-sm text-[var(--subtext)]">
                <li>
                  <Link href="/legal/terms" className="hover:text-[var(--text)]">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/legal/privacy" className="hover:text-[var(--text)]">
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-[var(--border)] mt-8 pt-8 text-center text-sm text-[var(--subtext)]">
            <p>&copy; 2025 RallyDues. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
