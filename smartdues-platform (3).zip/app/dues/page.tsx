import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { DuesManagement } from "@/components/dues-management"

export default async function DuesPage() {
  const supabase = createClient()

  // Check authentication and role
  const {
    data: { user },
    error: authError,
  } = await supabase.auth.getUser()

  if (authError || !user) {
    redirect("/auth/login")
  }

  // Get user profile to check role
  const { data: profile } = await supabase.from("users").select("role, organization_id").eq("id", user.id).single()

  if (!profile || !["treasurer", "president", "exec"].includes(profile.role)) {
    redirect("/")
  }

  // Fetch dues cycles for this organization
  const { data: cycles } = await supabase
    .from("dues_cycles")
    .select("*")
    .eq("organization_id", profile.organization_id)
    .order("created_at", { ascending: false })

  // Fetch organization details
  const { data: organization } = await supabase
    .from("organizations")
    .select("*")
    .eq("id", profile.organization_id)
    .single()

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">Dues Management</h1>
          <p className="text-slate-600 mt-2">Create dues cycles and generate invoices for members</p>
        </div>

        <DuesManagement
          cycles={cycles || []}
          organizationId={profile.organization_id}
          hasStripeConnect={!!organization?.stripe_account_id}
        />
      </div>
    </div>
  )
}
