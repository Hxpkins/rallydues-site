import { Button } from "@/components/ui/button"
import { Home, CreditCard, AlertCircle } from "lucide-react"
import Link from "next/link"

export default function NotFound() {
  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-4">
      <div className="text-center max-w-md mx-auto">
        {/* Friendly illustration */}
        <div className="w-24 h-24 bg-[var(--surface-alt)] rounded-full flex items-center justify-center mx-auto mb-8">
          <AlertCircle className="w-12 h-12 text-[var(--subtext)]" />
        </div>

        {/* Headline */}
        <h1 className="text-3xl font-semibold text-[var(--text)] mb-4">Page not found</h1>

        {/* Body copy */}
        <p className="text-lg text-[var(--subtext)] mb-8">
          Sorry, we couldn't find the page you're looking for. It might have been moved, deleted, or you entered the
          wrong URL.
        </p>

        {/* Action buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/">
            <Button
              size="lg"
              className="bg-[var(--primary)] hover:bg-[var(--primary)]/90 text-white px-6 py-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)] rounded-lg"
            >
              <Home className="w-4 h-4 mr-2" />
              Go Home
            </Button>
          </Link>
          <Link href="/quick-pay">
            <Button
              size="lg"
              variant="outline"
              className="border border-[var(--border)] text-[var(--text)] hover:bg-[var(--surface-alt)] bg-transparent px-6 py-3 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)] rounded-lg"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Quick Pay
            </Button>
          </Link>
        </div>

        {/* Additional help */}
        <p className="text-sm text-[var(--subtext)] mt-8">
          Need help?{" "}
          <Link
            href="/contact"
            className="text-[var(--primary)] hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)] rounded"
          >
            Contact us
          </Link>
        </p>
      </div>
    </div>
  )
}
