import { SignInForm } from "@/components/auth/signin-form"
import { DollarSign } from "lucide-react"
import Link from "next/link"

export default function SignInPage() {
  return (
    <div className="min-h-screen flex items-center justify-center px-4 bg-slate-50">
      <div className="w-full max-w-md space-y-8 bg-white border-gray-600 border px-3 py-3.5">
        <div className="text-center">
          <Link href="/" className="inline-flex items-center space-x-2 mb-8">
            <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>
          <h1 className="text-3xl font-semibold tracking-tight text-[var(--text)]">Welcome back</h1>
          <p className="text-[var(--subtext)] mt-2">Sign in to your organization's account</p>
        </div>

        <SignInForm />

        <div className="text-center text-[var(--subtext)]">
          Don't have an account?{" "}
          <Link href="/signup" className="text-[var(--primary)] hover:underline font-medium text-orange-600">
            Start free trial
          </Link>
        </div>
      </div>
    </div>
  )
}
