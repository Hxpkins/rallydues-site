"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { DollarSign, Mail, Phone, MapPin, Loader2, CheckCircle, AlertTriangle, X } from "lucide-react"
import Link from "next/link"
import { Navigation } from "@/components/navigation"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    organization: "",
    subject: "",
    message: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [status, setStatus] = useState<"idle" | "success" | "error" | "unavailable">("idle")
  const [errorMessage, setErrorMessage] = useState("")
  const [showEnvBanner, setShowEnvBanner] = useState(false)

  // Check if email is configured on mount
  useEffect(() => {
    const checkEmailConfig = async () => {
      try {
        const response = await fetch("/api/contact", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ name: "test", email: "test@test.com", subject: "test", message: "test" }),
        })

        if (response.status === 503) {
          setShowEnvBanner(true)
        }
      } catch (error) {
        // Ignore errors from this check
      }
    }

    checkEmailConfig()
  }, [])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setStatus("idle")
    setErrorMessage("")

    try {
      const response = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      })

      const data = await response.json()

      if (data.ok) {
        setStatus("success")
        setFormData({ name: "", email: "", organization: "", subject: "", message: "" })
      } else {
        if (response.status === 503) {
          setStatus("unavailable")
        } else {
          setStatus("error")
          setErrorMessage(data.error || "An error occurred")
        }
      }
    } catch (error) {
      console.error("Contact form error:", error)
      setStatus("error")
      setErrorMessage("Network error. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange =
    (field: keyof typeof formData) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setFormData((prev) => ({
        ...prev,
        [field]: e.target.value,
      }))
    }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>

          <Navigation />

          <div className="flex items-center space-x-4">
            <Link href="/signin">
              <Button className="border-black border" variant="ghost" size="sm">
                Sign In
              </Button>
            </Link>
            <Link href="/signup">
              <Button size="sm" className="bg-orange-500 hover:bg-orange-600">
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-6 py-16 bg-slate-50">
        {/* Environment variable banner */}
        {showEnvBanner && (
          <Alert className="mb-8 border-orange-200 bg-orange-50">
            <AlertTriangle className="h-4 w-4 text-orange-600" />
            <AlertDescription className="text-orange-800 flex items-center justify-between">
              <span>Email is temporarily unavailable. Please try again later.</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowEnvBanner(false)}
                className="h-auto p-1 text-orange-600 hover:text-orange-800"
              >
                <X className="h-4 w-4" />
              </Button>
            </AlertDescription>
          </Alert>
        )}

        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-[var(--text)]">Get in touch</h1>
          <p className="text-xl text-[var(--subtext)] mb-8 max-w-2xl mx-auto">
            Questions about RallyDues? We'd love to help you streamline your organization's financial management.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2">
          {/* Contact Form */}
          <Card className="border-[var(--border)] bg-[var(--surface)]">
            <CardHeader>
              <CardTitle className="text-[var(--text)]">Send us a message</CardTitle>
            </CardHeader>
            <CardContent>
              {status === "success" && (
                <Alert className="mb-6 border-green-200 bg-green-50">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800">
                    Sent! You'll receive a confirmation at {formData.email}. We typically reply within 48 hours.
                  </AlertDescription>
                </Alert>
              )}

              {status === "unavailable" && (
                <Alert className="mb-6 border-orange-200 bg-orange-50">
                  <AlertTriangle className="h-4 w-4 text-orange-600" />
                  <AlertDescription className="text-orange-800">
                    Email temporarily unavailable. Please try again later.
                  </AlertDescription>
                </Alert>
              )}

              {status === "error" && (
                <Alert variant="destructive" className="mb-6">
                  <AlertDescription>
                    {errorMessage || "Sorry, there was an error sending your message. Please try again."}
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium mb-2 text-[var(--text)]">
                      Name
                    </label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={handleInputChange("name")}
                      placeholder="Your name"
                      required
                      disabled={isLoading}
                      maxLength={100}
                      className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)]"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium mb-2 text-[var(--text)]">
                      Email
                    </label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={handleInputChange("email")}
                      placeholder="your@email.com"
                      required
                      disabled={isLoading}
                      className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)]"
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="organization" className="block text-sm font-medium mb-2 text-[var(--text)]">
                    Organization (Optional)
                  </label>
                  <Input
                    id="organization"
                    value={formData.organization}
                    onChange={handleInputChange("organization")}
                    placeholder="Your fraternity, sorority, or organization"
                    disabled={isLoading}
                    maxLength={120}
                    className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)]"
                  />
                </div>
                <div>
                  <label htmlFor="subject" className="block text-sm font-medium mb-2 text-[var(--text)]">
                    Subject
                  </label>
                  <Input
                    id="subject"
                    value={formData.subject}
                    onChange={handleInputChange("subject")}
                    placeholder="How can we help?"
                    required
                    disabled={isLoading}
                    maxLength={120}
                    className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)]"
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium mb-2 text-[var(--text)]">
                    Message
                  </label>
                  <Textarea
                    id="message"
                    value={formData.message}
                    onChange={handleInputChange("message")}
                    placeholder="Tell us more about your needs..."
                    className="h-32 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)]"
                    required
                    disabled={isLoading}
                    maxLength={5000}
                  />
                </div>
                <Button
                  type="submit"
                  className="w-full bg-[var(--primary)] hover:bg-[var(--primary)]/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)]"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Sending...
                    </>
                  ) : (
                    "Send Message"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <div className="space-y-8">
            <Card className="border-[var(--border)] bg-[var(--surface)]">
              <CardHeader>
                <CardTitle className="text-[var(--text)]">Other ways to reach us</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1 text-[var(--text)]">Email Support</h3>
                    <p className="text-sm text-[var(--subtext)] mb-2">
                      Get help with your account or technical questions
                    </p>
                    <a href="mailto:support@rallydues.com" className="text-sm text-[var(--primary)] hover:underline">
                      support@rallydues.com
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Phone className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1 text-[var(--text)]">Sales & Demos</h3>
                    <p className="text-sm text-[var(--subtext)] mb-2">
                      Schedule a personalized demo for your organization
                    </p>
                    <a href="tel:+1-555-RALLY-DUE" className="text-sm text-[var(--primary)] hover:underline">
                      +1 (555) RALLY-DUE
                    </a>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-1 text-[var(--text)]">Business Address</h3>
                    <p className="text-sm text-[var(--subtext)]">
                      10869 N Scottsdale Rd Suite 103 PMB 278
                      <br />
                      Scottsdale, AZ 85254
                      <br />
                      United States
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-[var(--border)] bg-[var(--surface)]">
              <CardHeader>
                <CardTitle className="text-[var(--text)]">Frequently Asked Questions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-sm mb-1 text-[var(--text)]">How quickly can we get started?</h4>
                  <p className="text-sm text-[var(--subtext)]">
                    Most organizations are up and running within 24 hours of signing up.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-sm mb-1 text-[var(--text)]">Do you offer training?</h4>
                  <p className="text-sm text-[var(--subtext)]">
                    Yes! We provide onboarding sessions and ongoing support to ensure success.
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-sm mb-1 text-[var(--text)]">Can you help with data migration?</h4>
                  <p className="text-sm text-[var(--subtext)]">
                    Absolutely. We'll help you import your existing member data and payment history.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
