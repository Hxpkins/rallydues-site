import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, DollarSign, CreditCard } from "lucide-react"
import Link from "next/link"
import { Navigation } from "@/components/navigation"

export const metadata = { title: "Pricing — RallyDues" }

export default function PricingPage() {
  return (
    <div className="min-h-screen bg-[var(--background)]">
      {/* Header */}
      <header className="border-b border-[var(--border)] bg-[var(--surface)] sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 rounded-lg bg-[var(--primary)] flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>

          <Navigation />

          <div className="flex items-center space-x-4">
            <Link href="/signin">
              <Button variant="ghost" size="sm" className="border border-[var(--border)]">
                Sign In
              </Button>
            </Link>
            <Link href="/quickpay">
              <Button variant="outline" size="sm">
                Quick Pay
              </Button>
            </Link>
            <Link href="/signup">
              <Button size="sm" className="bg-[var(--primary)] hover:bg-[var(--primary)]/90">
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-6 py-16">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 text-[var(--text)]">Simple, transparent pricing</h1>
          <p className="text-xl text-[var(--subtext)] mb-10 max-w-2xl mx-auto">
            Clear, simple pricing for chapters and members. No hidden fees, no setup costs.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-3 mb-16">
          {/* Starter Plan */}
          <Card className="relative border-[var(--border)] bg-[var(--surface)]">
            <CardHeader className="text-center pb-8">
              <h2 className="text-2xl font-semibold mb-2 text-[var(--text)]">Starter</h2>
              <p className="text-[var(--subtext)] mb-4">Perfect for smaller chapters</p>
              <div className="text-4xl font-bold mb-2 text-[var(--text)]">
                $29<span className="text-lg font-normal text-[var(--subtext)]">/mo</span>
              </div>
              <p className="text-sm text-[var(--subtext)]">Up to 25 members</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Member portal & dashboard</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Dues cycles & invoicing</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Stripe checkout integration</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Basic payment plans</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Email support</span>
                </li>
              </ul>
              <Link href="/signup">
                <Button variant="outline" className="w-full bg-transparent">
                  Start Free Trial
                </Button>
              </Link>
            </CardContent>
          </Card>

          {/* Professional Plan */}
          <Card className="relative border-[var(--primary)] shadow-lg bg-[var(--surface)]">
            <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[var(--primary)] text-white">
              Most Popular
            </Badge>
            <CardHeader className="text-center pb-8">
              <h2 className="text-2xl font-semibold mb-2 text-[var(--text)]">Professional</h2>
              <p className="text-[var(--subtext)] mb-4">For growing organizations</p>
              <div className="text-4xl font-bold mb-2 text-[var(--text)]">
                $79<span className="text-lg font-normal text-[var(--subtext)]">/mo</span>
              </div>
              <p className="text-sm text-[var(--subtext)]">Up to 75 members</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Everything in Starter</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Advanced payment plans</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">CSV roster import</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Automated reminders</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Financial analytics</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Priority support</span>
                </li>
              </ul>
              <Link href="/signup">
                <Button className="w-full bg-[var(--primary)] hover:bg-[var(--primary)]/90">Start Free Trial</Button>
              </Link>
            </CardContent>
          </Card>

          {/* Enterprise Plan */}
          <Card className="relative border-[var(--border)] bg-[var(--surface)]">
            <CardHeader className="text-center pb-8">
              <h2 className="text-2xl font-semibold mb-2 text-[var(--text)]">Enterprise</h2>
              <p className="text-[var(--subtext)] mb-4">For large organizations</p>
              <div className="text-4xl font-bold mb-2 text-[var(--text)]">
                $149<span className="text-lg font-normal text-[var(--subtext)]">/mo</span>
              </div>
              <p className="text-sm text-[var(--subtext)]">Unlimited members</p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3 mb-8">
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Everything in Professional</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Custom branding</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Advanced role management</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">API access</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Dedicated account manager</span>
                </li>
                <li className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-sm text-[var(--text)]">Phone & chat support</span>
                </li>
              </ul>
              <Link href="/signup">
                <Button variant="outline" className="w-full bg-transparent">
                  Start Free Trial
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        <div className="mb-16">
          <Card className="bg-blue-50 border-blue-200 max-w-md mx-auto">
            <CardContent className="pt-6 text-center">
              <CreditCard className="w-8 h-8 text-blue-600 mx-auto mb-3" />
              <h3 className="font-semibold text-blue-900 mb-2">Processing Fees</h3>
              <div className="text-sm text-blue-700 space-y-1">
                <p>Credit Card: 3.1% processing surcharge.</p>
                <p>ACH/Bank Transfer: No processing surcharge.</p>
                <p>No processing fee(s) on organization's monthly subscription.</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Section */}
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-8 text-[var(--text)]">Frequently Asked Questions</h2>
          <div className="grid gap-6 md:grid-cols-2 text-left max-w-4xl mx-auto">
            <div>
              <h3 className="font-semibold mb-2 text-[var(--text)]">What payment methods do you accept?</h3>
              <p className="text-sm text-[var(--subtext)]">
                Cards and bank transfers (ACH). Apple Pay and Google Pay show automatically on supported devices.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-[var(--text)]">Is there a setup fee?</h3>
              <p className="text-sm text-[var(--subtext)]">
                No setup fees, no hidden costs. Just simple monthly pricing based on your member count.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-[var(--text)]">Can I change plans anytime?</h3>
              <p className="text-sm text-[var(--subtext)]">
                Yes, you can upgrade or downgrade your plan at any time. Changes take effect on your next billing cycle.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-2 text-[var(--text)]">What about member transaction fees?</h3>
              <p className="text-sm text-[var(--subtext)]">
                Credit Card: 3.1% surcharge. ACH/Bank Transfer: no surcharge to the member.
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-[var(--surface)] border-t border-[var(--border)] py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div>
              <h3 className="font-semibold mb-4 text-[var(--text)]">Product</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/pricing" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="/features" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Features
                  </Link>
                </li>
                <li>
                  <Link href="/integrations" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Integrations
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-[var(--text)]">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/security" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Security
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-[var(--text)]">Resources</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/help" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Help Center
                  </Link>
                </li>
                <li>
                  <Link href="/guides" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Guides
                  </Link>
                </li>
                <li>
                  <Link href="/api" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    API Docs
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4 text-[var(--text)]">Legal</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/privacy" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Privacy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Terms
                  </Link>
                </li>
                <li>
                  <Link href="/cookies" className="text-sm text-[var(--subtext)] hover:text-[var(--text)]">
                    Cookies
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-[var(--border)] mt-8 pt-8 text-center">
            <p className="text-sm text-[var(--subtext)]">© 2024 RallyDues. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
