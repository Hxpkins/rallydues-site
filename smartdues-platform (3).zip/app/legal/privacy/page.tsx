import { DollarSign } from "lucide-react"
import Link from "next/link"

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-[var(--border)] sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)] rounded-lg"
          >
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <h1 className="text-3xl font-semibold mb-8 text-[var(--text)]">Privacy Policy</h1>

        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-8">
          <p className="text-sm text-orange-800">
            <strong>Important:</strong> This is not legal advice. This policy is provided as MVP copy for demonstration
            purposes. Consult with a qualified attorney before using in production.
          </p>
        </div>

        <div className="prose prose-slate max-w-none text-[var(--text)]">
          <p className="text-[var(--subtext)] mb-6">Effective Date: January 15, 2025</p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">What This Policy Covers</h2>
          <p className="mb-4 text-[var(--subtext)]">
            This policy explains how RallyDues collects, uses, and protects your information when you use our dues
            management platform.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">Information We Collect</h2>
          <p className="mb-4 text-[var(--subtext)]">We collect information in these ways:</p>

          <h3 className="text-lg font-semibold mb-2 text-[var(--text)]">Information You Give Us</h3>
          <ul className="mb-4 ml-6 list-disc text-[var(--subtext)]">
            <li>Account details (name, email, organization info)</li>
            <li>Member rosters and contact information</li>
            <li>Payment information (processed securely by Stripe)</li>
            <li>Messages you send us through contact forms</li>
          </ul>

          <h3 className="text-lg font-semibold mb-2 text-[var(--text)]">Information We Collect Automatically</h3>
          <ul className="mb-4 ml-6 list-disc text-[var(--subtext)]">
            <li>How you use our platform (pages visited, features used)</li>
            <li>Device information (browser type, IP address)</li>
            <li>Cookies and similar tracking technologies</li>
          </ul>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">How We Use Your Information</h2>
          <p className="mb-4 text-[var(--subtext)]">We use your information to:</p>
          <ul className="mb-4 ml-6 list-disc text-[var(--subtext)]">
            <li>Provide and improve our dues management service</li>
            <li>Process payments and send receipts</li>
            <li>Send important updates about your account</li>
            <li>Provide customer support</li>
            <li>Prevent fraud and ensure security</li>
          </ul>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">Information Sharing</h2>
          <p className="mb-4 text-[var(--subtext)]">
            We don't sell your personal information. We may share information with:
          </p>
          <ul className="mb-4 ml-6 list-disc text-[var(--subtext)]">
            <li>
              <strong>Stripe:</strong> For secure payment processing
            </li>
            <li>
              <strong>Service providers:</strong> Who help us operate the platform
            </li>
            <li>
              <strong>Legal requirements:</strong> When required by law
            </li>
          </ul>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">Payment Information</h2>
          <p className="mb-4 text-[var(--subtext)]">
            All payment processing is handled by Stripe, a PCI-compliant payment processor. We don't store your full
            credit card numbers or bank account details on our servers.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">Data Security</h2>
          <p className="mb-4 text-[var(--subtext)]">
            We use industry-standard security measures to protect your information, including:
          </p>
          <ul className="mb-4 ml-6 list-disc text-[var(--subtext)]">
            <li>Encryption of data in transit and at rest</li>
            <li>Regular security audits and monitoring</li>
            <li>Limited access to personal information</li>
            <li>Secure hosting infrastructure</li>
          </ul>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">Your Rights</h2>
          <p className="mb-4 text-[var(--subtext)]">You can:</p>
          <ul className="mb-4 ml-6 list-disc text-[var(--subtext)]">
            <li>Access and update your account information</li>
            <li>Delete your account and associated data</li>
            <li>Opt out of non-essential communications</li>
            <li>Request a copy of your data</li>
          </ul>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">Data Retention</h2>
          <p className="mb-4 text-[var(--subtext)]">
            We keep your information as long as your account is active or as needed to provide services. Financial
            records may be retained longer for legal and tax purposes.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">Changes to This Policy</h2>
          <p className="mb-4 text-[var(--subtext)]">
            We may update this privacy policy occasionally. We'll notify you of significant changes via email or through
            the platform.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">Contact Us</h2>
          <p className="mb-4 text-[var(--subtext)]">
            Questions about this privacy policy? Contact us at{" "}
            <a href="mailto:support@rallydues.com" className="text-[var(--primary)] hover:underline">
              support@rallydues.com
            </a>
          </p>

          <div className="border-t border-[var(--border)] pt-8 mt-8">
            <p className="text-sm text-[var(--subtext)]">
              RallyDues • 123 University Ave, College Town, ST 12345 • United States
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
