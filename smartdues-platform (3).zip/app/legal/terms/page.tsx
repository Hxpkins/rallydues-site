import { DollarSign } from "lucide-react"
import Link from "next/link"

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b border-[var(--border)] sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link
            href="/"
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-[var(--primary)] rounded-lg"
          >
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <h1 className="text-3xl font-semibold mb-8 text-[var(--text)]">Terms of Service</h1>

        <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-8">
          <p className="text-sm text-orange-800">
            <strong>Important:</strong> This is not legal advice. These terms are provided as MVP copy for demonstration
            purposes. Consult with a qualified attorney before using in production.
          </p>
        </div>

        <div className="prose prose-slate max-w-none text-[var(--text)]">
          <p className="text-[var(--subtext)] mb-6">Effective Date: January 15, 2025</p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">1. What RallyDues Does</h2>
          <p className="mb-4 text-[var(--subtext)]">
            RallyDues is a dues management platform for fraternities, sororities, and membership organizations. We help
            you collect payments, manage members, and track finances online.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">2. Using Our Service</h2>
          <p className="mb-4 text-[var(--subtext)]">
            By using RallyDues, you agree to these terms. You must be 18 or older to create an account. You're
            responsible for keeping your account secure and for all activity under your account.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">3. Payments</h2>
          <p className="mb-4 text-[var(--subtext)]">
            All payments are processed securely through Stripe. We charge processing fees as disclosed during checkout:
          </p>
          <ul className="mb-4 ml-6 list-disc text-[var(--subtext)]">
            <li>Credit Card: 3.1% processing surcharge</li>
            <li>ACH/Bank Transfer: No processing surcharge</li>
          </ul>
          <p className="mb-4 text-[var(--subtext)]">
            Payments are final. We don't offer refunds in version 1 of our platform.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">4. Your Data</h2>
          <p className="mb-4 text-[var(--subtext)]">
            We collect information you provide (like member rosters and payment details) to operate our service. We
            don't sell your data to third parties. See our Privacy Policy for details.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">5. Service Availability</h2>
          <p className="mb-4 text-[var(--subtext)]">
            We work hard to keep RallyDues running smoothly, but we can't guarantee 100% uptime. We may need to update
            or maintain the service occasionally.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">6. Ending Your Account</h2>
          <p className="mb-4 text-[var(--subtext)]">
            You can cancel your account anytime. We may suspend accounts that violate these terms. When you cancel,
            you'll still have access until the end of your billing period.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">7. Liability</h2>
          <p className="mb-4 text-[var(--subtext)]">
            RallyDues is provided "as is." We're not liable for indirect damages or losses. Our total liability is
            limited to the amount you paid us in the past 12 months.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">8. Changes to Terms</h2>
          <p className="mb-4 text-[var(--subtext)]">
            We may update these terms occasionally. We'll notify you of significant changes via email or through the
            platform.
          </p>

          <h2 className="text-xl font-semibold mb-4 text-[var(--text)]">9. Contact Us</h2>
          <p className="mb-4 text-[var(--subtext)]">
            Questions about these terms? Contact us at{" "}
            <a href="mailto:support@rallydues.com" className="text-[var(--primary)] hover:underline">
              support@rallydues.com
            </a>
          </p>

          <div className="border-t border-[var(--border)] pt-8 mt-8">
            <p className="text-sm text-[var(--subtext)]">
              RallyDues • 123 University Ave, College Town, ST 12345 • United States
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
