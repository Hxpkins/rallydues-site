import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { DollarSign, Users, CreditCard, BarChart3 } from "lucide-react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default async function HomePage() {
  const supabase = createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/signin")
  }

  // Get user's organization info
  const { data: userData } = await supabase
    .from("users")
    .select(`
      role,
      organizations (
        name,
        chapter_slug
      )
    `)
    .eq("id", user.id)
    .single()

  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white border-b border-[var(--border)]">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between max-w-6xl">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[var(--text)]">SmartDues</span>
          </div>

          <div className="flex items-center space-x-4">
            <span className="text-sm text-[var(--subtext)]">
              {userData?.organizations?.name} • {userData?.role}
            </span>
            <form action="/api/auth/signout" method="post">
              <Button variant="outline" size="sm" className="rounded-lg px-4 py-2.5 bg-transparent">
                Sign Out
              </Button>
            </form>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-[var(--text)] mb-2">Welcome back, {user.email?.split("@")[0]}!</h1>
          <p className="text-[var(--subtext)]">
            Manage your organization's dues and member information from your dashboard.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="rounded-2xl border border-[var(--border)] bg-white shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--subtext)]">Total Collected</p>
                <p className="text-2xl font-semibold text-emerald-600">$0</p>
              </div>
              <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center">
                <CreditCard className="w-6 h-6 text-emerald-600" />
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-[var(--border)] bg-white shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--subtext)]">Outstanding</p>
                <p className="text-2xl font-semibold text-orange-600">$0</p>
              </div>
              <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-[var(--border)] bg-white shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--subtext)]">Active Members</p>
                <p className="text-2xl font-semibold text-blue-600">0</p>
              </div>
              <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-[var(--border)] bg-white shadow-sm p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-[var(--subtext)]">Dues Cycles</p>
                <p className="text-2xl font-semibold text-purple-600">0</p>
              </div>
              <div className="w-12 h-12 bg-purple-50 rounded-full flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="rounded-2xl border border-[var(--border)] bg-white shadow-sm p-6">
            <h3 className="text-lg font-semibold text-[var(--text)] mb-2">Manage Members</h3>
            <p className="text-sm text-[var(--subtext)] mb-4">
              Import your roster and manage member information and PayCodes.
            </p>
            <Link href="/roster">
              <Button className="bg-[var(--primary)] hover:brightness-110 text-white rounded-lg px-4 py-2.5">
                View Roster
              </Button>
            </Link>
          </div>

          <div className="rounded-2xl border border-[var(--border)] bg-white shadow-sm p-6">
            <h3 className="text-lg font-semibold text-[var(--text)] mb-2">Create Dues Cycle</h3>
            <p className="text-sm text-[var(--subtext)] mb-4">
              Set up new dues cycles and generate invoices for your members.
            </p>
            <Link href="/dues">
              <Button className="bg-[var(--accent)] hover:brightness-110 text-white rounded-lg px-4 py-2.5">
                Manage Dues
              </Button>
            </Link>
          </div>

          <div className="rounded-2xl border border-[var(--border)] bg-white shadow-sm p-6">
            <h3 className="text-lg font-semibold text-[var(--text)] mb-2">Payment Settings</h3>
            <p className="text-sm text-[var(--subtext)] mb-4">
              Configure processing fees and payment methods for your organization.
            </p>
            <Link href="/settings/payments">
              <Button
                variant="outline"
                className="border border-[var(--border)] text-[var(--text)] hover:bg-[var(--surface-alt)] rounded-lg px-4 py-2.5 bg-transparent"
              >
                Settings
              </Button>
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
