import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function PUT(request: NextRequest) {
  try {
    const cookieStore = cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          get(name: string) {
            return cookieStore.get(name)?.value
          },
        },
      },
    )

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user details and check role
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("role, organization_id")
      .eq("id", user.id)
      .single()

    if (userError || !userData || !["treasurer", "president", "exec"].includes(userData.role)) {
      return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
    }

    const body = await request.json()
    const { organizationId, cardFeePercent, achFeePercent, achFeeCap } = body

    // Verify user belongs to this organization
    if (userData.organization_id !== organizationId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 403 })
    }

    // Validate input
    if (cardFeePercent < 0 || cardFeePercent > 0.1) {
      return NextResponse.json({ error: "Card fee must be between 0% and 10%" }, { status: 400 })
    }

    if (achFeePercent < 0 || achFeePercent > 0.05) {
      return NextResponse.json({ error: "ACH fee must be between 0% and 5%" }, { status: 400 })
    }

    if (achFeeCap < 0 || achFeeCap > 5000) {
      return NextResponse.json({ error: "ACH cap must be between $0 and $50" }, { status: 400 })
    }

    // Update organization settings
    const { error: updateError } = await supabase
      .from("organizations")
      .update({
        card_fee_percent: cardFeePercent,
        ach_fee_percent: achFeePercent,
        ach_fee_cap_cents: achFeeCap,
        updated_at: new Date().toISOString(),
      })
      .eq("id", organizationId)

    if (updateError) {
      console.error("Error updating payment settings:", updateError)
      return NextResponse.json({ error: "Failed to update settings" }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Payment settings API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
