import { NextResponse } from "next/server"
import Stripe from "stripe"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
})

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url)
    const sessionId = searchParams.get("session_id")

    if (!sessionId) {
      return NextResponse.json({ error: "Session ID is required" }, { status: 400 })
    }

    // Retrieve the checkout session from Stripe
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ["payment_intent", "line_items"],
    })

    if (!session) {
      return NextResponse.json({ error: "Session not found" }, { status: 404 })
    }

    // Generate a simple receipt (in production, you might want to use a PDF library)
    const receiptHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Payment Receipt</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 20px; }
            .details { margin: 20px 0; }
            .row { display: flex; justify-content: space-between; margin: 10px 0; }
            .total { font-weight: bold; font-size: 1.2em; border-top: 1px solid #333; padding-top: 10px; }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>SmartDues Payment Receipt</h1>
            <p>Receipt #${session.id}</p>
          </div>
          <div class="details">
            <div class="row">
              <span>Date:</span>
              <span>${new Date(session.created * 1000).toLocaleDateString()}</span>
            </div>
            <div class="row">
              <span>Payer Email:</span>
              <span>${session.customer_email}</span>
            </div>
            <div class="row">
              <span>Member:</span>
              <span>${session.metadata?.member_name}</span>
            </div>
            <div class="row">
              <span>Organization:</span>
              <span>${session.metadata?.organization_name}</span>
            </div>
            <div class="row">
              <span>Description:</span>
              <span>${session.metadata?.dues_name}</span>
            </div>
            <div class="row total">
              <span>Amount Paid:</span>
              <span>$${(session.amount_total! / 100).toFixed(2)}</span>
            </div>
          </div>
          <p style="text-align: center; color: #666; margin-top: 40px;">
            Thank you for your payment!
          </p>
        </body>
      </html>
    `

    return new NextResponse(receiptHtml, {
      headers: {
        "Content-Type": "text/html",
        "Content-Disposition": `inline; filename="receipt-${sessionId}.html"`,
      },
    })
  } catch (error) {
    console.error("Receipt generation error:", error)
    return NextResponse.json({ error: "Failed to generate receipt" }, { status: 500 })
  }
}
