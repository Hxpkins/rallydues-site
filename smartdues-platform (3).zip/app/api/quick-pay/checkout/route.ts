import { NextResponse } from "next/server"
import Stripe from "stripe"
import { createAdminClient } from "@/lib/supabase/admin"
import { calculateTotalWithFees, type PayMethod } from "@/lib/fees"

// Initialize Stripe with secret key
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
})

// Rate limiting map (in production, use Redis or similar)
const rateLimitMap = new Map<string, { count: number; resetTime: number }>()

function checkRateLimit(ip: string): boolean {
  const now = Date.now()
  const windowMs = 15 * 60 * 1000 // 15 minutes
  const maxRequests = 10 // Max 10 requests per 15 minutes per IP

  const current = rateLimitMap.get(ip)

  if (!current || now > current.resetTime) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + windowMs })
    return true
  }

  if (current.count >= maxRequests) {
    return false
  }

  current.count++
  return true
}

export async function POST(req: Request) {
  try {
    // Rate limiting
    const forwarded = req.headers.get("x-forwarded-for")
    const ip = forwarded ? forwarded.split(",")[0] : "127.0.0.1"

    if (!checkRateLimit(ip)) {
      return NextResponse.json({ error: "Too many requests. Please try again later." }, { status: 429 })
    }

    const body = await req.json()
    const { memberDuesId, payerEmail, memberName, organizationName, duesName, method } = body

    // Validate required fields
    if (!memberDuesId || !payerEmail || !memberName || !organizationName || !duesName || !method) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Validate payment method
    if (!["card", "ach"].includes(method)) {
      return NextResponse.json({ error: "Invalid payment method" }, { status: 400 })
    }

    // Get member dues and organization info from database
    const supabase = createAdminClient()

    const { data: memberDues, error: duesError } = await supabase
      .from("member_dues")
      .select(`
        *,
        user:users(*, organization:organizations(*)),
        dues_cycle:dues_cycles(*)
      `)
      .eq("id", memberDuesId)
      .single()

    if (duesError || !memberDues) {
      return NextResponse.json({ error: "Member dues not found" }, { status: 404 })
    }

    // Verify the member dues is still outstanding
    const subtotal = memberDues.amount_owed - memberDues.amount_paid
    if (subtotal <= 0) {
      return NextResponse.json({ error: "Already paid" }, { status: 400 })
    }

    const feeCalculation = calculateTotalWithFees(subtotal, method as PayMethod)
    const totalAmount = feeCalculation.total

    // Guard rails: amount must be > 0 && <= 10000
    if (totalAmount <= 0 || totalAmount > 10000) {
      return NextResponse.json({ error: "Invalid payment amount" }, { status: 400 })
    }

    // Build success/cancel URLs
    const origin = process.env.NEXT_PUBLIC_SITE_URL ?? new URL(req.url).origin
    const successUrl = `${origin}/quick-pay/success?session_id={CHECKOUT_SESSION_ID}`
    const cancelUrl = `${origin}/quick-pay?canceled=1`

    // Get organization's Stripe Connect account
    const organization = memberDues.user.organization
    const useConnectAccount = !!organization.stripe_account_id

    const paymentMethodTypes = method === "card" ? ["card"] : ["us_bank_account"]

    // Create Stripe Checkout session
    const sessionConfig: Stripe.Checkout.SessionCreateParams = {
      payment_method_types: paymentMethodTypes,
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: `${duesName} - ${memberName}`,
              description: `Payment for ${organizationName}`,
            },
            unit_amount: Math.round(totalAmount * 100), // Convert to cents
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: successUrl,
      cancel_url: cancelUrl,
      customer_email: payerEmail,
      metadata: {
        member_dues_id: memberDuesId,
        payment_method: method,
        payer_email: payerEmail,
        member_name: memberName,
        organization_name: organizationName,
        dues_name: duesName,
        subtotal: subtotal.toString(),
        processing_fee: feeCalculation.processingFee.toString(),
      },
      payment_intent_data: {
        metadata: {
          member_dues_id: memberDuesId,
          payment_method: method,
          payer_email: payerEmail,
          member_name: memberName,
          organization_name: organizationName,
          dues_name: duesName,
          subtotal: subtotal.toString(),
          processing_fee: feeCalculation.processingFee.toString(),
        },
      },
    }

    // Add Connect account configuration if available
    if (useConnectAccount) {
      const platformFee = Math.round(feeCalculation.processingFee * 100) // Processing fee goes to platform

      sessionConfig.payment_intent_data!.application_fee_amount = platformFee
      sessionConfig.payment_intent_data!.transfer_data = {
        destination: organization.stripe_account_id,
      }
    }

    const session = await stripe.checkout.sessions.create(sessionConfig)

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error("Checkout session creation error:", error)

    if (error instanceof Stripe.errors.StripeError) {
      return NextResponse.json({ error: `Payment processing error: ${error.message}` }, { status: 400 })
    }

    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
