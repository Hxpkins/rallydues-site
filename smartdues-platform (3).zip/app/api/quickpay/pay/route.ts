import { type NextRequest, NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { verifyToken } from "@/lib/quickpay/tokens"
import Stripe from "stripe"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
})

// Rate limiting for payment attempts
const paymentRateLimitMap = new Map<string, { count: number; resetTime: number }>()

function checkPaymentRateLimit(ip: string): boolean {
  const now = Date.now()
  const windowMs = 15 * 60 * 1000 // 15 minutes
  const maxRequests = 5 // Max 5 payment attempts per 15 minutes per IP

  const current = paymentRateLimitMap.get(ip)

  if (!current || now > current.resetTime) {
    paymentRateLimitMap.set(ip, { count: 1, resetTime: now + windowMs })
    return true
  }

  if (current.count >= maxRequests) {
    return false
  }

  current.count++
  return true
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { paymentToken, paymentMethodId, amount } = body

    if (!paymentToken || !paymentMethodId || !amount) {
      return NextResponse.json({ error: "Payment token, payment method, and amount are required" }, { status: 400 })
    }

    // Get client IP for rate limiting
    const forwarded = request.headers.get("x-forwarded-for")
    const ip = forwarded ? forwarded.split(",")[0] : "127.0.0.1"

    // Rate limiting: max 5 payment attempts per 15 minutes per IP
    if (!checkPaymentRateLimit(ip)) {
      return NextResponse.json({ error: "Too many payment attempts. Please try again later." }, { status: 429 })
    }

    // Verify and decode the payment token
    const tokenData = verifyToken(paymentToken)
    if (!tokenData || !tokenData.orgId || !tokenData.memberId || !tokenData.email) {
      return NextResponse.json({ error: "Invalid or expired payment token" }, { status: 400 })
    }

    // Validate amount matches token
    if (tokenData.amountDue && Math.abs(amount - tokenData.amountDue) > 0.01) {
      return NextResponse.json({ error: "Payment amount does not match expected amount" }, { status: 400 })
    }

    const supabase = createAdminClient()

    // Get member dues and organization info
    const { data: memberDues, error: duesError } = await supabase
      .from("member_dues")
      .select(`
        *,
        user:users!inner(id, first_name, last_name, email, organization_id),
        dues_cycle:dues_cycles(name, due_date),
        organization:organizations!inner(id, name, stripe_account_id, card_fee_percent, ach_fee_percent, ach_fee_cap_cents)
      `)
      .eq("user.id", tokenData.memberId)
      .eq("user.organization_id", tokenData.orgId)
      .ilike("user.email", tokenData.email)
      .in("status", ["pending", "partial", "overdue"])
      .gt("amount_owed", "amount_paid")

    if (duesError || !memberDues || memberDues.length === 0) {
      return NextResponse.json({ error: "No outstanding dues found" }, { status: 404 })
    }

    // Calculate total amount due
    const totalAmountDue = memberDues.reduce((sum, dues) => sum + (dues.amount_owed - dues.amount_paid), 0)

    // Validate payment amount
    if (amount <= 0 || amount > 10000 || Math.abs(amount - totalAmountDue) > 0.01) {
      return NextResponse.json({ error: "Invalid payment amount" }, { status: 400 })
    }

    const organization = memberDues[0].organization
    const member = memberDues[0].user

    // Create idempotency key
    const idempotencyKey = `quickpay_${tokenData.memberId}_${Date.now()}`

    try {
      // Create Stripe PaymentIntent
      const paymentIntentParams: Stripe.PaymentIntentCreateParams = {
        amount: Math.round(amount * 100), // Convert to cents
        currency: "usd",
        payment_method: paymentMethodId,
        confirmation_method: "manual",
        confirm: true,
        return_url: `${process.env.NEXT_PUBLIC_SITE_URL}/quick-pay/success`,
        metadata: {
          org_id: tokenData.orgId,
          member_id: tokenData.memberId,
          member_email: tokenData.email,
          member_name: `${member.first_name} ${member.last_name}`,
          organization_name: organization.name,
          payment_type: "quickpay",
          amount_due: totalAmountDue.toString(),
        },
      }

      // Add Stripe Connect configuration if available
      if (organization.stripe_account_id) {
        // Calculate platform fee (processing fee goes to platform)
        const processingFeePercent = paymentMethodId.startsWith("pm_")
          ? organization.card_fee_percent / 100
          : organization.ach_fee_percent / 100

        const processingFee = Math.min(
          amount * processingFeePercent,
          paymentMethodId.startsWith("pm_") ? amount * 0.1 : organization.ach_fee_cap_cents / 100,
        )

        paymentIntentParams.application_fee_amount = Math.round(processingFee * 100)
        paymentIntentParams.transfer_data = {
          destination: organization.stripe_account_id,
        }
      }

      const paymentIntent = await stripe.paymentIntents.create(paymentIntentParams, {
        idempotencyKey,
      })

      // Handle different payment intent statuses
      if (paymentIntent.status === "succeeded") {
        // Payment succeeded immediately
        await processSuccessfulPayment(supabase, memberDues, paymentIntent, tokenData.email)

        return NextResponse.json({
          ok: true,
          paymentId: paymentIntent.id,
          amount: amount,
          currency: "usd",
          status: "succeeded",
        })
      } else if (paymentIntent.status === "requires_action") {
        // Payment requires additional action (3D Secure, etc.)
        return NextResponse.json({
          ok: true,
          paymentId: paymentIntent.id,
          amount: amount,
          currency: "usd",
          status: "requires_action",
          client_secret: paymentIntent.client_secret,
        })
      } else {
        // Payment failed or requires different handling
        return NextResponse.json(
          {
            error: "Payment could not be processed",
            status: paymentIntent.status,
          },
          { status: 400 },
        )
      }
    } catch (stripeError: any) {
      console.error("Stripe payment error:", stripeError)

      if (stripeError.type === "StripeCardError") {
        return NextResponse.json(
          {
            error: stripeError.message || "Payment failed",
          },
          { status: 400 },
        )
      }

      return NextResponse.json(
        {
          error: "Payment processing failed. Please try again.",
        },
        { status: 500 },
      )
    }
  } catch (error) {
    console.error("Quick Pay payment error:", error)
    return NextResponse.json({ error: "An unexpected error occurred. Please try again." }, { status: 500 })
  }
}

async function processSuccessfulPayment(
  supabase: any,
  memberDues: any[],
  paymentIntent: Stripe.PaymentIntent,
  payerEmail: string,
) {
  const totalPaid = paymentIntent.amount / 100 // Convert from cents
  let remainingAmount = totalPaid

  // Process each member dues record
  for (const dues of memberDues) {
    if (remainingAmount <= 0) break

    const amountOwed = dues.amount_owed - dues.amount_paid
    const paymentAmount = Math.min(remainingAmount, amountOwed)
    const newAmountPaid = dues.amount_paid + paymentAmount
    const newStatus = newAmountPaid >= dues.amount_owed ? "paid" : "partial"

    // Update member dues
    await supabase
      .from("member_dues")
      .update({
        amount_paid: newAmountPaid,
        status: newStatus,
        updated_at: new Date().toISOString(),
      })
      .eq("id", dues.id)

    // Create payment record
    await supabase.from("payments").insert({
      member_dues_id: dues.id,
      stripe_payment_intent_id: paymentIntent.id,
      amount: paymentAmount,
      processing_fee: 0, // Fee is handled by Stripe Connect
      payer_email: payerEmail,
      payer_name: `${dues.user.first_name} ${dues.user.last_name}`,
      payment_method: getPaymentMethodType(paymentIntent),
      status: "succeeded",
      paid_at: new Date().toISOString(),
    })

    remainingAmount -= paymentAmount
  }
}

function getPaymentMethodType(paymentIntent: Stripe.PaymentIntent): string {
  const charges = paymentIntent.charges?.data
  if (!charges || charges.length === 0) return "unknown"

  const charge = charges[0]
  const paymentMethod = charge.payment_method_details

  if (paymentMethod?.card) return "card"
  if (paymentMethod?.us_bank_account) return "ach"
  if (paymentMethod?.link) return "link"

  return paymentMethod?.type || "unknown"
}
