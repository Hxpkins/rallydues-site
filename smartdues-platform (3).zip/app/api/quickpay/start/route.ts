import { type NextRequest, NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { generateRequestId } from "@/lib/ids"
import { newOtp, hashOtp } from "@/lib/otp"

// Rate limiting map (in production, use Redis or similar)
const rateLimitMap = new Map<string, { count: number; resetTime: number }>()
const emailRateLimitMap = new Map<string, { count: number; resetTime: number }>()

function checkRateLimit(key: string, maxRequests: number, windowMs: number, limitMap: Map<string, any>): boolean {
  const now = Date.now()
  const current = limitMap.get(key)

  if (!current || now > current.resetTime) {
    limitMap.set(key, { count: 1, resetTime: now + windowMs })
    return true
  }

  if (current.count >= maxRequests) {
    return false
  }

  current.count++
  return true
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { chapterCode, email } = body

    if (!chapterCode || !email) {
      return NextResponse.json({ error: "Chapter code and email are required" }, { status: 400 })
    }

    // Get client IP for rate limiting
    const forwarded = request.headers.get("x-forwarded-for")
    const ip = forwarded ? forwarded.split(",")[0] : "127.0.0.1"
    const ipChapterKey = `${ip}:${chapterCode}`

    // Rate limiting: 10 requests per hour per IP+chapterCode
    if (!checkRateLimit(ipChapterKey, 10, 60 * 60 * 1000, rateLimitMap)) {
      return NextResponse.json({ error: "Too many requests. Please try again later." }, { status: 429 })
    }

    // Rate limiting: 1 request per minute per email
    if (!checkRateLimit(email.toLowerCase(), 1, 60 * 1000, emailRateLimitMap)) {
      return NextResponse.json({ error: "Too many requests. Please try again later." }, { status: 429 })
    }

    const supabase = createAdminClient()

    const { data: organization, error: orgError } = await supabase
      .from("organizations")
      .select("id, name, chapter_code, prev_chapter_code, prev_code_valid_until")
      .or(
        `chapter_code.eq.${chapterCode},and(prev_chapter_code.eq.${chapterCode},prev_code_valid_until.gte.${new Date().toISOString()})`,
      )
      .single()

    // Always generate a requestId to prevent enumeration
    const requestId = generateRequestId()

    if (orgError || !organization) {
      // Return generic success response even if org not found
      return NextResponse.json({ ok: true, requestId })
    }

    const { data: members, error: memberError } = await supabase
      .from("users")
      .select("id, email, first_name, last_name")
      .eq("organization_id", organization.id)
      .ilike("email", email.toLowerCase())

    if (memberError || !members || members.length === 0) {
      // Return generic success response even if email not found
      return NextResponse.json({ ok: true, requestId })
    }

    const otpCode = newOtp()
    const otpHash = hashOtp(otpCode)
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000) // 10 minutes

    const { error: otpError } = await supabase.from("quickpay_otps").insert({
      org_id: organization.id,
      email: email.toLowerCase(),
      code_hash: otpHash,
      request_id: requestId,
      expires_at: expiresAt.toISOString(),
      ip: ip,
    })

    if (otpError) {
      console.error("Error storing OTP:", otpError)
      // Still return success to prevent enumeration
      return NextResponse.json({ ok: true, requestId })
    }

    console.log(`OTP email should be sent to ${email} with code: ${otpCode}`)
    // TODO: Implement email sending with SMTP or email service

    return NextResponse.json({ ok: true, requestId })
  } catch (error) {
    console.error("Quick Pay start error:", error)
    return NextResponse.json({ error: "An unexpected error occurred. Please try again." }, { status: 500 })
  }
}
