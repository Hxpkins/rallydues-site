import { type NextRequest, NextResponse } from "next/server"
import { createAdminClient } from "@/lib/supabase/admin"
import { verifyOtp } from "@/lib/otp"
import { createPaymentToken, createMemberToken } from "@/lib/quickpay/tokens"

// Rate limiting for verification attempts
const verifyRateLimitMap = new Map<string, { count: number; resetTime: number }>()

function checkVerifyRateLimit(requestId: string): boolean {
  const now = Date.now()
  const windowMs = 15 * 60 * 1000 // 15 minutes
  const maxAttempts = 5

  const current = verifyRateLimitMap.get(requestId)

  if (!current || now > current.resetTime) {
    verifyRateLimitMap.set(requestId, { count: 1, resetTime: now + windowMs })
    return true
  }

  if (current.count >= maxAttempts) {
    return false
  }

  current.count++
  return true
}

function maskName(firstName: string, lastName: string): string {
  const maskString = (str: string) => {
    if (str.length <= 1) return str
    return str.charAt(0) + "*".repeat(Math.max(0, str.length - 2)) + (str.length > 1 ? str.charAt(str.length - 1) : "")
  }
  return `${maskString(firstName)} ${maskString(lastName)}`
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { chapterCode, email, otp, requestId } = body

    if (!chapterCode || !email || !otp || !requestId) {
      return NextResponse.json({ error: "All fields are required" }, { status: 400 })
    }

    // Rate limiting: max 5 attempts per requestId
    if (!checkVerifyRateLimit(requestId)) {
      return NextResponse.json({ error: "Too many verification attempts. Please request a new code." }, { status: 429 })
    }

    const supabase = createAdminClient()

    const { data: otpRecord, error: otpError } = await supabase
      .from("quickpay_otps")
      .select("*")
      .eq("request_id", requestId)
      .eq("email", email.toLowerCase())
      .is("used_at", null)
      .gt("expires_at", new Date().toISOString())
      .lt("attempts", 5)
      .order("created_at", { ascending: false })
      .limit(1)
      .single()

    if (otpError || !otpRecord) {
      return NextResponse.json({ error: "Invalid or expired verification code" }, { status: 400 })
    }

    const isValidOtp = verifyOtp(otp, otpRecord.code_hash)

    // Increment attempts regardless of success/failure
    await supabase
      .from("quickpay_otps")
      .update({ attempts: otpRecord.attempts + 1 })
      .eq("id", otpRecord.id)

    if (!isValidOtp) {
      return NextResponse.json({ error: "Invalid verification code" }, { status: 400 })
    }

    await supabase.from("quickpay_otps").update({ used_at: new Date().toISOString() }).eq("id", otpRecord.id)

    const { data: memberDues, error: duesError } = await supabase
      .from("member_dues")
      .select(`
        *,
        user:users!inner(id, first_name, last_name, email),
        dues_cycle:dues_cycles(name, due_date)
      `)
      .eq("user.organization_id", otpRecord.org_id)
      .ilike("user.email", email.toLowerCase())
      .in("status", ["pending", "partial", "overdue"])
      .gt("amount_owed", "amount_paid")

    if (duesError || !memberDues || memberDues.length === 0) {
      return NextResponse.json({ error: "No outstanding dues found" }, { status: 404 })
    }

    const memberGroups = memberDues.reduce(
      (groups, dues) => {
        const memberId = dues.user.id
        if (!groups[memberId]) {
          groups[memberId] = {
            member: dues.user,
            dues: [],
            totalAmount: 0,
          }
        }
        const amountDue = dues.amount_owed - dues.amount_paid
        groups[memberId].dues.push(dues)
        groups[memberId].totalAmount += amountDue
        return groups
      },
      {} as Record<string, any>,
    )

    const memberOptions = Object.values(memberGroups)

    if (memberOptions.length === 1) {
      // Single member - return payment token
      const member = memberOptions[0]
      const paymentToken = createPaymentToken(otpRecord.org_id, member.member.id, email, member.totalAmount)

      return NextResponse.json({
        ok: true,
        paymentToken,
        summary: {
          maskedName: maskName(member.member.first_name, member.member.last_name),
          amountDue: member.totalAmount,
        },
      })
    } else {
      // Multiple members - return options with member tokens
      const options = memberOptions.map((memberGroup) => ({
        maskedName: maskName(memberGroup.member.first_name, memberGroup.member.last_name),
        memberToken: createMemberToken(otpRecord.org_id, memberGroup.member.id, email, memberGroup.totalAmount),
      }))

      return NextResponse.json({
        ok: true,
        options,
      })
    }
  } catch (error) {
    console.error("Quick Pay verify error:", error)
    return NextResponse.json({ error: "An unexpected error occurred. Please try again." }, { status: 500 })
  }
}
