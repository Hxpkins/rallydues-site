export const runtime = "nodejs"

import { NextResponse } from "next/server"
import { Resend } from "resend"

// Rate limiting map (in-memory)
const rateLimitMap = new Map<string, { count: number; resetTime: number }>()

// Clean up old entries every 15 minutes
setInterval(
  () => {
    const now = Date.now()
    for (const [ip, data] of rateLimitMap.entries()) {
      if (now > data.resetTime) {
        rateLimitMap.delete(ip)
      }
    }
  },
  15 * 60 * 1000,
)

function getRealIP(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for")
  const realIP = request.headers.get("x-real-ip")

  if (forwarded) {
    return forwarded.split(",")[0].trim()
  }
  if (realIP) {
    return realIP
  }
  return "unknown"
}

function isRateLimited(ip: string): boolean {
  const now = Date.now()
  const windowMs = 15 * 60 * 1000 // 15 minutes
  const maxRequests = 10

  const current = rateLimitMap.get(ip)

  if (!current || now > current.resetTime) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + windowMs })
    return false
  }

  if (current.count >= maxRequests) {
    return true
  }

  current.count++
  return false
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

function sanitizeInput(input: string): string {
  return input.trim().replace(/[<>]/g, "")
}

export async function POST(req: Request) {
  try {
    // Check required environment variables
    const RESEND_API_KEY = process.env.RESEND_API_KEY
    const SUPPORT_EMAIL = process.env.SUPPORT_EMAIL
    const EMAIL_FROM = process.env.EMAIL_FROM || "RallyDues <no-reply@rallydues.com>"

    if (!RESEND_API_KEY || !SUPPORT_EMAIL) {
      console.error("Missing required environment variables: RESEND_API_KEY or SUPPORT_EMAIL")
      return NextResponse.json({ ok: false, error: "Email temporarily unavailable" }, { status: 503 })
    }

    // Rate limiting
    const ip = getRealIP(req)
    if (isRateLimited(ip)) {
      return NextResponse.json({ ok: false, error: "Too many requests. Please try again later." }, { status: 429 })
    }

    const body = await req.json()
    const { name, email, subject, message, organization } = body

    // Validation
    if (!name || !email || !subject || !message) {
      return NextResponse.json({ ok: false, error: "Missing required fields" }, { status: 400 })
    }

    const cleanName = sanitizeInput(name)
    const cleanEmail = sanitizeInput(email)
    const cleanSubject = sanitizeInput(subject)
    const cleanMessage = sanitizeInput(message)
    const cleanOrganization = organization ? sanitizeInput(organization) : ""

    // Length validation
    if (cleanName.length < 1 || cleanName.length > 100) {
      return NextResponse.json({ ok: false, error: "Name must be 1-100 characters" }, { status: 400 })
    }

    if (!validateEmail(cleanEmail)) {
      return NextResponse.json({ ok: false, error: "Invalid email address" }, { status: 400 })
    }

    if (cleanSubject.length < 1 || cleanSubject.length > 120) {
      return NextResponse.json({ ok: false, error: "Subject must be 1-120 characters" }, { status: 400 })
    }

    if (cleanMessage.length < 1 || cleanMessage.length > 5000) {
      return NextResponse.json({ ok: false, error: "Message must be 1-5000 characters" }, { status: 400 })
    }

    if (cleanOrganization.length > 120) {
      return NextResponse.json({ ok: false, error: "Organization must be 120 characters or less" }, { status: 400 })
    }

    const resend = new Resend(RESEND_API_KEY)
    const timestamp = new Date().toISOString()

    try {
      // Send email to support
      await resend.emails.send({
        from: EMAIL_FROM,
        to: [SUPPORT_EMAIL],
        subject: `Contact: ${cleanSubject}`,
        html: `
          <h2>New Contact Form Submission</h2>
          <p><strong>Name:</strong> ${cleanName}</p>
          <p><strong>Email:</strong> ${cleanEmail}</p>
          ${cleanOrganization ? `<p><strong>Organization:</strong> ${cleanOrganization}</p>` : ""}
          <p><strong>Subject:</strong> ${cleanSubject}</p>
          <p><strong>Message:</strong></p>
          <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
            ${cleanMessage.replace(/\n/g, "<br>")}
          </div>
          <p><strong>Timestamp:</strong> ${timestamp}</p>
        `,
        replyTo: cleanEmail,
      })

      // Send confirmation email to user
      await resend.emails.send({
        from: EMAIL_FROM,
        to: [cleanEmail],
        subject: "We received your message",
        html: `
          <h2>Thanks for contacting RallyDues!</h2>
          <p>Hi ${cleanName},</p>
          <p>We received your message and will reply within 48 hours.</p>
          
          <h3>Copy of your message:</h3>
          <div style="background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0;">
            <p><strong>Subject:</strong> ${cleanSubject}</p>
            <p><strong>Message:</strong></p>
            <p>${cleanMessage.replace(/\n/g, "<br>")}</p>
          </div>
          
          <p>Best regards,<br>The RallyDues Team</p>
        `,
      })

      console.log("Contact form emails sent successfully:", {
        name: cleanName,
        email: cleanEmail,
        organization: cleanOrganization,
        subject: cleanSubject,
        timestamp,
      })

      return NextResponse.json({ ok: true })
    } catch (emailError) {
      console.error("Failed to send emails:", emailError)
      return NextResponse.json({ ok: false, error: "Failed to send email" }, { status: 500 })
    }
  } catch (error) {
    console.error("Contact form error:", error)
    return NextResponse.json({ ok: false, error: "Internal server error" }, { status: 500 })
  }
}
