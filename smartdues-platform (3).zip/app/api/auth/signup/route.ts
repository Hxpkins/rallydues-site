import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { isSupabaseConfigured } from "@/lib/supabase/server"
import { generateChapterCode } from "@/lib/ids"

export async function POST(request: NextRequest) {
  if (!isSupabaseConfigured) {
    return NextResponse.json({ error: "Authentication is not configured. Please contact support." }, { status: 500 })
  }

  try {
    const body = await request.json()
    const { organizationName, university, email, password } = body

    if (!organizationName || !email || !password) {
      return NextResponse.json({ error: "Organization name, email, and password are required" }, { status: 400 })
    }

    const supabase = createClient()

    let chapterCode = generateChapterCode(10)
    let attempts = 0
    const maxAttempts = 5

    // Ensure chapter code is unique
    while (attempts < maxAttempts) {
      const { data: existingOrg } = await supabase
        .from("organizations")
        .select("id")
        .eq("chapter_code", chapterCode)
        .single()

      if (!existingOrg) break

      chapterCode = generateChapterCode(10)
      attempts++
    }

    if (attempts >= maxAttempts) {
      return NextResponse.json({ error: "Failed to generate unique chapter code. Please try again." }, { status: 500 })
    }

    // Create user account
    const { data: authData, error: authError } = await supabase.auth.signUp({
      email: email.toString(),
      password: password.toString(),
      options: {
        emailRedirectTo:
          process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${process.env.NEXT_PUBLIC_SITE_URL}/app/home`,
      },
    })

    if (authError) {
      return NextResponse.json({ error: authError.message }, { status: 400 })
    }

    if (!authData.user) {
      return NextResponse.json({ error: "Failed to create user account" }, { status: 500 })
    }

    const { data: orgData, error: orgError } = await supabase
      .from("organizations")
      .insert({
        name: organizationName.toString(),
        slug: chapterCode.toLowerCase(), // Use chapter code as slug for now
        chapter_code: chapterCode,
        chapter_code_rotated_at: new Date().toISOString(),
        type: "fraternity", // Default type
        card_fee_percent: 3.1,
        ach_fee_percent: 1.0,
        ach_fee_cap_cents: 500, // $5.00
        // Store university in a metadata field if provided
        ...(university && { university: university.toString() }),
      })
      .select()
      .single()

    if (orgError) {
      console.error("Organization creation error:", orgError)
      return NextResponse.json({ error: "Failed to create organization. Please try again." }, { status: 500 })
    }

    // Update user with organization and role
    const { error: userUpdateError } = await supabase
      .from("users")
      .update({
        organization_id: orgData.id,
        role: "treasurer",
      })
      .eq("id", authData.user.id)

    if (userUpdateError) {
      console.error("User update error:", userUpdateError)
      return NextResponse.json(
        { error: "Account created but failed to set up organization. Please contact support." },
        { status: 500 },
      )
    }

    // TODO: Implement email sending with chapter code
    console.log(`Welcome email should be sent to ${email} with chapter code: ${chapterCode}`)

    // If user needs email confirmation, show message
    if (!authData.session) {
      return NextResponse.json({
        success: "Please check your email to confirm your account before signing in.",
      })
    }

    // User is automatically signed in
    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error("Sign up error:", error)
    return NextResponse.json({ error: "An unexpected error occurred. Please try again." }, { status: 500 })
  }
}
