import { signOut } from "@/lib/auth-actions"
import { redirect } from "next/navigation"

export async function POST() {
  await signOut()
  redirect("/")
}
