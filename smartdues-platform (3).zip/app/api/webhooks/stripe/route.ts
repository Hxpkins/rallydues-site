import { NextResponse } from "next/server"
import { headers } from "next/headers"
import Stripe from "stripe"
import { createAdminClient } from "@/lib/supabase/admin"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
})

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

export async function POST(req: Request) {
  try {
    const body = await req.text()
    const headersList = headers()
    const signature = headersList.get("stripe-signature")

    if (!signature) {
      console.error("No Stripe signature found")
      return NextResponse.json({ error: "No signature" }, { status: 400 })
    }

    let event: Stripe.Event

    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
    } catch (err) {
      console.error("Webhook signature verification failed:", err)
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    console.log(`Received webhook event: ${event.type}`)

    // Handle the event
    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutSessionCompleted(event.data.object as Stripe.Checkout.Session)
        break

      case "payment_intent.succeeded":
        await handlePaymentIntentSucceeded(event.data.object as Stripe.PaymentIntent)
        break

      case "payment_intent.payment_failed":
        await handlePaymentIntentFailed(event.data.object as Stripe.PaymentIntent)
        break

      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Webhook processing error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}

async function handleCheckoutSessionCompleted(session: Stripe.Checkout.Session) {
  try {
    console.log("Processing checkout session completed:", session.id)

    const memberDuesId = session.metadata?.member_dues_id
    const payerEmail = session.metadata?.payer_email

    if (!memberDuesId || !payerEmail) {
      console.error("Missing required metadata in session:", session.id)
      return
    }

    const supabase = createAdminClient()

    // Get the member dues record
    const { data: memberDues, error: duesError } = await supabase
      .from("member_dues")
      .select("*, user:users(*, organization:organizations(*))")
      .eq("id", memberDuesId)
      .single()

    if (duesError || !memberDues) {
      console.error("Failed to find member dues:", memberDuesId, duesError)
      return
    }

    // Check if payment already exists (idempotency)
    const { data: existingPayment } = await supabase
      .from("payments")
      .select("id")
      .eq("stripe_payment_intent_id", session.payment_intent as string)
      .single()

    if (existingPayment) {
      console.log("Payment already processed:", session.payment_intent)
      return
    }

    // Calculate amounts
    const amountPaid = (session.amount_total || 0) / 100 // Convert from cents
    const processingFee = ((session.amount_total || 0) - (session.amount_subtotal || 0)) / 100

    // Create payment record
    const { error: paymentError } = await supabase.from("payments").insert({
      member_dues_id: memberDuesId,
      stripe_payment_intent_id: session.payment_intent as string,
      amount: amountPaid,
      processing_fee: processingFee,
      payer_email: payerEmail,
      payer_name: session.customer_details?.name || "",
      payment_method: "stripe",
      status: "succeeded",
      paid_at: new Date().toISOString(),
    })

    if (paymentError) {
      console.error("Failed to create payment record:", paymentError)
      return
    }

    // Update member dues
    const newAmountPaid = memberDues.amount_paid + amountPaid
    const newStatus = newAmountPaid >= memberDues.amount_owed ? "paid" : "partial"

    const { error: updateError } = await supabase
      .from("member_dues")
      .update({
        amount_paid: newAmountPaid,
        status: newStatus,
        updated_at: new Date().toISOString(),
      })
      .eq("id", memberDuesId)

    if (updateError) {
      console.error("Failed to update member dues:", updateError)
      return
    }

    console.log(`Successfully processed payment for member dues ${memberDuesId}`)

    // TODO: Send confirmation email to payer and member
    // TODO: Send notification to organization treasurer
  } catch (error) {
    console.error("Error handling checkout session completed:", error)
  }
}

async function handlePaymentIntentSucceeded(paymentIntent: Stripe.PaymentIntent) {
  try {
    console.log("Processing payment intent succeeded:", paymentIntent.id)

    const supabase = createAdminClient()

    // Update payment status if it exists
    const { error } = await supabase
      .from("payments")
      .update({
        status: "succeeded",
        paid_at: new Date().toISOString(),
      })
      .eq("stripe_payment_intent_id", paymentIntent.id)

    if (error) {
      console.error("Failed to update payment status:", error)
    }
  } catch (error) {
    console.error("Error handling payment intent succeeded:", error)
  }
}

async function handlePaymentIntentFailed(paymentIntent: Stripe.PaymentIntent) {
  try {
    console.log("Processing payment intent failed:", paymentIntent.id)

    const supabase = createAdminClient()

    // Update payment status if it exists
    const { error } = await supabase
      .from("payments")
      .update({
        status: "failed",
      })
      .eq("stripe_payment_intent_id", paymentIntent.id)

    if (error) {
      console.error("Failed to update payment status:", error)
    }

    // TODO: Send failure notification to payer
    // TODO: Log failed payment for treasurer review
  } catch (error) {
    console.error("Error handling payment intent failed:", error)
  }
}
