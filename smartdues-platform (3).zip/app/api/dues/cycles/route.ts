import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user profile to check role and organization
    const { data: profile } = await supabase.from("users").select("role, organization_id").eq("id", user.id).single()

    if (!profile || !["treasurer", "president", "exec"].includes(profile.role)) {
      return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
    }

    const body = await request.json()
    const { name, due_date, default_amount, late_fee_amount, late_fee_days, organization_id } = body

    // Verify organization matches user's organization
    if (organization_id !== profile.organization_id) {
      return NextResponse.json({ error: "Invalid organization" }, { status: 403 })
    }

    // Create dues cycle
    const { data: cycle, error } = await supabase
      .from("dues_cycles")
      .insert({
        name,
        due_date,
        amount: default_amount,
        late_fee_amount,
        late_fee_days,
        organization_id,
        status: "draft",
      })
      .select()
      .single()

    if (error) {
      console.error("Error creating dues cycle:", error)
      return NextResponse.json({ error: "Failed to create cycle" }, { status: 500 })
    }

    return NextResponse.json(cycle)
  } catch (error) {
    console.error("Error in dues cycle creation:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
