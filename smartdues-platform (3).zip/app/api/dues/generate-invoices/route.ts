import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"
import Stripe from "stripe"

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-06-20",
})

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user profile to check role and organization
    const { data: profile } = await supabase.from("users").select("role, organization_id").eq("id", user.id).single()

    if (!profile || !["treasurer", "president", "exec"].includes(profile.role)) {
      return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
    }

    const { cycleId } = await request.json()

    // Get dues cycle
    const { data: cycle, error: cycleError } = await supabase
      .from("dues_cycles")
      .select("*")
      .eq("id", cycleId)
      .eq("organization_id", profile.organization_id)
      .single()

    if (cycleError || !cycle) {
      return NextResponse.json({ error: "Cycle not found" }, { status: 404 })
    }

    // Get organization details
    const { data: organization } = await supabase
      .from("organizations")
      .select("stripe_account_id, name")
      .eq("id", profile.organization_id)
      .single()

    // Get active members
    const { data: members } = await supabase
      .from("users")
      .select("id, email, first_name, last_name")
      .eq("organization_id", profile.organization_id)
      .eq("role", "member")

    if (!members || members.length === 0) {
      return NextResponse.json({ error: "No active members found" }, { status: 400 })
    }

    // Calculate fees
    const calculateFees = (amount: number, paymentMethod: "card" | "ach") => {
      if (paymentMethod === "card") {
        return Math.round(amount * 0.031 * 100) / 100 // 3.1%
      } else {
        return Math.min(Math.round(amount * 0.01 * 100) / 100, 5) // 1% capped at $5
      }
    }

    const cardFee = calculateFees(cycle.amount, "card")
    const achFee = calculateFees(cycle.amount, "ach")

    let invoiceCount = 0

    // Create member_dues records and Stripe checkout sessions
    for (const member of members) {
      // Create member_dues record
      const { data: memberDues, error: memberDuesError } = await supabase
        .from("member_dues")
        .insert({
          dues_cycle_id: cycleId,
          user_id: member.id,
          amount_owed: cycle.amount,
          amount_paid: 0,
          status: "unpaid",
        })
        .select()
        .single()

      if (memberDuesError) {
        console.error("Error creating member dues:", memberDuesError)
        continue
      }

      try {
        // Create Stripe Checkout Session with both payment options
        const sessionParams: Stripe.Checkout.SessionCreateParams = {
          mode: "payment",
          customer_email: member.email,
          success_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dues/payment-success?session_id={CHECKOUT_SESSION_ID}`,
          cancel_url: `${process.env.NEXT_PUBLIC_SITE_URL}/dues/payment-cancelled`,
          metadata: {
            member_dues_id: memberDues.id,
            cycle_id: cycleId,
            member_id: member.id,
          },
          line_items: [
            {
              price_data: {
                currency: "usd",
                product_data: {
                  name: `${cycle.name} - Dues`,
                  description: `Dues payment for ${member.first_name} ${member.last_name}`,
                },
                unit_amount: Math.round(cycle.amount * 100),
              },
              quantity: 1,
            },
            {
              price_data: {
                currency: "usd",
                product_data: {
                  name: "Processing Fee",
                  description: "Payment processing fee",
                },
                unit_amount: Math.round(cardFee * 100), // Default to card fee
              },
              quantity: 1,
            },
          ],
          payment_method_types: ["card", "us_bank_account"],
        }

        // Use connected account if available
        if (organization?.stripe_account_id) {
          sessionParams.stripe_account = organization.stripe_account_id
          // Set up destination charges for connected accounts
          sessionParams.payment_intent_data = {
            application_fee_amount: Math.round(cardFee * 100), // Platform keeps the processing fee
          }
        }

        const session = await stripe.checkout.sessions.create(sessionParams)

        // Update member_dues with Stripe session ID
        await supabase
          .from("member_dues")
          .update({
            stripe_session_id: session.id,
            stripe_payment_intent_id: session.payment_intent as string,
          })
          .eq("id", memberDues.id)

        invoiceCount++
      } catch (stripeError) {
        console.error("Error creating Stripe session:", stripeError)
        // Continue with other members even if one fails
      }
    }

    // Update cycle status to active
    await supabase.from("dues_cycles").update({ status: "active" }).eq("id", cycleId)

    return NextResponse.json({
      success: true,
      count: invoiceCount,
      message: `Generated ${invoiceCount} invoices for active members`,
    })
  } catch (error) {
    console.error("Error generating invoices:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
