import { type NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { generateChapterCode } from "@/lib/ids"

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user profile to check role and organization
    const { data: profile, error: profileError } = await supabase
      .from("users")
      .select("role, organization_id")
      .eq("id", user.id)
      .single()

    if (profileError || !profile) {
      return NextResponse.json({ error: "User profile not found" }, { status: 404 })
    }

    // Check if user has permission to rotate codes (treasurer, president, exec)
    if (!["treasurer", "president", "exec"].includes(profile.role)) {
      return NextResponse.json({ error: "Insufficient permissions" }, { status: 403 })
    }

    // Get current organization data
    const { data: organization, error: orgError } = await supabase
      .from("organizations")
      .select("id, name, chapter_code, chapter_code_rotated_at")
      .eq("id", profile.organization_id)
      .single()

    if (orgError || !organization) {
      return NextResponse.json({ error: "Organization not found" }, { status: 404 })
    }

    // Generate new chapter code, ensuring uniqueness
    let newChapterCode = generateChapterCode(10)
    let attempts = 0
    const maxAttempts = 5

    while (attempts < maxAttempts) {
      const { data: existingOrg } = await supabase
        .from("organizations")
        .select("id")
        .eq("chapter_code", newChapterCode)
        .single()

      if (!existingOrg) break

      newChapterCode = generateChapterCode(10)
      attempts++
    }

    if (attempts >= maxAttempts) {
      return NextResponse.json({ error: "Failed to generate unique chapter code. Please try again." }, { status: 500 })
    }

    const now = new Date()
    const validUntil = new Date(now.getTime() + 24 * 60 * 60 * 1000) // 24 hours from now

    // Update organization with new chapter code
    const { error: updateError } = await supabase
      .from("organizations")
      .update({
        prev_chapter_code: organization.chapter_code,
        prev_code_valid_until: validUntil.toISOString(),
        chapter_code: newChapterCode,
        chapter_code_rotated_at: now.toISOString(),
        updated_at: now.toISOString(),
      })
      .eq("id", organization.id)

    if (updateError) {
      console.error("Error updating organization chapter code:", updateError)
      return NextResponse.json({ error: "Failed to rotate chapter code" }, { status: 500 })
    }

    // Log the rotation for audit purposes
    console.log(
      `Chapter code rotated for organization ${organization.name} (${organization.id}): ${organization.chapter_code} -> ${newChapterCode}`,
    )

    // TODO: Send notification email to organization admins about code rotation
    // TODO: Consider sending notification to members about new code (if applicable)

    return NextResponse.json({
      ok: true,
      chapterCodeRotatedAt: now.toISOString(),
      message: "Chapter code has been successfully rotated. The previous code will remain valid for 24 hours.",
    })
  } catch (error) {
    console.error("Chapter code rotation error:", error)
    return NextResponse.json({ error: "An unexpected error occurred. Please try again." }, { status: 500 })
  }
}
