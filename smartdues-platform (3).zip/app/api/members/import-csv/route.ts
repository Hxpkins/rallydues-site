import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

// Generate a unique PayCode (8-10 characters, base36, uppercase)
function generatePayCode(): string {
  const length = Math.floor(Math.random() * 3) + 8 // 8-10 characters
  let result = ""
  const chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }

  return result
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user's role and organization
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("role, organization_id")
      .eq("id", user.id)
      .single()

    if (userError || !userData || userData.role !== "treasurer") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Parse the CSV file
    const formData = await request.formData()
    const file = formData.get("file") as File

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 })
    }

    const csvText = await file.text()
    const lines = csvText.split("\n").filter((line) => line.trim())

    if (lines.length < 2) {
      return NextResponse.json({ error: "CSV must have header and at least one data row" }, { status: 400 })
    }

    // Parse CSV rows
    const headers = lines[0].split(",").map((h) => h.trim())
    const expectedHeaders = ["first_name", "last_name", "email", "member_type", "status", "custom_amount"]

    // Validate headers
    const hasRequiredHeaders = expectedHeaders.slice(0, 3).every((header) => headers.includes(header))

    if (!hasRequiredHeaders) {
      return NextResponse.json(
        {
          error: "CSV must include: first_name, last_name, email columns",
        },
        { status: 400 },
      )
    }

    const members = []
    let paycodesGenerated = 0

    for (let i = 1; i < lines.length; i++) {
      const values = lines[i].split(",").map((v) => v.trim())
      const row: any = {}

      headers.forEach((header, index) => {
        row[header] = values[index] || ""
      })

      // Skip empty rows
      if (!row.first_name || !row.last_name || !row.email) continue

      // Check if member already exists
      const { data: existingMember } = await supabase
        .from("users")
        .select("id, paycode")
        .eq("email", row.email)
        .eq("organization_id", userData.organization_id)
        .single()

      if (existingMember) {
        // Update existing member if no PayCode
        if (!existingMember.paycode) {
          const paycode = generatePayCode()
          await supabase.from("users").update({ paycode }).eq("id", existingMember.id)
          paycodesGenerated++
        }
        continue
      }

      // Generate PayCode for new member
      const paycode = generatePayCode()
      paycodesGenerated++

      members.push({
        first_name: row.first_name,
        last_name: row.last_name,
        email: row.email,
        role: row.member_type || "member",
        paycode,
        organization_id: userData.organization_id,
      })
    }

    // Insert new members
    if (members.length > 0) {
      const { error: insertError } = await supabase.from("users").insert(members)

      if (insertError) {
        console.error("Insert error:", insertError)
        return NextResponse.json({ error: "Failed to import members" }, { status: 500 })
      }
    }

    return NextResponse.json({
      imported: members.length,
      paycodesGenerated,
      message: `Successfully imported ${members.length} members`,
    })
  } catch (error) {
    console.error("Import error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
