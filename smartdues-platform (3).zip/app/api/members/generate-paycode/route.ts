import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

// Generate a unique PayCode (8-10 characters, base36, uppercase)
function generatePayCode(): string {
  const length = Math.floor(Math.random() * 3) + 8 // 8-10 characters
  let result = ""
  const chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

  for (let i = 0; i < length; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }

  return result
}

export async function POST(request: NextRequest) {
  try {
    const supabase = createClient()

    // Check authentication
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get user's role
    const { data: userData, error: userError } = await supabase
      .from("users")
      .select("role, organization_id")
      .eq("id", user.id)
      .single()

    if (userError || !userData || userData.role !== "treasurer") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const { memberId } = await request.json()

    if (!memberId) {
      return NextResponse.json({ error: "Member ID required" }, { status: 400 })
    }

    // Verify member belongs to same organization
    const { data: member, error: memberError } = await supabase
      .from("users")
      .select("id, organization_id, paycode")
      .eq("id", memberId)
      .eq("organization_id", userData.organization_id)
      .single()

    if (memberError || !member) {
      return NextResponse.json({ error: "Member not found" }, { status: 404 })
    }

    if (member.paycode) {
      return NextResponse.json({ error: "Member already has a PayCode" }, { status: 400 })
    }

    // Generate unique PayCode
    let paycode = generatePayCode()
    let attempts = 0
    const maxAttempts = 10

    // Ensure PayCode is unique
    while (attempts < maxAttempts) {
      const { data: existing } = await supabase.from("users").select("id").eq("paycode", paycode).single()

      if (!existing) break

      paycode = generatePayCode()
      attempts++
    }

    if (attempts >= maxAttempts) {
      return NextResponse.json({ error: "Failed to generate unique PayCode" }, { status: 500 })
    }

    // Update member with PayCode
    const { error: updateError } = await supabase.from("users").update({ paycode }).eq("id", memberId)

    if (updateError) {
      return NextResponse.json({ error: "Failed to update PayCode" }, { status: 500 })
    }

    return NextResponse.json({ paycode })
  } catch (error) {
    console.error("Generate PayCode error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
