import Stripe from "stripe"
import { NextResponse } from "next/server"
import { createClient } from "@supabase/supabase-js"

export const runtime = "nodejs"

// Environment variable validation
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET
const SUPABASE_URL = process.env.SUPABASE_URL
const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY

if (!STRIPE_SECRET_KEY || !STRIPE_WEBHOOK_SECRET) {
  console.error("Missing Stripe environment variables")
}

if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
  console.error("Missing Supabase environment variables")
}

const stripe = STRIPE_SECRET_KEY ? new Stripe(STRIPE_SECRET_KEY, { apiVersion: "2024-06-20" }) : null
const supabase =
  SUPABASE_URL && SUPABASE_SERVICE_ROLE_KEY ? createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY) : null

export async function POST(req: Request) {
  // Check environment variables
  if (!stripe || !STRIPE_WEBHOOK_SECRET) {
    console.error("Stripe not configured")
    return NextResponse.json(
      { error: "Stripe webhook processing not available - missing configuration" },
      { status: 503 },
    )
  }

  if (!supabase) {
    console.error("Supabase not configured")
    return NextResponse.json({ error: "Database not available - missing configuration" }, { status: 503 })
  }

  let body: string
  let sig: string | null

  try {
    body = await req.text()
    sig = req.headers.get("stripe-signature")
  } catch (error) {
    console.error("Error reading request:", error)
    return NextResponse.json({ received: true })
  }

  if (!sig) {
    console.error("Missing stripe-signature header")
    return NextResponse.json({ error: "Missing signature" }, { status: 400 })
  }

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, sig, STRIPE_WEBHOOK_SECRET)
  } catch (err: any) {
    console.error("Webhook signature verification failed:", err.message)
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
  }

  console.log(`Received Stripe webhook event: ${event.type}`)

  try {
    switch (event.type) {
      case "checkout.session.completed":
        await handleCheckoutCompleted(event.data.object as Stripe.Checkout.Session)
        break

      case "payment_intent.succeeded":
        await handlePaymentSucceeded(event.data.object as Stripe.PaymentIntent)
        break

      default:
        console.log(`Unhandled event type: ${event.type}`)
        break
    }
  } catch (error) {
    console.error(`Error processing webhook event ${event.type}:`, error)
    // Don't return error - always return success to prevent retries
  }

  return NextResponse.json({ received: true })
}

async function handleCheckoutCompleted(session: Stripe.Checkout.Session) {
  console.log("Processing checkout.session.completed:", session.id)

  try {
    // Find member_dues via metadata
    let memberDuesId = session.metadata?.member_dues_id

    if (!memberDuesId && session.customer) {
      // Fallback: find latest unpaid dues for this customer
      const { data: memberDues } = await supabase!
        .from("member_dues")
        .select("id")
        .eq("status", "unpaid")
        .order("created_at", { ascending: false })
        .limit(1)
        .single()

      memberDuesId = memberDues?.id
    }

    if (!memberDuesId) {
      console.error("Could not find member_dues for session:", session.id)
      return
    }

    // Get payment intent details if available
    if (session.payment_intent) {
      const paymentIntent = await stripe!.paymentIntents.retrieve(session.payment_intent as string)
      await processPayment(
        memberDuesId,
        paymentIntent,
        session.customer_details?.email,
        session.metadata?.payment_method,
      )
    }
  } catch (error) {
    console.error("Error in handleCheckoutCompleted:", error)
  }
}

async function handlePaymentSucceeded(paymentIntent: Stripe.PaymentIntent) {
  console.log("Processing payment_intent.succeeded:", paymentIntent.id)

  try {
    // Find member_dues via metadata
    let memberDuesId = paymentIntent.metadata?.member_dues_id

    if (!memberDuesId && paymentIntent.customer) {
      // Fallback: find latest unpaid dues for this customer
      const { data: memberDues } = await supabase!
        .from("member_dues")
        .select("id")
        .eq("status", "unpaid")
        .order("created_at", { ascending: false })
        .limit(1)
        .single()

      memberDuesId = memberDues?.id
    }

    if (!memberDuesId) {
      console.error("Could not find member_dues for payment intent:", paymentIntent.id)
      return
    }

    await processPayment(memberDuesId, paymentIntent, undefined, paymentIntent.metadata?.payment_method)
  } catch (error) {
    console.error("Error in handlePaymentSucceeded:", error)
  }
}

async function processPayment(
  memberDuesId: string,
  paymentIntent: Stripe.PaymentIntent,
  payerEmail?: string | null,
  paymentMethod?: string,
) {
  try {
    // Get member_dues details
    const { data: memberDues, error: memberDuesError } = await supabase!
      .from("member_dues")
      .select(`
        id,
        amount_owed,
        amount_paid,
        user:users!inner(id, email, first_name, last_name, organization_id)
      `)
      .eq("id", memberDuesId)
      .single()

    if (memberDuesError || !memberDues) {
      console.error("Error fetching member_dues:", memberDuesError)
      return
    }

    // Calculate amounts
    const totalAmount = paymentIntent.amount / 100 // Convert from cents
    const duesAmount = memberDues.amount_owed - memberDues.amount_paid
    const processingFee = Math.max(0, totalAmount - duesAmount)

    // Update member_dues status to paid
    const { error: updateError } = await supabase!
      .from("member_dues")
      .update({
        status: "paid",
        paid_at: new Date().toISOString(),
      })
      .eq("id", memberDuesId)

    if (updateError) {
      console.error("Error updating member_dues:", updateError)
      return
    }

    // Insert payment record
    const { error: paymentError } = await supabase!.from("payments").insert({
      member_dues_id: memberDuesId,
      user_id: memberDues.user.id,
      organization_id: memberDues.user.organization_id,
      amount: duesAmount,
      processing_fee: processingFee,
      payer_email: payerEmail || memberDues.user.email,
      stripe_payment_intent_id: paymentIntent.id,
      payment_method: paymentMethod || getPaymentMethodType(paymentIntent),
      paid_at: new Date().toISOString(),
    })

    if (paymentError) {
      console.error("Error inserting payment:", paymentError)
      return
    }

    console.log(
      `Successfully processed payment for member_dues ${memberDuesId}: $${totalAmount} (dues: $${duesAmount}, fee: $${processingFee})`,
    )
  } catch (error) {
    console.error("Error processing payment:", error)
    throw error
  }
}

function getPaymentMethodType(paymentIntent: Stripe.PaymentIntent): string {
  const charges = paymentIntent.charges?.data
  if (!charges || charges.length === 0) return "unknown"

  const charge = charges[0]
  const paymentMethod = charge.payment_method_details

  if (paymentMethod?.card) return "card"
  if (paymentMethod?.us_bank_account) return "ach"
  if (paymentMethod?.link) return "link"

  return paymentMethod?.type || "unknown"
}
