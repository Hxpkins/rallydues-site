"use client"
export const dynamic = "force-dynamic"

import { useMemo } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

function slugToName(slug: string) {
  return slug
    .split("-")
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
    .join(" ")
}
function dollars(n: number) {
  return n.toLocaleString(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 0 })
}
const safe = (n: any, f = 0) => (typeof n === "number" && isFinite(n) ? n : f)

export default function MemberProfileCatchAll() {
  const params = useParams<{ slug: string[] }>()
  // first segment is the real name; preview sometimes passes "[slug]" literally—fallback to a demo value
  let first = Array.isArray(params?.slug) && params.slug.length ? params.slug[0] : "quinn-patel"
  if (first.startsWith("[") && first.endsWith("]")) first = "quinn-patel"
  const slug = decodeURIComponent(String(first))

  const data = useMemo(() => {
    let h = 0
    for (let i = 0; i < slug.length; i++) h = (h * 31 + slug.charCodeAt(i)) >>> 0
    const rand = (seed: number, min: number, max: number) =>
      Math.floor(((Math.sin(seed) + 1) / 2) * (max - min + 1)) + min

    const dues = 150
    const paidCount = rand(h + 1, 6, 9)
    const totalCount = 10
    const outstanding = (totalCount - paidCount) * dues
    const collected = paidCount * dues

    const payments = Array.from({ length: 8 }, (_, i) => {
      const amt = [75, 100, 125, 150][(h + i) % 4]
      const method = (h + i) % 3 === 0 ? "ACH" : "Card"
      const d = new Date()
      d.setDate(d.getDate() - i * ((h % 3) + 1))
      return { id: `${slug}-${i}`, date: d.toISOString().slice(0, 10), amount: amt, method }
    })

    const upcoming = Array.from({ length: 4 }, (_, i) => {
      const d = new Date()
      d.setDate(d.getDate() + 2 + i * 7)
      return {
        id: `${slug}-up-${i}`,
        due: d.toISOString().slice(0, 10),
        amount: [100, 150][(h + i) % 2],
        method: (h + i) % 2 ? "Card" : "ACH",
      }
    })

    return { name: slugToName(slug), dues, collected, outstanding, paidCount, totalCount, payments, upcoming }
  }, [slug])

  return (
    <div className="container mx-auto max-w-5xl px-4 py-8">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-slate-900">{data.name}</h1>
          <p className="text-sm text-slate-600">Member profile • Demo data</p>
        </div>
        <Link href="/demo/treasurer">
          <Button variant="outline">Back to dashboard</Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-slate-600">Collected</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-semibold">{dollars(data.collected)}</CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-slate-600">Outstanding</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-semibold text-red-600">{dollars(data.outstanding)}</CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-slate-600">Payments</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-semibold">
            {data.paidCount}/{data.totalCount}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-slate-600">Dues per installment</CardTitle>
          </CardHeader>
          <CardContent className="text-2xl font-semibold">{dollars(data.dues)}</CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Recent Payments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.payments.map((p) => (
                <div key={p.id} className="flex items-center justify-between rounded border border-slate-200 p-3">
                  <div>
                    <div className="font-medium text-slate-900">{p.date}</div>
                    <div className="text-xs text-slate-600">{p.method}</div>
                  </div>
                  <div className="text-slate-900 font-medium">${safe(p.amount).toFixed(2)}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Installments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {data.upcoming.map((u) => (
                <div key={u.id} className="flex items-center justify-between rounded border border-slate-200 p-3">
                  <div>
                    <div className="font-medium text-slate-900">{u.due}</div>
                    <div className="text-xs text-slate-600">{u.method}</div>
                  </div>
                  <div className="text-slate-900 font-medium">${safe(u.amount).toFixed(2)}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
