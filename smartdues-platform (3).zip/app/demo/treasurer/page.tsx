"use client"

import { useMemo, useState, useCallback } from "react"
import { DollarSign } from "lucide-react"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FiltersBar } from "@/components/demo/treasurer/FiltersBar"
import { KpiCards } from "@/components/demo/treasurer/KpiCards"
import { TopOverdueTable } from "@/components/demo/treasurer/TopOverdueTable"
import { UpcomingInstallments } from "@/components/demo/treasurer/UpcomingInstallments"
import { RecentPayments } from "@/components/demo/treasurer/RecentPayments"
import { InsightsPanel } from "@/components/demo/treasurer/InsightsPanel"
import { Navigation } from "@/components/navigation"

// CHARTS
import CollectionsVsTarget from "@/components/demo/treasurer/charts/CollectionsVsTarget"
import AgingAnalysis from "@/components/demo/treasurer/charts/AgingAnalysis"
import PaymentMethodsPie from "@/components/demo/treasurer/charts/PaymentMethodsPie"
import CashFlowForecast from "@/components/demo/treasurer/charts/CashFlowForecast"
import ReminderImpact from "@/components/demo/treasurer/charts/ReminderImpact"

// ---------------- Mock data helpers ----------------

function seedFromString(str: string): number {
  let hash = 0
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i)
    hash |= 0
  }
  return Math.abs(hash) || 12345
}
function mulberry32(a: number) {
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t ^= t + Math.imul(t ^ (t >>> 7), 61 | t)
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}
function pick(r: () => number, min: number, max: number) {
  return min + (max - min) * r()
}

type CycleMock = {
  metrics: {
    goal: number
    totalCollected: number
    outstanding: number
    collectionRate: number
    avgDaysToPay: number
    failedPayments: number
    activeMembers: number
  }
  agingBuckets: Array<{ key: "0_7" | "8_14" | "15_30" | "30_plus"; amount: number }>
  methods: { card: number; ach: number }
  weeks: Array<{ label: string; amount: number }>
  reminders: Array<{ day: string; rate: number }>
}

function buildCycleMock(key: string): CycleMock {
  const rand = mulberry32(seedFromString(key))

  const goal = Math.round(pick(rand, 42000, 58000) / 100) * 100
  const totalCollected = Math.round(pick(rand, goal * 0.28, goal * 0.62))
  const outstanding = Math.max(0, goal - totalCollected - Math.round(pick(rand, 0, 2500)))
  const collectionRate = Math.min(99.9, (totalCollected / goal) * 100)
  const avgDaysToPay = Math.round(pick(rand, 18, 27))
  const failedPayments = Math.round(pick(rand, 1, 4))
  const activeMembers = Math.round(pick(rand, 110, 130))

  const agingBuckets: CycleMock["agingBuckets"] = [
    { key: "0_7", amount: Math.round(pick(rand, 1800, 4200)) },
    { key: "8_14", amount: Math.round(pick(rand, 1600, 3600)) },
    { key: "15_30", amount: Math.round(pick(rand, 4200, 6800)) },
    { key: "30_plus", amount: Math.round(pick(rand, 7200, 9200)) },
  ]

  const methods = { card: Math.round(pick(rand, 55, 70)), ach: Math.round(pick(rand, 25, 40)) }
  const weeks = Array.from({ length: 12 }, (_, i) => ({ label: `W${i + 1}`, amount: Math.round(pick(rand, 1200, 5400)) }))
  const reminders = ["7d", "3d", "1d", "day-of"].map((d) => ({ day: d, rate: Math.round(pick(rand, 5, 35)) }))

  return {
    metrics: { goal, totalCollected, outstanding, collectionRate, avgDaysToPay, failedPayments, activeMembers },
    agingBuckets,
    methods,
    weeks,
    reminders,
  }
}

// ---------------- Page ----------------

export default function Page() {
  const [selectedCycle, setSelectedCycle] = useState("Fall 2025")
  const mock = useMemo(() => buildCycleMock(selectedCycle), [selectedCycle])

  const [searchQuery, setSearchQuery] = useState("")
  const [agingFilter, setAgingFilter] = useState<"0_7" | "8_14" | "15_30" | "30_plus" | null>(null)
  const [methodFilter, setMethodFilter] = useState<string | null>(null)

  const handleKpiCardClick = useCallback((scrollTarget: string) => {
    const el = document.getElementById(scrollTarget)
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" })
  }, [])
  const handleAgingFilterChange = useCallback((b: "0_7" | "8_14" | "15_30" | "30_plus") => setAgingFilter(b), [])
  const handleMethodFilterChange = useCallback((m: string | null) => setMethodFilter(m), [])

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="mx-auto max-w-screen-2xl w-full px-4 h-16 flex items-center justify-between relative">
          <Link
            href="/"
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 rounded-lg"
          >
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-slate-900">RallyDues</span>
          </Link>

          <div className="absolute left-1/2 transform -translate-x-1/2">
            <Navigation />
          </div>

          <div className="hidden md:flex items-center space-x-2 text-sm text-slate-600">
            <span>Alpha Beta Gamma</span>
            <span>—</span>
            <span>Delta Chapter</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-screen-2xl w-full px-4 py-6 pt-4">
        {/* Title + Subtitle */}
        <section className="mb-4">
          <h1 className="text-3xl font-semibold tracking-tight text-slate-900">Treasurer Dashboard</h1>
          <p className="text-sm text-slate-600">Alpha Beta Gamma — Delta Chapter</p>
        </section>

        {/* Toolbar AT THE TOP */}
        <FiltersBar
          selectedCycle={selectedCycle}
          onCycleChange={setSelectedCycle}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />

        {/* Single-column content */}
        <div className="flex flex-col gap-8 w-full mt-4">
          {/* KPI Cards: 2 rows × 3 */}
          <div id="kpi-cards">
            <KpiCards onCardClick={handleKpiCardClick} />
          </div>

          {/* Collections & Aging row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 min-w-0" id="collections-chart">
              <Card className="overflow-hidden">
                <CardHeader>
                  <CardTitle>Collections vs Target</CardTitle>
                </CardHeader>
                <CardContent>
                  <CollectionsVsTarget goal={mock.metrics.goal} />
                </CardContent>
              </Card>
            </div>

            <div className="min-w-0">
              <Card className="overflow-hidden">
                <CardHeader>
                  <CardTitle>Aging Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <AgingAnalysis onFilterChange={(k) => k && handleAgingFilterChange(k as any)} activeFilter={agingFilter} />
                </CardContent>
              </Card>
            </div>

            <div className="min-w-0">
              <Card className="overflow-hidden">
                <CardHeader>
                  <CardTitle>Payment Methods</CardTitle>
                </CardHeader>
                <CardContent>
                  <PaymentMethodsPie cardPct={mock.methods.card} achPct={mock.methods.ach} />
                  <p className="text-xs text-slate-500 mt-2">Card includes processing fees • ACH no fee</p>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-2 min-w-0">
              <Card className="overflow-hidden">
                <CardHeader>
                  <CardTitle>Cash Flow Forecast</CardTitle>
                </CardHeader>
                <CardContent>
                  <CashFlowForecast weeks={mock.weeks} />
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Reminder Impact */}
          <Card className="overflow-hidden">
            <CardHeader>
              <CardTitle>Reminder Impact</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="w-full min-h-[260px]">
                <ReminderImpact points={mock.reminders} />
              </div>
            </CardContent>
          </Card>

          {/* Insights */}
          <div>
            <InsightsPanel />
          </div>

          {/* Tables as 3 ROWS (full width) */}
          <div className="flex flex-col gap-6">
            <div className="min-w-0" id="top-overdue">
              <TopOverdueTable searchQuery={searchQuery} agingFilter={agingFilter} />
            </div>
            <div className="min-w-0">
              <UpcomingInstallments searchQuery={searchQuery} />
            </div>
            <div className="min-w-0" id="recent-payments">
              <RecentPayments searchQuery={searchQuery} methodFilter={methodFilter} />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
