"use client"

import * as React from "react"
import CollectionsVsTarget, {
  type CollectionsPoint,
} from "@/components/demo/treasurer/charts/CollectionsVsTarget"

export default function ServerDataWrapper({
  chapterId,
  goal = 50000,
}: {
  chapterId: string
  goal?: number
}) {
  const [data, setData] = React.useState<CollectionsPoint[] | null>(null)

  React.useEffect(() => {
    let cancelled = false
    ;(async () => {
      try {
        // TODO: replace with real fetch when you have an API:
        // const res = await fetch(`/api/collections?chapterId=${chapterId}`, { cache: "no-store" })
        // const json: CollectionsPoint[] = await res.json()
        const json: CollectionsPoint[] = [] // return [] to trigger chart's sample fallback
        if (!cancelled) setData(json)
      } catch (e) {
        console.error(e)
        if (!cancelled) setData([]) // fall back to sample data in the chart
      }
    })()
    return () => { cancelled = true }
  }, [chapterId])

  return <CollectionsVsTarget data={data ?? undefined} goal={goal} />
}
