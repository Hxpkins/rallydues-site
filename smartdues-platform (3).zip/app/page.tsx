"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Users, CreditCard, BarChart3, Bell, Shield, Zap, DollarSign } from "lucide-react"
import Link from "next/link"
import { Navigation } from "@/components/navigation"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="bg-white border-b border-[var(--border)] sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
          </Link>

          <Navigation />

          <div className="flex items-center space-x-3">
            <Link href="/signin">
              <Button
                variant="outline"
                size="sm"
                className="border border-[var(--border)] text-[var(--text)] hover:bg-[var(--surface-alt)] bg-transparent rounded-lg px-4 py-2.5"
              >
                Sign In
              </Button>
            </Link>
            <Link href="/quick-pay">
              <Button
                variant="outline"
                size="sm"
                className="border border-blue-200 hover:bg-blue-50 rounded-lg px-4 py-2.5 bg-blue-600 text-white"
              >
                Quick Pay
              </Button>
            </Link>
            <Link href="/signup">
              <Button
                size="sm"
                className="bg-[var(--accent)] text-white hover:brightness-110 rounded-lg px-4 py-2.5 bg-orange-500"
              >
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <section className="pt-12 px-4 bg-slate-50 pb-2 md:pt-8">
        <div className="container mx-auto text-center max-w-4xl">
          <Badge variant="secondary" className="mb-4 bg-[var(--surface-alt)] text-[var(--text)]">
            Trusted by 1,000+ Organizations
          </Badge>

          <h1 className="text-[40px] md:text-[56px] font-semibold leading-tight tracking-[-0.01em] text-[var(--text)] text-center mb-6">
            Collect dues, track expenses & <span className="text-[var(--primary)] text-blue-500">manage members</span>{" "}
            online.
          </h1>

          <p className="mt-4 text-base md:text-lg text-[var(--subtext)] max-w-3xl mx-auto text-center mb-8">
            Designed for fraternities, sororities, and more. Streamline your organization's finances with automated dues
            collection, payment plans, and comprehensive member management.
          </p>

          <div className="mt-8 flex items-center justify-center gap-3 mb-12">
            <Link href="/signup">
              <Button
                size="lg"
                className="inline-flex items-center rounded-lg bg-[var(--accent)] px-5 py-2.5 text-white hover:brightness-110 bg-orange-500"
              >
                Start Free Trial
              </Button>
            </Link>
            <Link href="/contact">
              <Button
                size="lg"
                variant="outline"
                className="border border-[var(--border)] text-[var(--text)] hover:bg-[var(--surface-alt)] bg-transparent rounded-lg px-4 py-2.5"
              >
                Schedule Demo
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <section className="px-4 bg-white py-16">
        <div className="container mx-auto max-w-4xl">
          <div className="relative">
            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-8">
              <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                <div className="bg-[var(--surface-alt)] px-4 py-2 flex items-center space-x-2">
                  <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                  <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                  <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-[var(--subtext)]">Total Collected</p>
                          <p className="text-2xl font-semibold text-emerald-600">$47,250</p>
                        </div>
                        <div className="w-12 h-12 bg-emerald-50 rounded-full flex items-center justify-center">
                          <CheckCircle className="w-6 h-6 text-emerald-600" />
                        </div>
                      </div>
                    </div>
                    <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-[var(--subtext)]">Outstanding</p>
                          <p className="text-2xl font-semibold text-orange-600">$12,750</p>
                        </div>
                        <div className="w-12 h-12 bg-orange-50 rounded-full flex items-center justify-center">
                          <CreditCard className="w-6 h-6 text-orange-600" />
                        </div>
                      </div>
                    </div>
                    <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-[var(--subtext)]">Active Members</p>
                          <p className="text-2xl font-semibold text-blue-600">127</p>
                        </div>
                        <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center">
                          <Users className="w-6 h-6 text-blue-600" />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-[var(--surface-alt)] rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-[var(--text)]">Recent Payments</h3>
                      <Badge variant="secondary" className="bg-white text-[var(--text)]">
                        Live Data
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-[var(--text)]">John Smith - Fall 2025 Dues</span>
                        <span className="text-sm font-medium text-emerald-600">$750.00</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-[var(--text)]">Sarah Johnson - Payment Plan (2/3)</span>
                        <span className="text-sm font-medium text-blue-600">$250.00</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="px-4 bg-[var(--surface-alt)] py-16 bg-slate-50">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-semibold mb-4 text-[var(--text)]">
              Everything you need to easily manage the finances of your group.
            </h2>
            <p className="text-xl text-[var(--subtext)] max-w-2xl mx-auto">
              Comprehensive tools designed specifically for Greek life organizations and membership groups.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm text-center p-6">
              <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <CreditCard className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-[var(--text)]">Collect Dues & Send Invoices</h3>
              <p className="text-sm text-[var(--subtext)]">
                Automated dues collection with flexible payment plans. Accept cards (incl. Apple Pay & Google Pay via
                Stripe) and ACH payments.
              </p>
            </div>

            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm text-center p-6">
              <div className="w-16 h-16 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-emerald-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-[var(--text)]">Member Management</h3>
              <p className="text-sm text-[var(--subtext)]">
                Import rosters, track member status, and manage custom dues amounts with ease.
              </p>
            </div>

            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm text-center p-6">
              <div className="w-16 h-16 bg-purple-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-[var(--text)]">Financial Analytics</h3>
              <p className="text-sm text-[var(--subtext)]">
                Real-time dashboards showing collection rates, outstanding balances, and payment trends.
              </p>
            </div>

            <div className="rounded-2xl border border-[var(--border)] bg-[var(--surface)] shadow-sm text-center p-6">
              <div className="w-16 h-16 bg-orange-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <Bell className="w-8 h-8 text-orange-600" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-[var(--text)]">Smart Reminders</h3>
              <p className="text-sm text-[var(--subtext)]">
                Automated email reminders for upcoming dues and overdue payments via Stripe.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="px-4 bg-white py-16">
        <div className="container mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-semibold mb-6 text-[var(--text)]">
                Flexible Payment Plans That Work
              </h2>
              <p className="text-lg text-[var(--subtext)] mb-8">
                Allow members to request installment plans before the cutoff date. First payment still due on time, with
                automatic scheduling for remaining installments.
              </p>

              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">Custom Payment Schedules</h4>
                    <p className="text-sm text-[var(--subtext)]">
                      Create 2, 3, or 4-installment plans with flexible due dates
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">Automatic Processing</h4>
                    <p className="text-sm text-[var(--subtext)]">
                      Stripe handles recurring payments and sends reminders automatically
                    </p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-5 h-5 text-emerald-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-[var(--text)]">Treasurer Approval</h4>
                    <p className="text-sm text-[var(--subtext)]">
                      All payment plans require treasurer approval before activation
                    </p>
                  </div>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-[var(--border)] bg-emerald-50 shadow-sm p-8">
              <div className="bg-white rounded-xl p-6 shadow-lg">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-emerald-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold text-white">$750</span>
                  </div>
                  <h3 className="text-lg font-semibold text-[var(--text)]">Fall 2025 Dues</h3>
                  <p className="text-sm text-[var(--subtext)]">Due October 15, 2025</p>
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-[var(--surface-alt)] rounded-lg">
                    <span className="text-sm font-medium text-[var(--subtext)]">Payment 1 (Oct 15)</span>
                    <span className="text-sm font-bold text-[var(--text)]">$250.00</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-[var(--surface-alt)] rounded-lg">
                    <span className="text-sm font-medium text-[var(--subtext)]">Payment 2 (Nov 15)</span>
                    <span className="text-sm font-bold text-[var(--text)]">$250.00</span>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-[var(--surface-alt)] rounded-lg">
                    <span className="text-sm font-medium text-[var(--subtext)]">Payment 3 (Dec 15)</span>
                    <span className="text-sm font-bold text-[var(--text)]">$250.00</span>
                  </div>
                </div>

                <Button className="w-full mt-6 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg px-4 py-2.5">
                  Request Payment Plan
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 px-4 bg-[var(--surface-alt)] bg-slate-50">
        <div className="container mx-auto text-center">
          <div className="max-w-3xl mx-auto">
            <Shield className="w-16 h-16 text-[var(--primary)] mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl font-semibold mb-6 text-[var(--text)]">
              Bank-Level Security & Compliance
            </h2>
            <p className="text-lg text-[var(--subtext)] mb-8">
              Built on Stripe Connect with enterprise-grade security. Your organization's financial data is protected
              with the same technology trusted by millions of businesses worldwide.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold mb-2 text-[var(--text)]">PCI Compliant</h3>
                <p className="text-sm text-[var(--subtext)]">Highest level of payment security standards</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Zap className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold mb-2 text-[var(--text)]">Instant Transfers</h3>
                <p className="text-sm text-[var(--subtext)]">Funds deposited directly to your organization's account</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold mb-2 text-[var(--text)]">Multi-Tenant</h3>
                <p className="text-sm text-[var(--subtext)]">Complete data isolation between organizations</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="px-4 bg-white py-16">
        <div className="container mx-auto text-center max-w-6xl">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-semibold mb-6 text-[var(--text)]">
              RallyDues makes it ridiculously easy for your members to pay online and on time.
            </h2>
            <p className="text-lg text-[var(--subtext)] mb-8">
              Join thousands of organizations that have streamlined their financial management with RallyDues.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/signup">
                <Button
                  size="lg"
                  className="bg-[var(--accent)] hover:brightness-110 text-white px-8 rounded-lg py-2.5 bg-orange-500"
                >
                  Start Your Free Trial
                </Button>
              </Link>
              <Link href="/contact">
                <Button
                  size="lg"
                  variant="outline"
                  className="border border-[var(--border)] text-[var(--text)] hover:bg-[var(--surface-alt)] rounded-lg px-8 py-2.5 bg-transparent"
                >
                  Schedule a Demo
                </Button>
              </Link>
            </div>

            <p className="text-sm text-[var(--subtext)] mt-4">
              No credit card required • 30-day free trial • Cancel anytime
            </p>
          </div>
        </div>
      </section>

      <footer className="border-t border-[var(--border)] bg-[var(--surface-alt)] py-12 px-4 bg-slate-50">
        <div className="container mx-auto max-w-6xl">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-semibold text-[var(--text)]">RallyDues</span>
              </div>
              <p className="text-sm text-[var(--subtext)]">
                The modern dues management platform for Greek life organizations and membership groups.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-[var(--text)]">Product</h4>
              <ul className="space-y-2 text-sm text-[var(--subtext)]">
                <li>
                  <Link href="/pricing" className="hover:text-[var(--text)]">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="/quick-pay" className="hover:text-[var(--text)]">
                    Quick Pay
                  </Link>
                </li>
                <li>
                  <Link href="/demo/treasurer" className="hover:text-[var(--text)]">
                    Treasurer Demo
                  </Link>
                </li>
                <li></li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-[var(--text)]">Company</h4>
              <ul className="space-y-2 text-sm text-[var(--subtext)]">
                <li>
                  <Link href="/about" className="hover:text-[var(--text)]">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-[var(--text)]">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/security" className="hover:text-[var(--text)]">
                    Security
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-[var(--text)]">Legal</h4>
              <ul className="space-y-2 text-sm text-[var(--subtext)]">
                <li>
                  <Link href="/legal/terms" className="hover:text-[var(--text)]">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <Link href="/legal/privacy" className="hover:text-[var(--text)]">
                    Privacy Policy
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-[var(--border)] mt-8 pt-8 text-center text-sm text-[var(--subtext)]">
            <p>&copy; 2025 RallyDues. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
