export const organization = {
  name: "Alpha Beta",
  chapter: "State U",
  slug: "ab-stateu",
}

export const kpis = {
  totalCollected: 47250,
  outstanding: 12750,
  activeMembers: 127,
  duesCycles: 2,
}

export const members = [
  {
    id: 1,
    name: "John Smith",
    email: "john.smith@email.com",
    paycode: "ABG123",
    status: "Paid",
    balance: 0,
    role: "member",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah.j@email.com",
    paycode: "ABG124",
    status: "Pending",
    balance: 750,
    role: "member",
  },
  {
    id: 3,
    name: "Mike Davis",
    email: "mike.davis@email.com",
    paycode: "ABG125",
    status: "Overdue",
    balance: 775,
    role: "member",
  },
  {
    id: 4,
    name: "Emily Chen",
    email: "emily.chen@email.com",
    paycode: "ABG126",
    status: "Paid",
    balance: 0,
    role: "member",
  },
  {
    id: 5,
    name: "Alex Rodriguez",
    email: "alex.r@email.com",
    paycode: "ABG127",
    status: "Pending",
    balance: 750,
    role: "member",
  },
  {
    id: 6,
    name: "Jessica Taylor",
    email: "jessica.t@email.com",
    paycode: "ABG128",
    status: "Paid",
    balance: 0,
    role: "member",
  },
  {
    id: 7,
    name: "David Wilson",
    email: "david.w@email.com",
    paycode: "ABG129",
    status: "Overdue",
    balance: 775,
    role: "member",
  },
  {
    id: 8,
    name: "Lisa Brown",
    email: "lisa.brown@email.com",
    paycode: "ABG130",
    status: "Pending",
    balance: 375,
    role: "member",
  },
  {
    id: 9,
    name: "Ryan Martinez",
    email: "ryan.m@email.com",
    paycode: "ABG131",
    status: "Paid",
    balance: 0,
    role: "member",
  },
  {
    id: 10,
    name: "Amanda White",
    email: "amanda.w@email.com",
    paycode: "ABG132",
    status: "Pending",
    balance: 750,
    role: "member",
  },
]

export const payments = [
  {
    id: 1,
    memberName: "John Smith",
    label: "Fall 2025 Dues",
    timestamp: "2:14 PM",
    amount: 750.0,
    status: "Succeeded",
  },
  {
    id: 2,
    memberName: "Sarah Johnson",
    label: "Payment Plan (2/3)",
    timestamp: "10:03 AM",
    amount: 250.0,
    status: "Succeeded",
  },
  {
    id: 3,
    memberName: "Emily Chen",
    label: "Fall 2025 Dues",
    timestamp: "Yesterday",
    amount: 750.0,
    status: "Succeeded",
  },
  {
    id: 4,
    memberName: "Jessica Taylor",
    label: "Chapter Fees",
    timestamp: "Yesterday",
    amount: 125.0,
    status: "Succeeded",
  },
  {
    id: 5,
    memberName: "Ryan Martinez",
    label: "Fall 2025 Dues",
    timestamp: "2 days ago",
    amount: 750.0,
    status: "Succeeded",
  },
  {
    id: 6,
    memberName: "Alex Rodriguez",
    label: "Payment Plan (1/3)",
    timestamp: "3 days ago",
    amount: 250.0,
    status: "Succeeded",
  },
]

export const duesCycles = [
  {
    id: 1,
    name: "Fall 2025 Dues",
    dueDate: "2025-10-15",
    amount: 750,
    lateFee: 25,
    status: "Active",
    graceDays: 7,
  },
  {
    id: 2,
    name: "Chapter Fees",
    dueDate: "2025-11-01",
    amount: 125,
    lateFee: 10,
    status: "Active",
    graceDays: 3,
  },
]

export const memberDues = {
  subtotal: 750.0,
  processingFee: 23.25,
  total: 773.25,
}

export const memberPaymentHistory = [
  {
    id: 1,
    description: "Spring 2025 Dues",
    date: "2025-03-15",
    amount: 750.0,
    status: "Paid",
  },
  {
    id: 2,
    description: "Chapter Fees",
    date: "2025-02-01",
    amount: 125.0,
    status: "Paid",
  },
]
