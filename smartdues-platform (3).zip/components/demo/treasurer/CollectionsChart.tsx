"use client"

import { useState } from "react"
import { Area, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Line, ComposedChart } from "recharts"
import { useDemoStore } from "@/lib/demo/mockStore"
import { Button } from "@/components/ui/button"

type DateRange = "30d" | "60d" | "cycle" | "ytd"

export function CollectionsChart() {
  const [selectedRange, setSelectedRange] = useState<DateRange>("60d")

  const storeData = useDemoStore((s) => s.collections60d)
  const data =
    storeData && storeData.length
      ? storeData
      : [
          { date: "2025-01-01", collected: 1000, target: 900 },
          { date: "2025-01-02", collected: 1800, target: 1700 },
          { date: "2025-01-03", collected: 2500, target: 2500 },
        ]

  const getRangeDays = (range: DateRange): number => {
    switch (range) {
      case "30d":
        return 30
      case "60d":
        return 60
      case "cycle":
        return 90
      case "ytd":
        return 365
      default:
        return 60
    }
  }

  const filteredData = data.slice(-getRangeDays(selectedRange))

  const formatCurrency = (value: number) => {
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}k`
    }
    return `$${value.toFixed(0)}`
  }

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white p-3 border border-slate-200 rounded-lg shadow-sm">
          <p className="text-sm font-medium text-slate-900 mb-2">{formatDate(label)}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {entry.name}: {formatCurrency(entry.value)}
            </p>
          ))}
        </div>
      )
    }
    return null
  }

  const rangeOptions = [
    { key: "30d", label: "Last 30d" },
    { key: "60d", label: "Last 60d" },
    { key: "cycle", label: "This cycle" },
    { key: "ytd", label: "YTD" },
  ]

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold text-slate-900 mb-2">Collections vs Target</h3>
          <p className="text-sm text-slate-600">Cumulative collections compared to target timeline</p>
        </div>

        <div className="flex gap-1 bg-slate-100 rounded-lg p-1">
          {rangeOptions.map((option) => (
            <Button
              key={option.key}
              variant={selectedRange === option.key ? "default" : "ghost"}
              size="sm"
              onClick={() => setSelectedRange(option.key as DateRange)}
              className={`text-xs px-3 py-1 h-auto ${
                selectedRange === option.key
                  ? "bg-white shadow-sm text-slate-900"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              {option.label}
            </Button>
          ))}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <ComposedChart data={filteredData} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis
            dataKey="date"
            tickFormatter={formatDate}
            tick={{ fontSize: 12, fill: "#64748b" }}
            axisLine={{ stroke: "#e2e8f0" }}
          />
          <YAxis
            tickFormatter={formatCurrency}
            tick={{ fontSize: 12, fill: "#64748b" }}
            axisLine={{ stroke: "#e2e8f0" }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend
            wrapperStyle={{ paddingTop: "20px" }}
            iconType="line"
            formatter={(value) => <span style={{ color: "#374151" }}>{value}</span>}
          />

          <Area
            type="monotone"
            dataKey="collected"
            stroke="#10b981"
            fill="#10b981"
            fillOpacity={0.1}
            strokeWidth={2}
            name="Collected"
          />

          <Line
            type="monotone"
            dataKey="target"
            stroke="#6b7280"
            strokeWidth={2}
            strokeDasharray="5 5"
            dot={false}
            name="Target"
          />
        </ComposedChart>
      </ResponsiveContainer>

      <div className="mt-4 text-xs text-slate-600">
        Target line shows expected collections based on linear progression to due date
      </div>
    </div>
  )
}
