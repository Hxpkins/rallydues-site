"use client"

import { type PropsWithChildren, useEffect, useState } from "react"

export default function ChartBase({ children, className = "h-72" }: PropsWithChildren<{ className?: string }>) {
  // Recharts needs client-only to avoid SSR blanks
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])
  if (!mounted) return <div className={`w-full ${className}`} />

  return <div className={`w-full ${className}`}>{children}</div>
}
