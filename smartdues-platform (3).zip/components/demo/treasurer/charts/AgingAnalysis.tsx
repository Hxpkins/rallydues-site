"use client"

import * as React from "react"

type BucketKey = "0_7" | "8_14" | "15_30" | "30_plus"
type Bucket = { key: BucketKey; amount: number; members: number }

const LABELS: Record<BucketKey, string> = {
  "0_7": "0–7 days",
  "8_14": "8–14 days",
  "15_30": "15–30 days",
  "30_plus": "30+ days",
}

const COLORS: Record<BucketKey, string> = {
  "0_7": "#facc15", // amber
  "8_14": "#fb923c", // orange
  "15_30": "#ef4444", // red
  "30_plus": "#991b1b", // dark red
}

export default function AgingAnalysis({
  buckets: external,
  onBucketClick,
}: {
  buckets?: Bucket[]
  onBucketClick?: (bucket: BucketKey) => void
}) {
  // Sample fallback
  const sample: Bucket[] =
    external ??
    [
      { key: "0_7", amount: 1800, members: 6 },
      { key: "8_14", amount: 3200, members: 9 },
      { key: "15_30", amount: 6400, members: 14 },
      { key: "30_plus", amount: 9100, members: 17 },
    ]

  const max = Math.max(...sample.map((b) => b.amount), 1)

  // Tooltip state
  const containerRef = React.useRef<HTMLDivElement | null>(null)
  const [tip, setTip] = React.useState<{
    x: number
    y: number
    b: Bucket
  } | null>(null)

  const showTip = (
    e: React.MouseEvent<HTMLButtonElement> | React.TouchEvent<HTMLButtonElement>,
    b: Bucket
  ) => {
    const rect = containerRef.current?.getBoundingClientRect()
    if (!rect) return

    // Get pointer position
    let clientX = 0
    let clientY = 0
    if ("touches" in e && e.touches.length) {
      clientX = e.touches[0].clientX
      clientY = e.touches[0].clientY
    } else if ("nativeEvent" in e) {
      const me = (e as React.MouseEvent).nativeEvent
      clientX = (me as MouseEvent).clientX
      clientY = (me as MouseEvent).clientY
    }

    const rawX = clientX - rect.left
    const rawY = clientY - rect.top

    // Clamp tooltip inside the card
    const width = (containerRef.current as HTMLDivElement).offsetWidth
    const height = (containerRef.current as HTMLDivElement).offsetHeight
    const boxW = 200
    const boxH = 60
    const x = Math.min(Math.max(rawX + 12, 8), width - boxW - 8)
    const y = Math.min(Math.max(rawY - boxH - 8, 8), height - boxH - 8)

    setTip({ x, y, b })
  }

  const hideTip = () => setTip(null)

  const money = (n: number) =>
    n >= 1000 ? `$${(n / 1000).toFixed(1)}k` : `$${n.toLocaleString()}`

  return (
    <div
      ref={containerRef}
      className="bg-white rounded-lg p-4 space-y-3 relative"
      onMouseLeave={hideTip}
    >
      {sample.map((b) => (
        <button
          key={b.key}
          onClick={() => onBucketClick?.(b.key)}
          onMouseMove={(e) => showTip(e, b)}
          onTouchStart={(e) => showTip(e, b)}
          onTouchMove={(e) => showTip(e, b)}
          onTouchEnd={hideTip}
          className="w-full text-left"
          aria-label={`Filter table to ${LABELS[b.key]} past due`}
        >
          <div className="flex items-center justify-between text-sm mb-1">
            <span className="text-slate-700">{LABELS[b.key]}</span>
            <span className="tabular-nums text-slate-900">{money(b.amount)}</span>
          </div>
          <div className="h-3 rounded bg-slate-100 overflow-hidden">
            <div
              className="h-full rounded"
              style={{
                width: `${(b.amount / max) * 100}%`,
                backgroundColor: COLORS[b.key],
                transition: "width 200ms ease",
              }}
              title={`${b.members} members • ${money(b.amount)}`}
            />
          </div>
        </button>
      ))}

      {/* Hover tooltip */}
      {tip && (
        <div
          role="tooltip"
          className="absolute pointer-events-none rounded-md border border-slate-200 bg-white shadow-sm px-3 py-2"
          style={{ left: tip.x, top: tip.y, width: 200 }}
        >
          <div className="text-xs font-semibold text-slate-900">
            {LABELS[tip.b.key]}
          </div>
          <div className="text-xs text-slate-700 mt-0.5">
            <span className="tabular-nums">{tip.b.members}</span> members
            <span className="mx-1 text-slate-400">•</span>
            Outstanding <span className="tabular-nums">{money(tip.b.amount)}</span>
          </div>
        </div>
      )}

      <p className="text-xs text-slate-500 mt-2">
        Hover to see members and outstanding dollars. Click a bucket to filter the Overdue table.
      </p>
    </div>
  )
}
