"use client"

import * as React from "react"

type Point = { day: string; rate: number }

/**
 * ReminderImpact — LINE CHART with precise hover tooltip
 * - Responsive (viewBox) + accurate pointer mapping (SVG CTM inverse)
 * - Tooltip is anchored to the nearest data point and clamped inside plot
 */
export default function ReminderImpact({
  points,
  height = 260,
}: {
  points?: Point[]
  height?: number
}) {
  // -------- Data (fallback if none provided) --------
  const data: Point[] =
    points && points.length
      ? points
      : [
          { day: "7d", rate: 12 },
          { day: "3d", rate: 32 },
          { day: "1d", rate: 28 },
          { day: "day-of", rate: 12 },
        ]

  // -------- Layout --------
  const PAD = { top: 16, right: 20, bottom: 36, left: 48 }
  const BASE_WIDTH = 800        // logical width; scales via viewBox
  const BASE_HEIGHT = height    // height in SVG units

  const innerW = BASE_WIDTH - PAD.left - PAD.right
  const innerH = BASE_HEIGHT - PAD.top - PAD.bottom

  const maxYRaw = Math.max(1, ...data.map(d => d.rate))
  const maxY = Math.ceil((maxYRaw * 1.15) / 5) * 5 // headroom + round to nice tick

  const xAt = (i: number) => PAD.left + (i / Math.max(1, data.length - 1)) * innerW
  const yAt = (v: number) => PAD.top + innerH - (v / maxY) * innerH

  // -------- Paths --------
  const linePath = data.map((d, i) => `${i ? "L" : "M"} ${xAt(i)} ${yAt(d.rate)}`).join(" ")
  const areaPath =
    `M ${xAt(0)} ${yAt(data[0].rate)} ` +
    data.slice(1).map((d, i) => `L ${xAt(i + 1)} ${yAt(d.rate)}`).join(" ") +
    ` L ${xAt(data.length - 1)} ${PAD.top + innerH}` +
    ` L ${xAt(0)} ${PAD.top + innerH} Z`

  const yTicks = [0, 0.25, 0.5, 0.75, 1].map(p => Math.round(p * maxY))

  // -------- Hover state + precise coordinate mapping --------
  const [hoverIdx, setHoverIdx] = React.useState<number | null>(null)
  const svgRef = React.useRef<SVGSVGElement | null>(null)

  // Convert client (screen) coords -> SVG coords (accounts for scaling/zoom)
  const clientToSvg = React.useCallback((clientX: number, clientY: number) => {
    const svg = svgRef.current
    if (!svg) return null
    const pt = (svg as any).createSVGPoint ? (svg as any).createSVGPoint() : null
    if (pt) {
      pt.x = clientX
      pt.y = clientY
      const ctm = svg.getScreenCTM()
      if (ctm && (ctm as any).inverse) {
        const p = pt.matrixTransform((ctm as any).inverse())
        return { x: p.x as number, y: p.y as number }
      }
    }
    // Fallback: scale via bounding rect
    const r = svg.getBoundingClientRect()
    const scaleX = BASE_WIDTH / r.width
    const scaleY = BASE_HEIGHT / r.height
    return { x: (clientX - r.left) * scaleX, y: (clientY - r.top) * scaleY }
  }, [])

  const indexFromClient = React.useCallback((clientX: number, clientY: number) => {
    const p = clientToSvg(clientX, clientY)
    if (!p) return null
    const rel = (p.x - PAD.left) / Math.max(1, innerW) // 0..1 within plot
    if (rel < 0 || rel > 1) return null
    const idx = Math.round(rel * (data.length - 1))
    return Math.max(0, Math.min(data.length - 1, idx))
  }, [clientToSvg, innerW, data.length])

  const handlePointerMove = (e: React.PointerEvent<SVGRectElement>) => {
    const idx = indexFromClient(e.clientX, e.clientY)
    setHoverIdx(idx)
  }
  const handlePointerLeave = () => setHoverIdx(null)

  const hoverPoint = hoverIdx != null ? data[hoverIdx] : null
  const hx = hoverIdx != null ? xAt(hoverIdx) : null
  const hy = hoverPoint ? yAt(hoverPoint.rate) : null

  // -------- Tooltip position (anchored to data point, clamped) --------
  let tipRect: { x: number; y: number; w: number; h: number } | null = null
  if (hoverPoint && hx != null && hy != null) {
    const text = `${hoverPoint.day}: ${hoverPoint.rate}%`
    const w = Math.max(72, 12 + text.length * 7)  // approx text width
    const h = 24
    let x = hx - w / 2
    let y = hy - h - 10
    // clamp inside plot area
    const minX = PAD.left
    const maxX = BASE_WIDTH - PAD.right - w
    const minY = PAD.top
    if (x < minX) x = minX
    if (x > maxX) x = maxX
    if (y < minY) y = hy + 10      // place below the point if too close to top
    tipRect = { x, y, w, h }
  }

  return (
    <div className="w-full" style={{ minHeight: BASE_HEIGHT }}>
      <svg
        ref={svgRef}
        role="img"
        aria-label="Reminder impact line chart"
        viewBox={`0 0 ${BASE_WIDTH} ${BASE_HEIGHT}`}
        width="100%"
        height={BASE_HEIGHT}
        preserveAspectRatio="xMidYMid meet"
        style={{ display: "block" }}
      >
        {/* Y grid + labels */}
        {yTicks.map((t, i) => (
          <g key={`gy-${i}`}>
            <line x1={PAD.left} x2={BASE_WIDTH - PAD.right} y1={yAt(t)} y2={yAt(t)} stroke="#e5e7eb" />
            <text
              x={PAD.left - 8}
              y={yAt(t)}
              alignmentBaseline="middle"
              textAnchor="end"
              fontSize="11"
              fill="#64748b"
            >
              {t}%
            </text>
          </g>
        ))}

        {/* X labels */}
        {data.map((d, i) => (
          <text key={`gx-${d.day}`} x={xAt(i)} y={BASE_HEIGHT - PAD.bottom + 18} textAnchor="middle" fontSize="12" fill="#475569">
            {d.day}
          </text>
        ))}

        {/* Area + line + dots */}
        <path d={areaPath} fill="#dbeafe" />
        <path d={linePath} fill="none" stroke="#2563eb" strokeWidth={3} />
        {data.map((d, i) => <circle key={`dot-${i}`} cx={xAt(i)} cy={yAt(d.rate)} r={3.5} fill="#2563eb" />)}

        {/* Hover crosshair + marker */}
        {hoverPoint && hx != null && hy != null && (
          <>
            <line x1={hx} x2={hx} y1={PAD.top} y2={PAD.top + innerH} stroke="#e2e8f0" strokeDasharray="3 3" />
            <circle cx={hx} cy={hy} r={5} fill="#2563eb" />
          </>
        )}

        {/* Tooltip box anchored to point */}
        {tipRect && hoverPoint && (
          <g>
            <rect x={tipRect.x} y={tipRect.y} width={tipRect.w} height={tipRect.h} rx={6} fill="white" stroke="#cbd5e1" />
            <text
              x={tipRect.x + tipRect.w / 2}
              y={tipRect.y + tipRect.h / 2}
              textAnchor="middle"
              alignmentBaseline="middle"
              fontSize="12"
              fill="#0f172a"
            >
              {hoverPoint.day}: {hoverPoint.rate}%
            </text>
          </g>
        )}

        {/* Invisible overlay to capture pointer across the plot area */}
        <rect
          x={PAD.left}
          y={PAD.top}
          width={innerW}
          height={innerH}
          fill="transparent"
          pointerEvents="all"
          onPointerMove={handlePointerMove}
          onPointerLeave={handlePointerLeave}
        />
      </svg>

      {!hoverPoint && (
        <div className="mt-2 text-xs text-slate-500">Hover the line to see reminder response rates.</div>
      )}
    </div>
  )
}
