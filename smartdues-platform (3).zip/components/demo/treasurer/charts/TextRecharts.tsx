'use client'

import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from 'recharts'

const data = [
  { w: 'W1', v: 1200 },
  { w: 'W2', v: 1500 },
  { w: 'W3', v: 2100 },
  { w: 'W4', v: 1800 },
  { w: 'W5', v: 2400 },
]

export default function TestRecharts() {
  // IMPORTANT: parent must have a fixed (not auto) height
  return (
    <div className="h-[280px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="w" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="v" stroke="#111827" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
