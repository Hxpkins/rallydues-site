"use client"

import * as React from "react"

export default function PaymentMethodsPie({
  data,
  onSliceClick,
}: {
  data?: { card: number; ach: number } // optional amounts; if omitted, uses 69/31
  onSliceClick?: (method: "card" | "ach" | null) => void
}) {
  const totals = data ?? { card: 69, ach: 31 } // same 69/31 split
  const sum = Math.max(totals.card + totals.ach, 1)

  const segments = [
    { key: "Card", method: "card" as const, value: totals.card / sum, color: "#2563eb" },
    { key: "ACH", method: "ach" as const, value: totals.ach / sum, color: "#10b981" },
  ]

  // For center label: largest by default
  const largest =
    segments[0].value >= segments[1].value ? segments[0] : segments[1]

  // Tooltip state
  const wrapRef = React.useRef<HTMLDivElement | null>(null)
  const [tip, setTip] = React.useState<{
    x: number
    y: number
    key: string
    pct: number
  } | null>(null)

  const showTip = (
    e: React.MouseEvent<SVGPathElement> | React.TouchEvent<SVGPathElement>,
    s: (typeof segments)[number]
  ) => {
    const rect = wrapRef.current?.getBoundingClientRect()
    if (!rect) return

    let clientX = 0
    let clientY = 0
    if ("touches" in e && e.touches.length) {
      clientX = e.touches[0].clientX
      clientY = e.touches[0].clientY
    } else {
      const me = (e as React.MouseEvent).nativeEvent as MouseEvent
      clientX = me.clientX
      clientY = me.clientY
    }

    const rawX = clientX - rect.left
    const rawY = clientY - rect.top
    const w = (wrapRef.current as HTMLDivElement).offsetWidth
    const h = (wrapRef.current as HTMLDivElement).offsetHeight
    const boxW = 160
    const boxH = 48
    const x = Math.min(Math.max(rawX + 12, 8), w - boxW - 8)
    const y = Math.min(Math.max(rawY - boxH - 8, 8), h - boxH - 8)

    setTip({ x, y, key: s.key, pct: s.value * 100 })
  }

  const hideTip = () => setTip(null)

  // SVG pie
  const size = 240
  const r = 90
  const cx = size / 2
  const cy = 120
  const tau = Math.PI * 2

  const arcs = React.useMemo(() => {
    let a0 = -Math.PI / 2
    return segments.map((s) => {
      const a1 = a0 + s.value * tau
      const largeArc = a1 - a0 > Math.PI ? 1 : 0
      const x0 = cx + r * Math.cos(a0)
      const y0 = cy + r * Math.sin(a0)
      const x1 = cx + r * Math.cos(a1)
      const y1 = cy + r * Math.sin(a1)
      const d = `M ${cx} ${cy} L ${x0} ${y0} A ${r} ${r} 0 ${largeArc} 1 ${x1} ${y1} Z`
      a0 = a1
      return { ...s, d }
    })
    // Recompute if values change
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [totals.card, totals.ach])

  // Center label (hover takes precedence)
  const centerKey = tip?.key ?? largest.key
  const centerPct = (tip?.pct ?? largest.value * 100).toFixed(1)

  return (
    <div
      ref={wrapRef}
      className="bg-white rounded-lg p-4 flex flex-col items-center relative"
      onMouseLeave={hideTip}
    >
      <svg
        viewBox={`0 0 ${size} ${size}`}
        style={{ width: "100%", maxWidth: 360, height: 260 }}
      >
        {arcs.map((a) => (
          <path
            key={a.key}
            d={a.d}
            fill={a.color}
            stroke="#ffffff"
            strokeWidth={1}
            style={{ cursor: onSliceClick ? "pointer" : "default", opacity: tip && tip.key !== a.key ? 0.85 : 1 }}
            onClick={() => onSliceClick?.(a.method)}
            onMouseMove={(e) => showTip(e, a)}
            onTouchStart={(e) => showTip(e, a)}
            onTouchMove={(e) => showTip(e, a)}
            onTouchEnd={hideTip}
          >
            <title>{`${a.key} (${Math.round(a.value * 100)}%)`}</title>
          </path>
        ))}

        {/* center badge */}
        <circle cx={cx} cy={cy} r={52} fill="white" />
        <text
          x={cx}
          y={cy - 6}
          textAnchor="middle"
          fontSize="22"
          fontWeight={600}
          fill="#111827"
        >
          {centerPct}%
        </text>
        <text x={cx} y={cy + 16} textAnchor="middle" fontSize="11" fill="#64748b">
          {centerKey}
        </text>
      </svg>

      {/* hover tooltip */}
      {tip && (
        <div
          role="tooltip"
          className="absolute pointer-events-none rounded-md border border-slate-200 bg-white shadow-sm px-3 py-2 text-xs text-slate-800"
          style={{ left: tip.x, top: tip.y, width: 160 }}
        >
          {tip.key} ({tip.pct.toFixed(1)}%)
        </div>
      )}

      <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
        <Legend color="#2563eb" label={`Card (${Math.round(segments[0].value * 100)}%)`} />
        <Legend color="#10b981" label={`ACH (${Math.round(segments[1].value * 100)}%)`} />
      </div>

      {onSliceClick && (
        <button
          className="mt-2 text-xs text-blue-600 hover:underline"
          onClick={() => onSliceClick?.(null)}
        >
          Clear method filter
        </button>
      )}

      <p className="mt-2 text-xs text-slate-500">
        Processing fees: Card includes fees • ACH no fee
      </p>
    </div>
  )
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <span
        className="inline-block w-3 h-3 rounded-sm"
        style={{ background: color }}
      />
      <span className="text-slate-700">{label}</span>
    </div>
  )
}
