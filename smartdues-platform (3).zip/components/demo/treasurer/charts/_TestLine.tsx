"use client"

import * as React from "react"
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip } from "recharts"

export default function TestLine() {
  const data = [
    { x: "A", y: 10 },
    { x: "B", y: 20 },
    { x: "C", y: 12 },
    { x: "D", y: 28 },
  ]
  return (
    <div className="w-full">
      <ResponsiveContainer width="100%" height={160}>
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 8, left: 0 }}>
          <XAxis dataKey="x" />
          <YAxis />
          <Tooltip />
          <Line type="monotone" dataKey="y" stroke="#2563eb" dot />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
