"use client"

import * as React from "react"

type Week = { label: string; amount: number }

export default function CashFlowForecast({ weeks: external }: { weeks?: Week[] }) {
  const weeks: Week[] =
    external ??
    Array.from({ length: 12 }, (_, i) => ({
      label: `W${i + 1}`,
      amount: Math.round(2000 + Math.sin(i / 2) * 800 + (i > 6 ? 900 : 0)),
    }))

  const width = 700
  const height = 300
  const pad = { top: 10, right: 16, bottom: 36, left: 48 }
  const max = Math.max(...weeks.map((w) => w.amount), 1)
  const chartW = width - pad.left - pad.right
  const chartH = height - pad.top - pad.bottom
  const bw = chartW / weeks.length - 6

  const sx = (i: number) => pad.left + i * (chartW / weeks.length) + 3
  const sy = (v: number) => pad.top + chartH - (v / max) * chartH

  // Hover tooltip state
  const wrapRef = React.useRef<HTMLDivElement | null>(null)
  const [hoverIdx, setHoverIdx] = React.useState<number | null>(null)
  const [tip, setTip] = React.useState<{
    x: number
    y: number
    label: string
    amount: number
  } | null>(null)

  const showTip = (
    e:
      | React.MouseEvent<SVGRectElement, MouseEvent>
      | React.TouchEvent<SVGRectElement>,
    i: number
  ) => {
    const rect = wrapRef.current?.getBoundingClientRect()
    if (!rect) return

    let clientX = 0
    let clientY = 0
    if ("touches" in e && e.touches.length) {
      clientX = e.touches[0].clientX
      clientY = e.touches[0].clientY
    } else {
      const me = (e as React.MouseEvent).nativeEvent as MouseEvent
      clientX = me.clientX
      clientY = me.clientY
    }

    const rawX = clientX - rect.left
    const rawY = clientY - rect.top
    const w = (wrapRef.current as HTMLDivElement).offsetWidth
    const h = (wrapRef.current as HTMLDivElement).offsetHeight
    const boxW = 160
    const boxH = 48
    const x = Math.min(Math.max(rawX + 12, 8), w - boxW - 8)
    const y = Math.min(Math.max(rawY - boxH - 8, 8), h - boxH - 8)

    setHoverIdx(i)
    setTip({ x, y, label: weeks[i].label, amount: weeks[i].amount })
  }

  const hideTip = () => {
    setHoverIdx(null)
    setTip(null)
  }

  return (
    <div
      ref={wrapRef}
      className="bg-white rounded-lg p-4 relative"
      style={{ width: "100%" }}
      onMouseLeave={hideTip}
    >
      <svg viewBox={`0 0 ${width} ${height}`} style={{ width: "100%", height }}>
        {/* horizontal grid + labels */}
        {[0, 0.25, 0.5, 0.75, 1].map((g) => (
          <g key={g}>
            <line
              x1={pad.left}
              x2={width - pad.right}
              y1={pad.top + chartH * (1 - g)}
              y2={pad.top + chartH * (1 - g)}
              stroke="#e5e7eb"
            />
            <text
              x={pad.left - 8}
              y={pad.top + chartH * (1 - g)}
              alignmentBaseline="middle"
              textAnchor="end"
              fontSize="11"
              fill="#64748b"
            >
              ${Math.round((max * g) / 1000)}k
            </text>
          </g>
        ))}

        {/* guide line on hover */}
        {hoverIdx !== null && (
          <line
            x1={sx(hoverIdx) + bw / 2}
            x2={sx(hoverIdx) + bw / 2}
            y1={pad.top}
            y2={pad.top + chartH}
            stroke="#94a3b8"
            strokeDasharray="3 3"
          />
        )}

        {/* bars (blue) */}
        {weeks.map((w, i) => (
          <rect
            key={w.label}
            x={sx(i)}
            y={sy(w.amount)}
            width={bw}
            height={pad.top + chartH - sy(w.amount)}
            fill="#2563eb"
            rx={3}
            opacity={hoverIdx === null || hoverIdx === i ? 1 : 0.85}
            onMouseMove={(e) => showTip(e, i)}
            onTouchStart={(e) => showTip(e, i)}
            onTouchMove={(e) => showTip(e, i)}
            onTouchEnd={hideTip}
          >
            <title>
              {w.label}: ${w.amount.toLocaleString()}
            </title>
          </rect>
        ))}

        {/* x-axis labels */}
        {weeks.map((w, i) => (
          <text
            key={w.label}
            x={sx(i) + bw / 2}
            y={height - 12}
            textAnchor="middle"
            fontSize="11"
            fill="#64748b"
          >
            {w.label}
          </text>
        ))}
      </svg>

      {/* hover tooltip */}
      {tip && (
        <div
          role="tooltip"
          className="absolute pointer-events-none rounded-md border border-slate-200 bg-white shadow-sm px-3 py-2 text-xs text-slate-800"
          style={{ left: tip.x, top: tip.y, width: 160 }}
        >
          <div className="font-medium">{tip.label}</div>
          <div>${tip.amount.toLocaleString()}</div>
        </div>
      )}

      <p className="mt-2 text-xs text-slate-500">
        Based on scheduled installments (sample if no live data).
      </p>
    </div>
  )
}
