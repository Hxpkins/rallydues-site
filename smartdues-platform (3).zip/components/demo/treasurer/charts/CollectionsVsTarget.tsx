"use client"

import * as React from "react"

export type CollectionsPoint = { x: number; target: number; actual: number }

export default function CollectionsVsTarget({
  data: external,
  goal = 50000,
}: {
  data?: CollectionsPoint[]
  goal?: number
}) {
  // ---------- data ----------
  const sample = React.useMemo(() => {
    const days = 60
    return Array.from({ length: days }, (_, i) => {
      const t = Math.round((i / (days - 1)) * goal)
      const a = Math.round(t * (i < 24 ? 0.8 : i < 45 ? 0.93 : 1.03))
      return { x: i, target: t, actual: a }
    })
  }, [goal])

  const data = external && external.length ? external : sample

  // ---------- layout / scales ----------
  const width = 700
  const height = 320
  const pad = { top: 16, right: 24, bottom: 28, left: 48 }
  const innerW = width - pad.left - pad.right
  const innerH = height - pad.top - pad.bottom

  const maxY = Math.max(goal * 1.04, ...data.map((d) => Math.max(d.target, d.actual)))

  const sx = (i: number) => pad.left + (i / (data.length - 1)) * innerW
  const sy = (v: number) => height - pad.bottom - (v / maxY) * innerH

  // ---------- paths ----------
  const line = (key: "target" | "actual") =>
    data.map((d, idx) => `${idx === 0 ? "M" : "L"} ${sx(d.x)} ${sy(d[key])}`).join(" ")

  const areaActual = () => {
    const top = data.map((d, idx) => `${idx === 0 ? "M" : "L"} ${sx(d.x)} ${sy(d.actual)}`)
    const bottom = [`L ${sx(data.length - 1)} ${sy(0)}`, `L ${sx(0)} ${sy(0)}`, "Z"]
    return [...top, ...bottom].join(" ")
  }

  const grid = [0, goal * 0.2, goal * 0.4, goal * 0.6, goal * 0.8, goal]

  // ---------- interactivity ----------
  const [hoverIdx, setHoverIdx] = React.useState<number | null>(null)

  function indexFromMouse(clientX: number, svgEl: SVGSVGElement | null): number | null {
    if (!svgEl) return null
    const rect = svgEl.getBoundingClientRect()
    const mx = clientX - rect.left
    const rel = (mx - pad.left) / innerW
    if (rel < 0 || rel > 1) return null
    const idx = Math.round(rel * (data.length - 1))
    return Math.min(data.length - 1, Math.max(0, idx))
  }

  const svgRef = React.useRef<SVGSVGElement | null>(null)
  const onMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    setHoverIdx(indexFromMouse(e.clientX, svgRef.current))
  }
  const onMouseLeave = () => setHoverIdx(null)
  const onTouchMove = (e: React.TouchEvent<SVGSVGElement>) => {
    const t = e.touches[0]
    if (t) setHoverIdx(indexFromMouse(t.clientX, svgRef.current))
  }

  // ---------- tooltip helpers ----------
  const formatMoneyShort = (n: number) => {
    if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1)}m`
    if (n >= 1_000) return `$${(n / 1_000).toFixed(1)}k`
    return `$${n.toLocaleString()}`
  }

  const tipWidth = 180
  const tipHeight = 64

  const current = hoverIdx !== null ? data[hoverIdx] : null
  const anchorX = current ? sx(current.x) : 0
  const anchorY = current ? Math.min(sy(current.actual), sy(current.target)) : 0

  // horizontal flip if near right edge
  const tipX = current
    ? (() => {
        const rightSpace = width - pad.right - anchorX
        return rightSpace > tipWidth + 10 ? anchorX + 10 : anchorX - 10 - tipWidth
      })()
    : 0

  // vertical flip if not enough room above
  const tipY = current
    ? (() => {
        const above = anchorY - (tipHeight + 8)
        const below = anchorY + 8
        if (above > pad.top) return above
        // clamp below so it doesn't run off the bottom
        return Math.min(below, height - pad.bottom - tipHeight)
      })()
    : 0

  return (
    <div className="bg-white rounded-lg p-4" style={{ width: "100%" }}>
      <svg
        ref={svgRef}
        viewBox={`0 0 ${width} ${height}`}
        style={{ width: "100%", height }}
        onMouseMove={onMouseMove}
        onMouseLeave={onMouseLeave}
        onTouchStart={onTouchMove}
        onTouchMove={onTouchMove}
        role="img"
        aria-label="Collections compared to target over time"
      >
        {/* grid + axis labels */}
        {grid.map((y) => (
          <g key={y}>
            <line x1={pad.left} x2={width - pad.right} y1={sy(y)} y2={sy(y)} stroke="#e5e7eb" />
            <text
              x={pad.left - 8}
              y={sy(y)}
              textAnchor="end"
              alignmentBaseline="middle"
              fontSize="11"
              fill="#64748b"
            >
              ${Math.round(y / 1000)}k
            </text>
          </g>
        ))}

        {/* shaded area + lines */}
        <path d={areaActual()} fill="rgba(16,24,40,0.08)" />
        <path d={line("actual")} fill="none" stroke="#111827" strokeWidth={2} />
        <path d={line("target")} fill="none" stroke="#64748b" strokeWidth={2} strokeDasharray="6 6" />

        {/* goal line */}
        <line
          x1={pad.left}
          x2={width - pad.right}
          y1={sy(goal)}
          y2={sy(goal)}
          stroke="#94a3b8"
          strokeDasharray="3 3"
        />
        <text x={width - pad.right} y={sy(goal) - 6} textAnchor="end" fontSize="11" fill="#64748b">
          Goal ${goal.toLocaleString()}
        </text>

        {/* hover crosshair + dot + tooltip */}
        {current && (
          <>
            <line
              x1={anchorX}
              x2={anchorX}
              y1={pad.top}
              y2={height - pad.bottom}
              stroke="#cbd5e1"
              strokeDasharray="4 4"
            />
            <circle cx={anchorX} cy={sy(current.actual)} r={4} fill="#111827" />

            {/* tooltip */}
            <g>
              <rect
                x={tipX}
                y={tipY}
                width={tipWidth}
                height={tipHeight}
                rx={6}
                fill="#ffffff"
                stroke="#e5e7eb"
              />
              <text x={tipX + 10} y={tipY + 18} fontSize="12" fontWeight={600} fill="#111827">
                Day D{current.x + 1}
              </text>
              <text x={tipX + 10} y={tipY + 36} fontSize="12" fill="#111827">
                Actual {formatMoneyShort(current.actual)}
              </text>
              <text x={tipX + 10} y={tipY + 52} fontSize="12" fill="#64748b">
                Target {formatMoneyShort(current.target)}
              </text>
            </g>
          </>
        )}

        {/* wide invisible hit area */}
        <rect
          x={pad.left}
          y={pad.top}
          width={innerW}
          height={innerH}
          fill="transparent"
          pointerEvents="all"
        />
      </svg>

      <p className="mt-2 text-xs text-slate-500">
        Move your cursor (or touch) across the chart to see daily values. Falls back to sample data
        if no live data provided.
      </p>
    </div>
  )
}
