'use client'

import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip
} from 'recharts'

const data = [
  { w: 'W1', v: 1200 },
  { w: 'W2', v: 1500 },
  { w: 'W3', v: 2100 },
  { w: 'W4', v: 1800 },
  { w: 'W5', v: 2400 },
]

export default function TestRechartsFixed() {
  // No ResponsiveContainer: hard-coded width/height force drawing
  return (
    <div className="w-full">
      <LineChart width={720} height={280} data={data}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="w" />
        <YAxis />
        <Tooltip />
        <Line type="monotone" dataKey="v" stroke="#111827" strokeWidth={2} dot={false} />
      </LineChart>
    </div>
  )
}
