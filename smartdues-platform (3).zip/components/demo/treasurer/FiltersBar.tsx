"use client"

import * as React from "react"
import { useRouter } from "next/navigation"
import { ChevronDown, Search, Download, Printer } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useDemoStore } from "@/lib/demo/mockStore"
import { exportOverdueCSV, exportUpcomingCSV, exportPaymentsCSV } from "@/lib/demo/csv"

interface FiltersBarProps {
  selectedCycle: string
  onCycleChange: (cycle: string) => void
  searchQuery: string
  onSearchChange: (query: string) => void
}

const cycles = [
  { id: "fall-2025", name: "Fall 2025" },
  { id: "spring-2025", name: "Spring 2025" },
  { id: "fall-2024", name: "Fall 2024" },
]

function slugify(s: string) {
  return s.toLowerCase().trim().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "")
}

export function FiltersBar({
  selectedCycle,
  onCycleChange,
  searchQuery,
  onSearchChange,
}: FiltersBarProps) {
  const router = useRouter()

  // data sources (may be empty in demo)
  const topOverdue = useDemoStore((s) => s.topOverdue) ?? []
  const upcoming7d = useDemoStore((s) => s.upcoming7d) ?? []
  const recentPayments = useDemoStore((s) => s.recentPayments) ?? []

  // build a simple demo roster for suggestions
  const roster = React.useMemo(() => {
    const names = new Set<string>()
    topOverdue.forEach((r: any) => r?.member && names.add(r.member))
    upcoming7d.forEach((r: any) => r?.member && names.add(r.member))
    recentPayments.forEach((r: any) => r?.member && names.add(r.member))

    // fallback demo names if empty
    if (names.size === 0) {
      [
        "Rowan Ross",
        "Hayden Cruz",
        "Avery Kim",
        "Quinn Patel",
        "Jordan Ross",
        "Casey Green",
        "Rowan Nguyen",
        "Parker Kelly",
      ].forEach((n) => names.add(n))
    }
    return Array.from(names)
  }, [topOverdue, upcoming7d, recentPayments])

  const [openSuggest, setOpenSuggest] = React.useState(false)
  const filtered = React.useMemo(() => {
    const q = searchQuery.trim().toLowerCase()
    if (!q) return []
    return roster
      .filter((n) => n.toLowerCase().includes(q))
      .slice(0, 6)
  }, [roster, searchQuery])

  const navigateToMember = (name: string) => {
    const slug = slugify(name)
    // IMPORTANT: programmatic push; no form submit; no query string
    router.push(`/demo/member/${slug}`)
    setOpenSuggest(false)
  }

  const handleKeyDown: React.KeyboardEventHandler<HTMLInputElement> = (e) => {
    if (e.key === "Enter") {
      e.preventDefault()
      if (filtered.length > 0) {
        navigateToMember(filtered[0])
      }
    }
  }

  // exports
  const handleExportOverdue = () => {
    exportOverdueCSV(topOverdue, { term: cycles.find((c) => c.id === selectedCycle)?.name ?? "" })
  }
  const handleExportUpcoming = () => {
    exportUpcomingCSV(upcoming7d, { term: cycles.find((c) => c.id === selectedCycle)?.name ?? "" })
  }
  const handleExportPayments = () => {
    exportPaymentsCSV(recentPayments, { term: cycles.find((c) => c.id === selectedCycle)?.name ?? "" })
  }

  const handlePrint = () => window.print()

  return (
    <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center relative">
      {/* Cycle Dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="justify-between min-w-[140px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 bg-white"
          >
            {cycles.find((c) => c.id === selectedCycle)?.name || "Select Cycle"}
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="bg-white border border-slate-200 shadow-md">
          {cycles.map((cycle) => (
            <DropdownMenuItem
              key={cycle.id}
              onClick={() => onCycleChange(cycle.id)}
              className="cursor-pointer"
            >
              {cycle.name}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Member Search (client-only, no <form>) */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
        <Input
          placeholder="Search members..."
          value={searchQuery}
          onChange={(e) => {
            onSearchChange(e.target.value)
            setOpenSuggest(true)
          }}
          onFocus={() => searchQuery && setOpenSuggest(true)}
          onBlur={() => setTimeout(() => setOpenSuggest(false), 120)} // allow click
          onKeyDown={handleKeyDown}
          className="pl-10 min-w-[220px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600"
        />

        {openSuggest && filtered.length > 0 && (
          <div className="absolute z-50 mt-2 w-full rounded-md border border-slate-200 bg-white shadow-md">
            {filtered.map((name) => (
              <button
                key={name}
                type="button"
                className="block w-full text-left px-3 py-2 hover:bg-slate-50"
                onMouseDown={(e) => e.preventDefault()}
                onClick={() => navigateToMember(name)}
              >
                {name}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Export CSV Menu */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 bg-white"
          >
            <Download className="mr-2 h-4 w-4" />
            Export CSV
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="bg-white border border-slate-200 shadow-md">
          <DropdownMenuItem onClick={handleExportOverdue} className="cursor-pointer">
            Overdue Members
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleExportUpcoming} className="cursor-pointer">
            Upcoming Installments
          </DropdownMenuItem>
          <DropdownMenuItem onClick={handleExportPayments} className="cursor-pointer">
            Recent Payments
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Print Button */}
      <Button
        variant="outline"
        onClick={handlePrint}
        className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 bg-white"
      >
        <Printer className="mr-2 h-4 w-4" />
        Print
      </Button>
    </div>
  )
}
