"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { useDemoStore } from "@/lib/demo/mockStore"
import { Mail, DollarSign, MoreHorizontal, Download, CheckCircle } from "lucide-react"
import { toast } from "sonner"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface TopOverdueTableProps {
  searchQuery: string
  agingFilter?: string | null
}

export function TopOverdueTable({ searchQuery, agingFilter }: TopOverdueTableProps) {
  const [selectedMembers, setSelectedMembers] = useState<Set<string>>(new Set())
  const [reminded, setReminded] = useState<Set<string>>(new Set()) // UI-only “Sent!” state

  const storeOverdue = useDemoStore((s) => s.topOverdue)

  const baseOverdue = storeOverdue && storeOverdue.length ? storeOverdue : []
  const minRows = 8
  const overdueData =
    baseOverdue.length >= minRows
      ? baseOverdue
      : [
          ...baseOverdue,
          ...Array.from({ length: minRows - baseOverdue.length }, (_, i) => ({
            id: `fallback_${i}`,
            member: `Member ${i + baseOverdue.length + 1}`,
            amount: 150 + Math.floor(Math.random() * 600),
            daysLate: 1 + Math.floor(Math.random() * 40),
            onPlan: Math.random() < 0.35,
            email: "member@example.com",
          })),
        ]

  // Apply aging filter if provided
  const agingFilteredData = agingFilter
    ? overdueData.filter((item) => {
        if (agingFilter === "30+ days") return item.daysLate > 30
        if (agingFilter === "0–7 days") return item.daysLate >= 0 && item.daysLate <= 7
        if (agingFilter === "8–14 days") return item.daysLate >= 8 && item.daysLate <= 14
        if (agingFilter === "15–30 days") return item.daysLate >= 15 && item.daysLate <= 30
        return true
      })
    : overdueData

  // Filter by search query
  const filteredData = agingFilteredData.filter((item) => {
    if (!searchQuery) return true
    return item.member.toLowerCase().includes(searchQuery.toLowerCase())
  })

  const displayData = filteredData.slice(0, 8)

  const handleSelectAll = (checked: boolean) => {
    if (checked) setSelectedMembers(new Set(displayData.map((item) => item.id)))
    else setSelectedMembers(new Set())
  }

  const handleSelectMember = (memberId: string, checked: boolean) => {
    const next = new Set(selectedMembers)
    checked ? next.add(memberId) : next.delete(memberId)
    setSelectedMembers(next)
  }

  const handleSendReminder = (id: string, memberName: string) => {
    const next = new Set(reminded)
    next.add(id)
    setReminded(next)
    toast.success(`Reminder sent to ${memberName}`, {
      description: "Payment reminder email has been queued for delivery",
    })
  }

  const handleRecordPayment = (memberName: string) => {
    toast.success(`Payment recorded for ${memberName}`, {
      description: "Offline payment has been added to their account",
    })
  }

  const handleStartPlan = (memberName: string) => {
    toast.success(`Payment plan started for ${memberName}`, {
      description: "3-installment plan has been created",
    })
  }

  const handleWaiveLateFee = (memberName: string) => {
    toast.success(`Late fee waived for ${memberName}`, {
      description: "Late fee has been removed from their account",
    })
  }

  const handleBulkReminder = () => {
    const count = selectedMembers.size
    if (count > 0) {
      const next = new Set(reminded)
      selectedMembers.forEach((id) => next.add(id))
      setReminded(next)
    }
    toast.success(`Bulk reminder sent to ${count} members`, {
      description: "Payment reminder emails have been queued for delivery",
    })
    setSelectedMembers(new Set())
  }

  // ---------- Inline CSV export (robust for Excel) ----------
  const esc = (val: string | number | boolean) => `"${String(val).replace(/"/g, '""')}"`
  const toCSV = (rows: Array<Record<string, string | number | boolean>>) => {
    const headers = Object.keys(rows[0] ?? { Name: "", Email: "", Amount: "", DaysLate: "", OnPlan: "", Reminded: "" })
    const lines = [
      "sep=,", // Excel hint for delimiter
      headers.map(esc).join(","),
      ...rows.map((r) => headers.map((h) => esc(r[h] ?? "")).join(",")),
    ]
    return lines.join("\n")
  }

  const handleExportCSV = () => {
    const rows = filteredData.map((item) => ({
      Name: item.member,
      Email: item.email ?? "",
      Amount: Number(item.amount).toFixed(2),
      DaysLate: item.daysLate ?? "",
      OnPlan: item.onPlan ? "Yes" : "No",
      Reminded: reminded.has(item.id) ? "Yes" : "No",
    }))

    // Keep columns visible even if there are 0 rows
    const safeRows = rows.length ? rows : [{ Name: "", Email: "", Amount: "", DaysLate: "", OnPlan: "", Reminded: "" }]

    const csv = "\uFEFF" + toCSV(safeRows) // BOM for UTF-8 Excel
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)

    const ts = new Date().toISOString().slice(0, 10).replace(/-/g, "")
    const filename = `smartdues-top-overdue-${ts}.csv`

    const a = document.createElement("a")
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success("CSV exported successfully", {
      description: `${rows.length} overdue members exported`,
    })
  }
  // ---------------------------------------------------------

  const showPreview = filteredData.length === 0 && (searchQuery || agingFilter)
  const previewData = showPreview ? overdueData.slice(0, 3) : []

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-slate-900 mb-2">Top Overdue</h3>
          <p className="text-sm text-slate-600">Members with outstanding balances</p>
        </div>
        <div className="flex gap-2">
          {selectedMembers.size > 0 && (
            <Button
              size="sm"
              onClick={handleBulkReminder}
              className="bg-emerald-600 hover:bg-emerald-700 text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-emerald-600"
            >
              <Mail className="w-4 h-4 mr-2" />
              Send Bulk Reminder ({selectedMembers.size})
            </Button>
          )}
          <Button
            size="sm"
            variant="outline"
            onClick={handleExportCSV}
            className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 bg-transparent"
          >
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200">
              <th className="text-left p-3">
                <Checkbox
                  checked={selectedMembers.size === displayData.length && displayData.length > 0}
                  onCheckedChange={handleSelectAll}
                  aria-label="Select all members"
                />
              </th>
              <th className="text-left p-3 font-medium text-slate-900">Member</th>
              <th className="text-left p-3 font-medium text-slate-900">Amount</th>
              <th className="text-left p-3 font-medium text-slate-900">Days Late</th>
              <th className="text-left p-3 font-medium text-slate-900">Plan?</th>
              <th className="text-left p-3 font-medium text-slate-900">Actions</th>
            </tr>
          </thead>
          <tbody>
            {(displayData.length > 0 ? displayData : previewData).map((item) => {
              const isSent = reminded.has(item.id)
              return (
                <tr
                  key={item.id}
                  className={`border-b border-slate-200 hover:bg-slate-50 ${showPreview ? "opacity-50" : ""}`}
                >
                  <td className="p-3">
                    <Checkbox
                      checked={selectedMembers.has(item.id)}
                      onCheckedChange={(checked) => handleSelectMember(item.id, checked as boolean)}
                      aria-label={`Select ${item.member}`}
                      disabled={showPreview}
                    />
                  </td>
                  <td className="p-3">
                    <div>
                      <div className="font-medium text-slate-900">{item.member}</div>
                      <div className="text-xs text-slate-600">{item.email}</div>
                    </div>
                  </td>
                  <td className="p-3">
                    <span className="font-medium text-red-600">${item.amount.toFixed(2)}</span>
                  </td>
                  <td className="p-3">
                    <Badge variant="destructive" className="text-xs">
                      {item.daysLate} days
                    </Badge>
                  </td>
                  <td className="p-3">
                    {item.onPlan ? (
                      <Badge variant="secondary" className="text-xs">
                        Yes
                      </Badge>
                    ) : (
                      <span className="text-slate-600">No</span>
                    )}
                  </td>
                  <td className="p-3">
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleSendReminder(item.id, item.member)}
                        className={`text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 ${
                          isSent ? "bg-green-600 text-white hover:bg-green-600 cursor-default" : ""
                        }`}
                        disabled={showPreview || isSent}
                      >
                        {isSent ? (
                          <>
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Sent!
                          </>
                        ) : (
                          <>
                            <Mail className="w-3 h-3 mr-1" />
                            Remind
                          </>
                        )}
                      </Button>

                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 bg-transparent"
                            disabled={showPreview}
                          >
                            <MoreHorizontal className="w-3 h-3" />
                          </Button>
                        </DropdownMenuTrigger>

                        <DropdownMenuContent
                          align="end"
                          sideOffset={6}
                          className="z-50 bg-white border border-slate-200 shadow-lg rounded-md p-1"
                        >
                          <DropdownMenuItem
                            className="cursor-pointer focus:bg-slate-50"
                            onClick={() => handleRecordPayment(item.member)}
                          >
                            <DollarSign className="w-4 h-4 mr-2" />
                            Record Offline Payment
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleStartPlan(item.member)}
                            className="cursor-pointer focus:bg-slate-50"
                          >
                            Start Payment Plan
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            onClick={() => handleWaiveLateFee(item.member)}
                            className="cursor-pointer focus:bg-slate-50"
                          >
                            Waive Late Fee
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {showPreview && (
        <div className="mt-4 p-3 bg-slate-50 rounded-lg">
          <p className="text-sm text-slate-600 text-center">
            No results found. Showing preview of available data.{" "}
            <button onClick={() => window.location.reload()} className="text-blue-600 hover:underline">
              Clear filters
            </button>
          </p>
        </div>
      )}

      {displayData.length === 0 && !showPreview && (
        <div className="text-center py-8 text-slate-600">No overdue members found</div>
      )}
    </div>
  )
}
