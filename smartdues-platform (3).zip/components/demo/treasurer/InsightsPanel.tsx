"use client"

import { useState } from "react"
import { useDemoStore } from "@/lib/demo/mockStore"
import { TrendingUp, AlertTriangle, DollarSign, Users, Target, CheckCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { toast } from "sonner"

export function InsightsPanel() {
  const {
    payments,
    overdueRows,
    upcomingRows,
    reminders,
    members: totalMembers = 120,
    duesAmount = 150,
    targetAmount = 18000,
  } = useDemoStore()

  // KPIs
  const totalCollected = payments?.reduce((sum, p) => sum + p.amount, 0) || 0
  const totalOutstanding = overdueRows?.reduce((sum, row) => sum + row.amount, 0) || 0
  const collectionRate = targetAmount > 0 ? (totalCollected / targetAmount) * 100 : 0

  // Aging buckets
  const now = new Date()
  const agingBuckets = { "0-7": 0, "8-14": 0, "15-30": 0, "30+": 0 as number }
  overdueRows?.forEach((row) => {
    const d = row.daysPastDue || 0
    const amt = row.amount || 0
    if (d <= 7) agingBuckets["0-7"] += amt
    else if (d <= 14) agingBuckets["8-14"] += amt
    else if (d <= 30) agingBuckets["15-30"] += amt
    else agingBuckets["30+"] += amt
  })

  // Method breakdown (last 30d)
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
  const recentPayments = payments?.filter((p) => new Date(p.date) >= thirtyDaysAgo) || []
  const methodBreakdown = {
    card: recentPayments.filter((p) => p.method === "card").reduce((s, p) => s + p.amount, 0),
    ach: recentPayments.filter((p) => p.method === "ach").reduce((s, p) => s + p.amount, 0),
  }
  const totalMethodAmount = methodBreakdown.card + methodBreakdown.ach

  // Build insights
  type Insight = {
    type: "warning" | "success" | "info" | "default"
    icon: any
    title: string
    message: string
    action: string
    actionType: "reminder" | "view" | "promote" | "campaign" | "escalate"
    key: string // stable UI key for “done” state
  }

  const insights: Insight[] = []
  const targetRate = 85
  const behindAmount = Math.max(0, targetAmount - totalCollected)
  if (collectionRate < targetRate && behindAmount > 0) {
    const agingTotal = agingBuckets["8-14"] + agingBuckets["15-30"]
    const memberCount = Math.floor(agingTotal / duesAmount)
    insights.push({
      type: "warning",
      icon: AlertTriangle,
      title: "Behind Target",
      message: `You're $${behindAmount.toLocaleString()} behind target. ${memberCount} members are 8–14 days late.`,
      action: "Send 2nd Reminder",
      actionType: "reminder",
      key: "Behind Target-reminder",
    })
  }

  const upcomingAmount = upcomingRows?.reduce((s, r) => s + (r.amount || 0), 0) || 0
  const planMembers = upcomingRows?.length || 0
  if (upcomingAmount > 0 && planMembers > 0) {
    const planPercentage = Math.round((planMembers / totalMembers) * 100)
    insights.push({
      type: "info",
      icon: TrendingUp,
      title: "Payment Plan Forecast",
      message: `${planPercentage}% on plans. Expecting $${(upcomingAmount / 1000).toFixed(1)}k in next 4 weeks.`,
      action: "View Forecast",
      actionType: "view",
      key: "Payment Plan Forecast-view",
    })
  }

  const achPercentage = totalMethodAmount > 0 ? (methodBreakdown.ach / totalMethodAmount) * 100 : 0
  if (achPercentage < 40 && methodBreakdown.card > 0) {
    const potentialSavings = methodBreakdown.card * 0.031 * 0.15
    insights.push({
      type: "success",
      icon: DollarSign,
      title: "Fee Optimization",
      message: `ACH adoption is ${achPercentage.toFixed(0)}%. Promoting ACH could save ~$${potentialSavings.toFixed(0)} in fees.`,
      action: "Promote ACH",
      actionType: "promote",
      key: "Fee Optimization-promote",
    })
  }

  const paidMembers = Math.max(0, totalMembers - Math.floor(totalOutstanding / duesAmount))
  if (paidMembers < totalMembers * 0.8) {
    insights.push({
      type: "info",
      icon: Users,
      title: "Member Engagement",
      message: `${paidMembers} of ${totalMembers} members have paid. Consider targeted outreach.`,
      action: "Send Campaign",
      actionType: "campaign",
      key: "Member Engagement-campaign",
    })
  }

  const criticalAging = agingBuckets["30+"]
  if (criticalAging > 1000) {
    insights.push({
      type: "warning",
      icon: Target,
      title: "Critical Aging",
      message: `$${criticalAging.toLocaleString()} outstanding for 30+ days. Immediate action needed.`,
      action: "Escalate",
      actionType: "escalate",
      key: "Critical Aging-escalate",
    })
  }

  // --- Button "done" state handling ---
  const [doneKeys, setDoneKeys] = useState<Set<string>>(new Set())

  const markDone = (k: string) => setDoneKeys((prev) => {
    const next = new Set(prev)
    next.add(k)
    return next
  })

  const doneLabel = (actionType: Insight["actionType"]) => {
    switch (actionType) {
      case "reminder": return "Sent!"
      case "promote":  return "Promoted"
      case "campaign": return "Sent!"
      case "escalate": return "Escalated"
      case "view":     return "Viewed"
      default:         return "Done"
    }
  }

  const handleAction = (actionType: Insight["actionType"], title: string, key: string) => {
    const actions: Record<Insight["actionType"], () => void> = {
      reminder: () =>
        toast.success("Reminder campaign queued", {
          description: "2nd reminder emails will be sent to overdue members",
        }),
      view: () =>
        toast.info("Forecast updated", { description: "Payment plan forecast has been refreshed" }),
      promote: () =>
        toast.success("ACH promotion activated", {
          description: "ACH benefits will be highlighted in next communications",
        }),
      campaign: () =>
        toast.success("Engagement campaign started", {
          description: "Targeted outreach emails have been queued",
        }),
      escalate: () =>
        toast.warning("Escalation initiated", {
          description: "Critical aging cases have been flagged for review",
        }),
    }
    actions[actionType]?.()
    markDone(key)
  }

  const getInsightColor = (type: Insight["type"]) => {
    switch (type) {
      case "warning": return "border-orange-200 bg-orange-50"
      case "success": return "border-emerald-200 bg-emerald-50"
      case "info":    return "border-blue-200 bg-blue-50"
      default:        return "border-gray-200 bg-gray-50"
    }
  }

  const getIconColor = (type: Insight["type"]) => {
    switch (type) {
      case "warning": return "text-orange-600"
      case "success": return "text-emerald-600"
      case "info":    return "text-blue-600"
      default:        return "text-gray-600"
    }
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-2">Insights</h3>
        <p className="text-sm text-slate-600">AI-powered recommendations</p>
      </div>

      <div className="space-y-4">
        {insights.map((insight) => {
          const Icon = insight.icon
          const isDone = doneKeys.has(insight.key)
          return (
            <div key={insight.key} className={`p-4 rounded-lg border ${getInsightColor(insight.type)}`}>
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-white flex items-center justify-center flex-shrink-0">
                  <Icon className={`w-4 h-4 ${getIconColor(insight.type)}`} />
                </div>
                <div className="flex-1">
                  <h4 className="font-medium text-slate-900 mb-1">{insight.title}</h4>
                  <p className="text-sm text-slate-600 mb-3">{insight.message}</p>

                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleAction(insight.actionType, insight.title, insight.key)}
                    className={`text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 ${
                      isDone ? "bg-green-600 text-white hover:bg-green-600 cursor-default" : "bg-transparent"
                    }`}
                    disabled={isDone}
                  >
                    {isDone ? (
                      <>
                        <CheckCircle className="w-3 h-3 mr-1" />
                        {doneLabel(insight.actionType)}
                      </>
                    ) : (
                      insight.action
                    )}
                  </Button>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      {insights.length === 0 && (
        <div className="text-center py-8 text-slate-600">
          <TrendingUp className="w-8 h-8 mx-auto mb-2 text-emerald-600" />
          <p className="text-sm">All metrics look good!</p>
          <p className="text-xs text-slate-500 mt-1">No immediate actions needed</p>
        </div>
      )}

      <div className="mt-6 pt-4 border-t border-slate-200">
        <p className="text-xs text-slate-600">Insights are generated from your current data and updated in real-time</p>
      </div>
    </div>
  )
}
