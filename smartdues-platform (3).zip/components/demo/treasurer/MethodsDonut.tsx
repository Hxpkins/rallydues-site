"use client"

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts"
import { useDemoStore } from "@/lib/demo/mockStore"
import { METHOD_COLORS, FEE_COPY } from "@/lib/demo/constants"

interface MethodsDonutProps {
  onMethodFilter?: (method: string | null) => void
  activeMethodFilter?: string | null
}

export function MethodsDonut({ onMethodFilter, activeMethodFilter }: MethodsDonutProps) {
  const recentPayments = useDemoStore((s) => s.recentPayments)

  const payments =
    recentPayments && recentPayments.length
      ? recentPayments
      : [
          { method: "card", amount: 2500 },
          { method: "ach", amount: 1800 },
          { method: "card", amount: 1200 },
          { method: "ach", amount: 900 },
        ]

  const breakdown = payments.reduce(
    (acc, payment) => {
      acc[payment.method] = (acc[payment.method] || 0) + payment.amount
      return acc
    },
    { card: 0, ach: 0 } as Record<string, number>,
  )

  const total = breakdown.card + breakdown.ach

  const data = [
    { name: "Card", value: breakdown.card, color: METHOD_COLORS.card },
    { name: "ACH", value: breakdown.ach, color: METHOD_COLORS.ach },
  ].filter((item) => item.value > 0)

  const achPercentage = total > 0 ? ((breakdown.ach / total) * 100).toFixed(1) : "0.0"

  const formatCurrency = (value: number) => {
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}k`
    }
    return `$${value.toFixed(0)}`
  }

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0]
      const percentage = total > 0 ? ((data.value / total) * 100).toFixed(1) : "0"
      return (
        <div className="bg-white p-3 border border-slate-200 rounded-lg shadow-sm">
          <p className="text-sm font-medium text-slate-900">{data.name}</p>
          <p className="text-sm text-slate-600">
            {formatCurrency(data.value)} ({percentage}%)
          </p>
        </div>
      )
    }
    return null
  }

  const handleLegendClick = (entry: any) => {
    if (onMethodFilter) {
      const method = entry.value.toLowerCase()
      onMethodFilter(activeMethodFilter === method ? null : method)
    }
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-2">Payment Methods</h3>
        <p className="text-sm text-slate-600">Breakdown by payment method (click legend to filter)</p>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie data={data} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={2} dataKey="value">
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={entry.color}
                className="cursor-pointer hover:opacity-80"
                onClick={() => handleLegendClick({ value: entry.name })}
              />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
        </PieChart>
      </ResponsiveContainer>

      {/* Center content - positioned absolutely over the chart */}
      <div className="relative -mt-[300px] h-[300px] flex items-center justify-center pointer-events-none">
        <div className="text-center">
          <div className="text-2xl font-semibold text-emerald-600">{achPercentage}%</div>
          <div className="text-xs text-slate-600">paid via ACH</div>
          <div className="text-xs text-slate-600">(no fee)</div>
        </div>
      </div>

      {/* Interactive Legend */}
      <div className="flex justify-center gap-6 mt-4">
        {data.map((entry) => (
          <button
            key={entry.name}
            onClick={() => handleLegendClick({ value: entry.name })}
            className={`flex items-center gap-2 px-3 py-2 rounded-lg transition-colors ${
              activeMethodFilter === entry.name.toLowerCase()
                ? "bg-slate-100 ring-2 ring-slate-300"
                : "hover:bg-slate-50"
            }`}
          >
            <div className="w-3 h-3 rounded" style={{ backgroundColor: entry.color }}></div>
            <span className="text-sm text-slate-900">{entry.name}</span>
            <span className="text-sm text-slate-600">
              ({total > 0 ? ((entry.value / total) * 100).toFixed(0) : 0}%)
            </span>
          </button>
        ))}
      </div>

      {/* Footnote */}
      <div className="mt-6 pt-4 border-t border-slate-200">
        <p className="text-xs text-slate-600 text-center">
          <strong>Processing fees:</strong> {FEE_COPY}
        </p>
      </div>
    </div>
  )
}
