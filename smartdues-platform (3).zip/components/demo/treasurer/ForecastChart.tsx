"use client"

import { Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, ReferenceLine } from "recharts"
import { useDemoStore } from "@/lib/demo/mockStore"

export function ForecastChart() {
  const storeForecast = useDemoStore((s) => s.forecast12w)

  const forecast =
    storeForecast && storeForecast.length
      ? storeForecast
      : [
          { weekStart: "2025-01-06", expected: 3200 },
          { weekStart: "2025-01-13", expected: 2800 },
          { weekStart: "2025-01-20", expected: 4100 },
          { weekStart: "2025-01-27", expected: 3600 },
        ]

  const today = new Date()

  const forecastData = forecast.map((week, index) => {
    const weekStart = new Date(week.weekStart)
    const weekEnd = new Date(weekStart)
    weekEnd.setDate(weekEnd.getDate() + 6)

    return {
      ...week,
      week: `Week ${index + 1}`,
      weekIndex: index,
      isToday: weekStart <= today && weekEnd >= today,
    }
  })

  const formatCurrency = (value: number) => {
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}k`
    }
    return `$${value.toFixed(0)}`
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload
      const weekStart = new Date(data.weekStart)
      const weekEnd = new Date(weekStart)
      weekEnd.setDate(weekEnd.getDate() + 6)

      return (
        <div className="bg-white p-3 border border-slate-200 rounded-lg shadow-sm">
          <p className="text-sm font-medium text-slate-900 mb-1">{label}</p>
          <p className="text-xs text-slate-600 mb-2">
            {weekStart.toLocaleDateString("en-US", { month: "short", day: "numeric" })} -{" "}
            {weekEnd.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
          </p>
          <p className="text-sm text-emerald-600">Expected: {formatCurrency(payload[0].value)}</p>
        </div>
      )
    }
    return null
  }

  const todayWeekIndex = forecastData.findIndex((week) => week.isToday)

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-2">Cash Flow Forecast</h3>
        <p className="text-sm text-slate-600">Expected collections from payment plans over next 12 weeks</p>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <AreaChart data={forecastData} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis
            dataKey="week"
            tick={{ fontSize: 12, fill: "#64748b" }}
            axisLine={{ stroke: "#e2e8f0" }}
            interval={0}
            angle={-45}
            textAnchor="end"
            height={60}
          />
          <YAxis
            tickFormatter={formatCurrency}
            tick={{ fontSize: 12, fill: "#64748b" }}
            axisLine={{ stroke: "#e2e8f0" }}
          />
          <Tooltip content={<CustomTooltip />} />

          {todayWeekIndex >= 0 && (
            <ReferenceLine
              x={forecastData[todayWeekIndex].week}
              stroke="#ef4444"
              strokeDasharray="3 3"
              label={{ value: "Today", position: "top", fill: "#ef4444", fontSize: 12 }}
            />
          )}

          <Area type="monotone" dataKey="expected" stroke="#10b981" fill="#10b981" fillOpacity={0.2} strokeWidth={2} />
        </AreaChart>
      </ResponsiveContainer>

      <div className="mt-4 text-xs text-slate-600">
        Forecast based on scheduled payment plan installments. Actual collections may vary.
      </div>
    </div>
  )
}
