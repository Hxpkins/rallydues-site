"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useDemoStore } from "@/lib/demo/mockStore"
import { Calendar, CheckCircle, Download, Mail } from "lucide-react"
import { toast } from "sonner"

interface UpcomingInstallmentsProps {
  searchQuery: string
}

export function UpcomingInstallments({ searchQuery }: UpcomingInstallmentsProps) {
  const storeUpcoming = useDemoStore((s) => s.upcoming7d)

  // UI-only states (keep rows visible)
  const [reminded, setReminded] = useState<Set<string>>(new Set())
  const [paid, setPaid] = useState<Set<string>>(new Set())

  const baseUpcoming = storeUpcoming && storeUpcoming.length ? storeUpcoming : []
  const minRows = 10
  const upcomingData =
    baseUpcoming.length >= minRows
      ? baseUpcoming
      : [
          ...baseUpcoming,
          ...Array.from({ length: minRows - baseUpcoming.length }, (_, i) => {
            const today = new Date()
            const dueDate = new Date(today)
            dueDate.setDate(dueDate.getDate() + 1 + Math.floor(Math.random() * 6))
            return {
              id: `fallback_${i}`,
              member: `Member ${i + baseUpcoming.length + 1}`,
              installmentNo: 1 + Math.floor(Math.random() * 6),
              dueDate: dueDate.toISOString().slice(0, 10),
              amount: 100 + Math.round(Math.random() * 400),
              method: Math.random() < 0.3 ? "ach" : ("card" as const),
            }
          }),
        ]

  // Filter by search query
  const filteredData = upcomingData.filter((item) => {
    if (!searchQuery) return true
    return item.member.toLowerCase().includes(searchQuery.toLowerCase())
  })

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)

    if (date.toDateString() === today.toDateString()) return "Today"
    if (date.toDateString() === tomorrow.toDateString()) return "Tomorrow"
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
  }

  const getDateBadgeVariant = (dateStr: string) => {
    const date = new Date(dateStr)
    const today = new Date()
    const diffDays = Math.ceil((date.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))
    if (diffDays <= 1) return "destructive"
    if (diffDays <= 3) return "secondary"
    return "outline"
  }

  const handleRemind = (id: string, memberName: string) => {
    const next = new Set(reminded)
    next.add(id)
    setReminded(next)
    toast.success(`Reminder sent to ${memberName}`, {
      description: "Payment reminder email has been queued for delivery",
    })
  }

  const handleMarkPaid = (id: string, memberName: string, amount: number) => {
    const next = new Set(paid)
    next.add(id)
    setPaid(next)
    toast.success(`Payment recorded for ${memberName}`, {
      description: `$${amount.toFixed(2)} installment marked as paid`,
    })
  }

  // ---------- Inline CSV export (robust for Excel) ----------
  const esc = (val: string | number | boolean) => `"${String(val).replace(/"/g, '""')}"`
  const toCSV = (rows: Array<Record<string, string | number | boolean>>) => {
    const headers = Object.keys(rows[0] ?? { Name: "", Installment: "", DueDate: "", Amount: "", Method: "", Reminded: "", Paid: "" })
    const lines = [
      // Excel hint for separator (prevents the single-column issue in some locales)
      "sep=,",
      headers.map(esc).join(","),
      ...rows.map((r) => headers.map((h) => esc(r[h] ?? "")).join(",")),
    ]
    return lines.join("\n")
  }

  const handleExportCSV = () => {
    const rows = filteredData.map((item) => ({
      Name: item.member,
      Installment: item.installmentNo,
      DueDate: item.dueDate,                      // ISO yyyy-mm-dd
      Amount: item.amount.toFixed(2),
      Method: item.method.toUpperCase(),
      Reminded: reminded.has(item.id),
      Paid: paid.has(item.id),
    }))

    const safeRows = rows.length ? rows : [{
      Name: "", Installment: "", DueDate: "", Amount: "", Method: "", Reminded: "", Paid: ""
    }]

    const csv = "\uFEFF" + toCSV(safeRows)        // BOM for Excel UTF-8
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)

    const ts = new Date().toISOString().slice(0,10).replace(/-/g,"")
    const filename = `smartdues-upcoming-installments-${ts}.csv`

    const a = document.createElement("a")
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success("CSV exported successfully", {
      description: `${rows.length} upcoming installments exported`,
    })
  }
  // ---------------------------------------------------------

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-slate-900 mb-2">Upcoming Installments</h3>
          <p className="text-sm text-slate-600">Payment plan installments due in next 7 days</p>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={handleExportCSV}
          className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 bg-transparent"
        >
          <Download className="w-4 h-4 mr-2" />
          Export CSV
        </Button>
      </div>

      <div className="space-y-3">
        {filteredData.map((item) => {
          const isReminded = reminded.has(item.id)
          const isPaid = paid.has(item.id)

          return (
            <div
              key={item.id}
              className="flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-blue-50 rounded-full flex items-center justify-center">
                  <Calendar className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <div className="font-medium text-slate-900">{item.member}</div>
                  <div className="text-xs text-slate-600">
                    Installment #{item.installmentNo} • {item.method.toUpperCase()}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="font-medium text-slate-900">${item.amount.toFixed(2)}</div>
                  <Badge variant={getDateBadgeVariant(item.dueDate)} className="text-xs">
                    {formatDate(item.dueDate)}
                  </Badge>
                </div>

                {/* Remind (disable if already reminded OR paid) */}
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleRemind(item.id, item.member)}
                  disabled={isReminded || isPaid}
                  className={`text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 ${
                    isReminded ? "bg-green-600 text-white hover:bg-green-600 cursor-default" : ""
                  }`}
                >
                  {isReminded ? (
                    <>
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Sent!
                    </>
                  ) : (
                    <>
                      <Mail className="w-3 h-3 mr-1" />
                      Remind
                    </>
                  )}
                </Button>

                {/* Mark Paid (UI-only, do not remove row) */}
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleMarkPaid(item.id, item.member, item.amount)}
                  disabled={isPaid}
                  className={`text-xs focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 ${
                    isPaid ? "bg-green-600 text-white hover:bg-green-600 cursor-default" : ""
                  }`}
                >
                  {isPaid ? (
                    <>
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Paid!
                    </>
                  ) : (
                    <>
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Mark Paid
                    </>
                  )}
                </Button>
              </div>
            </div>
          )
        })}
      </div>

      {filteredData.length === 0 && (
        <div className="text-center py-8 text-slate-600">
          {searchQuery ? "No upcoming installments match your search" : "No upcoming installments"}
        </div>
      )}
    </div>
  )
}
