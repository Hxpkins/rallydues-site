"use client"

import * as React from "react"

type Point = { day: string; rate: number }

/**
 * ReminderImpact
 * A lightweight, dependency-free bar chart that adapts to parent width.
 *
 * Props:
 * - points?: { day: string; rate: number }[]  // optional; falls back to sample data
 * - height?: number                            // default 240
 */
export default function ReminderImpact({
  points,
  height = 240,
}: {
  points?: Point[]
  height?: number
}) {
  // Fallback sample data if none provided
  const data: Point[] =
    points && points.length
      ? points
      : [
          { day: "7d", rate: 12 },
          { day: "3d", rate: 18 },
          { day: "1d", rate: 25 },
          { day: "Day-of", rate: 32 },
        ]

  // Responsive width via ResizeObserver
  const wrapRef = React.useRef<HTMLDivElement | null>(null)
  const [width, setWidth] = React.useState(600)

  React.useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    const ro = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect?.width
      if (w && w > 0) setWidth(w)
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  // Layout
  const pad = { t: 16, r: 20, b: 32, l: 44 }
  const innerW = Math.max(0, width - pad.l - pad.r)
  const innerH = Math.max(0, height - pad.t - pad.b)

  const maxY = Math.max(1, ...data.map((d) => d.rate)) * 1.1

  const xStep = innerW / Math.max(1, data.length)
  const barW = Math.min(48, Math.max(18, xStep * 0.6))

  const sx = (i: number) => pad.l + i * xStep + (xStep - barW) / 2
  const sy = (v: number) => height - pad.b - (v / maxY) * innerH

  // Hover state
  const [hoverIdx, setHoverIdx] = React.useState<number | null>(null)
  const onEnter = (i: number) => setHoverIdx(i)
  const onLeave = () => setHoverIdx(null)

  return (
    <div ref={wrapRef} className="w-full" style={{ minHeight: height }}>
      <svg width={width} height={height} role="img" aria-label="Reminder impact chart">
        {/* gridlines + y labels */}
        {[0, 25, 50, 75, 100].map((y, idx) => {
          const yv = (y / 100) * maxY
          return (
            <g key={idx}>
              <line
                x1={pad.l}
                x2={width - pad.r}
                y1={sy(yv)}
                y2={sy(yv)}
                stroke="#e5e7eb"
              />
              <text
                x={pad.l - 8}
                y={sy(yv)}
                textAnchor="end"
                alignmentBaseline="middle"
                fontSize="11"
                fill="#64748b"
              >
                {y}%
              </text>
            </g>
          )
        })}

        {/* bars */}
        {data.map((d, i) => {
          const x = sx(i)
          const y = sy(d.rate)
          const h = height - pad.b - y
          const isHover = hoverIdx === i
          return (
            <g key={d.day}>
              <rect
                x={x}
                y={y}
                width={barW}
                height={h}
                rx={6}
                fill={isHover ? "#1d4ed8" : "#3b82f6"}
                onMouseEnter={() => onEnter(i)}
                onMouseLeave={onLeave}
                onFocus={() => onEnter(i)}
                onBlur={onLeave}
              />
              <text
                x={x + barW / 2}
                y={height - pad.b + 16}
                textAnchor="middle"
                fontSize="12"
                fill="#475569"
              >
                {d.day}
              </text>
            </g>
          )
        })}

        {/* hover marker */}
        {hoverIdx != null && (
          <text
            x={sx(hoverIdx) + barW / 2}
            y={sy(data[hoverIdx].rate) - 8}
            textAnchor="middle"
            fontSize="12"
            fill="#0f172a"
          >
            {data[hoverIdx].rate}%
          </text>
        )}
      </svg>

      <div className="mt-2 text-xs text-slate-500">
        Response rates by reminder timing. Hover a bar to see the exact rate.
      </div>
    </div>
  )
}
