import CollectionsVsTarget from '@/components/demo/treasurer/charts/CollectionsVsTarget'

// Pretend DB fetch (replace with real queries later)
async function getCollectionsData(chapterId: string) {
  // Example shape you’ll return:
  // [{ x: 0, target: 0, actual: 0 }, ...]
  // For now return empty array to trigger chart’s sample fallback
  return [] as { x: number; target: number; actual: number }[]
}

export default async function ServerDataWrapper({
  chapterId,
}: { chapterId: string }) {
  const data = await getCollectionsData(chapterId) // do your real fetch here
  return <CollectionsVsTarget data={data} goal={50000} />
}
