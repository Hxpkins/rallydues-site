"use client"

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import { useDemoStore } from "@/lib/demo/mockStore"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"

interface AgingChartProps {
  onFilterChange?: (filter: string | null) => void
  activeFilter?: string | null
}

export function AgingChart({ onFilterChange, activeFilter }: AgingChartProps) {
  const storeAging = useDemoStore((s) => s.aging)
  const aging =
    storeAging && storeAging.length
      ? storeAging
      : [
          { key: "0_7", label: "0–7 days", amount: 2500, memberCount: 8 },
          { key: "8_14", label: "8–14 days", amount: 4200, memberCount: 12 },
          { key: "15_30", label: "15–30 days", amount: 3800, memberCount: 10 },
          { key: "30_plus", label: "30+ days", amount: 6100, memberCount: 15 },
        ]

  const today = new Date()

  const data = [
    {
      name: "Outstanding",
      ...aging.reduce((acc, bucket) => {
        acc[bucket.label] = { amount: bucket.amount, count: bucket.memberCount }
        return acc
      }, {} as any),
    },
  ]

  const formatCurrency = (value: number) => {
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}k`
    }
    return `$${value.toFixed(0)}`
  }

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      const total = payload.reduce((sum: number, entry: any) => sum + entry.value.amount, 0)
      return (
        <div className="bg-white p-3 border border-slate-200 rounded-lg shadow-sm">
          <p className="text-sm font-medium text-slate-900 mb-2">Outstanding by Age</p>
          {payload
            .filter((entry: any) => entry.value.amount > 0)
            .map((entry: any, index: number) => (
              <div key={index} className="text-sm" style={{ color: entry.color }}>
                <p>
                  {entry.dataKey.replace(".amount", "")}: {formatCurrency(entry.value.amount)}
                </p>
                <p className="text-xs text-slate-600">{entry.value.count} members</p>
              </div>
            ))}
          {total > 0 && (
            <div className="border-t border-gray-200 mt-2 pt-2">
              <p className="text-sm font-medium text-slate-900">Total: {formatCurrency(total)}</p>
            </div>
          )}
        </div>
      )
    }
    return null
  }

  const colors = {
    "0–7 days": "#fbbf24",
    "8–14 days": "#f97316",
    "15–30 days": "#ef4444",
    "30+ days": "#dc2626",
  }

  const handleBarClick = (data: any, index: number) => {
    if (onFilterChange) {
      const labels = Object.keys(colors)
      const bucketLabel = labels[index]
      onFilterChange(activeFilter === bucketLabel ? null : bucketLabel)
    }
  }

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-lg font-semibold text-slate-900">Aging Analysis</h3>
          {activeFilter && (
            <Badge variant="secondary" className="flex items-center gap-1">
              Filter: {activeFilter}
              <button onClick={() => onFilterChange?.(null)} className="ml-1 hover:bg-slate-300 rounded-full p-0.5">
                <X className="w-3 h-3" />
              </button>
            </Badge>
          )}
        </div>
        <p className="text-sm text-slate-600">Outstanding amounts by days overdue (click to filter table)</p>
      </div>

      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
          <XAxis dataKey="name" tick={{ fontSize: 12, fill: "#64748b" }} axisLine={{ stroke: "#e2e8f0" }} />
          <YAxis
            tickFormatter={formatCurrency}
            tick={{ fontSize: 12, fill: "#64748b" }}
            axisLine={{ stroke: "#e2e8f0" }}
          />
          <Tooltip content={<CustomTooltip />} />

          {aging.map((bucket, index) => (
            <Bar
              key={bucket.key}
              dataKey={`${bucket.label}.amount`}
              stackId="a"
              fill={colors[bucket.label as keyof typeof colors]}
              radius={index === aging.length - 1 ? [4, 4, 0, 0] : [0, 0, 0, 0]}
              onClick={handleBarClick}
              className="cursor-pointer"
            />
          ))}
        </BarChart>
      </ResponsiveContainer>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 mt-4">
        {aging.map((bucket, index) => (
          <button
            key={bucket.key}
            onClick={() => handleBarClick(null, index)}
            className="flex items-center gap-2 hover:bg-slate-50 px-2 py-1 rounded transition-colors"
          >
            <div
              className="w-3 h-3 rounded"
              style={{ backgroundColor: colors[bucket.label as keyof typeof colors] }}
            ></div>
            <span className="text-xs text-slate-600">{bucket.label}</span>
            <span className="text-xs text-slate-500">({bucket.memberCount} members)</span>
          </button>
        ))}
      </div>

      <div className="mt-4 text-xs text-slate-600">
        Aging as of {today.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })}
      </div>
    </div>
  )
}
