"use client"

import { getCohortMatrix } from "@/lib/demo/mockData"

type Props = {
  data?: { members?: Array<{ pledgeClass?: string; paidWeeks?: number[] }> }
}

export function CohortHeatmap(props: Props) {
  // Safe: helper has defaults + fallback
  const grid = getCohortMatrix(props?.data)

  const cohorts = Array.from(new Set(grid.map((c) => c.cohort)))
  const maxWeek = Math.max(0, ...grid.map((c) => c.week))
  const weeks = Array.from({ length: maxWeek + 1 }, (_, i) => i)

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6">
      <div className="mb-6">
        <h3 className="text-lg font-semibold text-slate-900 mb-2">Cohort Performance</h3>
        <p className="text-sm text-slate-600">Payment completion rate by pledge class over time</p>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm border-separate" style={{ borderSpacing: 0 }}>
          <thead>
            <tr>
              <th className="text-left p-2 sticky left-0 bg-white z-10">Pledge Class</th>
              {weeks.map((w) => (
                <th key={w} className="p-2 text-center font-medium text-slate-500">
                  Week {w}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {cohorts.map((cohort) => (
              <tr key={cohort}>
                <td className="p-2 font-medium sticky left-0 bg-white z-10">{cohort}</td>
                {weeks.map((w) => {
                  const cell = grid.find((g) => g.cohort === cohort && g.week === w)
                  const pct = cell?.pct ?? 0
                  // Make even tiny percentages visible; 0.15 min alpha
                  const alpha = Math.max(0.15, Math.min(1, pct / 100))
                  return (
                    <td key={w} className="p-1">
                      <div
                        className="h-8 w-16 rounded flex items-center justify-center text-xs font-medium"
                        title={`${pct}%`}
                        style={{
                          background: `rgba(16,185,129,${alpha})`,
                          color: pct > 50 ? "white" : "rgba(0,0,0,0.8)",
                        }}
                      >
                        {pct}%
                      </div>
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Legend */}
      <div className="mt-6 pt-4 border-t border-slate-200">
        <div className="flex items-center justify-between text-xs text-slate-600 mb-2">
          <span>Payment Rate</span>
          <div className="flex items-center gap-1">
            <span>0%</span>
            <div className="flex gap-1">
              <div className="w-4 h-4 rounded" style={{ background: "rgba(16,185,129,0.15)" }}></div>
              <div className="w-4 h-4 rounded" style={{ background: "rgba(16,185,129,0.3)" }}></div>
              <div className="w-4 h-4 rounded" style={{ background: "rgba(16,185,129,0.5)" }}></div>
              <div className="w-4 h-4 rounded" style={{ background: "rgba(16,185,129,0.7)" }}></div>
              <div className="w-4 h-4 rounded" style={{ background: "rgba(16,185,129,1)" }}></div>
            </div>
            <span>100%</span>
          </div>
        </div>
        <p className="text-xs text-slate-600">
          Each cell shows the percentage of members from that pledge class who had paid in full by that week
        </p>
      </div>
    </div>
  )
}
