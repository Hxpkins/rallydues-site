"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { useDemoStore } from "@/lib/demo/mockStore"
import { CreditCard, Banknote, Download, Filter } from "lucide-react"
import { toast } from "sonner"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface RecentPaymentsProps {
  searchQuery: string
  methodFilter?: string | null
}

export function RecentPayments({ searchQuery, methodFilter }: RecentPaymentsProps) {
  const [sortBy, setSortBy] = useState<"date" | "amount">("date")
  const storePayments = useDemoStore((s) => s.recentPayments)

  const basePayments = storePayments && storePayments.length ? storePayments : []
  const minRows = 12
  const recentData =
    basePayments.length >= minRows
      ? basePayments
      : [
          ...basePayments,
          ...Array.from({ length: minRows - basePayments.length }, (_, i) => {
            const today = new Date()
            const paidDate = new Date(today)
            paidDate.setDate(paidDate.getDate() - Math.floor(Math.random() * 30))
            return {
              id: `fallback_${i}`,
              member: `Member ${i + basePayments.length + 1}`,
              paidAt: paidDate.toISOString().slice(0, 10),
              amount: 75 + Math.round(Math.random() * 525),
              method: Math.random() < 0.3 ? "ach" : ("card" as const),
            }
          }),
        ]

  // Apply method filter if provided
  const methodFilteredData = methodFilter ? recentData.filter((item) => item.method === methodFilter) : recentData

  // Filter by search query
  const filteredData = methodFilteredData.filter((item) => {
    if (!searchQuery) return true
    return item.member.toLowerCase().includes(searchQuery.toLowerCase())
  })

  // Sort data
  const sortedData = [...filteredData].sort((a, b) => {
    if (sortBy === "date") {
      return new Date(b.paidAt).getTime() - new Date(a.paidAt).getTime()
    } else {
      return b.amount - a.amount
    }
  })

  const displayData = sortedData.slice(0, 12)

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr)
    const today = new Date()
    const diffDays = Math.ceil((today.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))

    if (diffDays === 0) return "Today"
    if (diffDays === 1) return "Yesterday"
    if (diffDays < 7) return `${diffDays} days ago`
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric" })
  }

  const getMethodIcon = (method: string) => {
    switch (method) {
      case "card":
        return <CreditCard className="w-3 h-3" />
      case "ach":
        return <Banknote className="w-3 h-3" />
      default:
        return <CreditCard className="w-3 h-3" />
    }
  }

  const getMethodColor = (method: string) => {
    switch (method) {
      case "card":
        return "bg-green-100 text-green-800"
      case "ach":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getMethodLabel = (method: string) => {
    switch (method) {
      case "card":
        return "Card"
      case "ach":
        return "ACH"
      default:
        return method.toUpperCase()
    }
  }

  // ---- Inline CSV export (no external helper needed) ----
  const esc = (val: string | number) => `"${String(val).replace(/"/g, '""')}"`
  const toCSV = (rows: Array<Record<string, string | number>>) => {
    const headers = Object.keys(rows[0] ?? { Name: "", Date: "", Amount: "", Method: "", Fee: "" })
    const lines = [headers.map(esc).join(","), ...rows.map((r) => headers.map((h) => esc(r[h] ?? "")).join(","))]
    return lines.join("\n")
  }

  const handleExportCSV = () => {
    // Build rows from the *filtered* dataset
    const rows = filteredData.map((item) => ({
      Name: item.member,
      Date: item.paidAt, // ISO yyyy-mm-dd (good for spreadsheets)
      Amount: item.amount.toFixed(2),
      Method: getMethodLabel(item.method),
      Fee: item.method === "card" ? (item.amount * 0.031).toFixed(2) : "0.00",
    }))

    // Always export headers, even if 0 rows
    const safeRows = rows.length ? rows : [{ Name: "", Date: "", Amount: "", Method: "", Fee: "" }]

    const csv = "\uFEFF" + toCSV(safeRows) // BOM for Excel
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)

    const ts = new Date().toISOString().slice(0, 10).replace(/-/g, "")
    const filename = `smartdues-recent-payments-${ts}.csv`

    const a = document.createElement("a")
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)

    toast.success("CSV exported successfully", { description: `${rows.length} payments exported` })
  }
  // -------------------------------------------------------

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-slate-900 mb-2">Recent Payments</h3>
          <p className="text-sm text-slate-600">Latest successful payments (last 30 days)</p>
        </div>
        <div className="flex gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                size="sm"
                variant="outline"
                className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 bg-transparent"
              >
                <Filter className="w-4 h-4 mr-2" />
                Sort: {sortBy === "date" ? "Date" : "Amount"}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setSortBy("date")}>Sort by Date</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setSortBy("amount")}>Sort by Amount</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button
            size="sm"
            variant="outline"
            onClick={handleExportCSV}
            className="focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-blue-600 bg-transparent"
          >
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      <div className="space-y-3">
        {displayData.map((item) => (
          <div
            key={item.id}
            className="flex items-center justify-between p-3 rounded-lg border border-slate-200 hover:bg-slate-50 transition-colors"
          >
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-emerald-50 rounded-full flex items-center justify-center">
                {getMethodIcon(item.method)}
              </div>
              <div>
                <div className="font-medium text-slate-900">{item.member}</div>
                <div className="text-xs text-slate-600">{formatDate(item.paidAt)}</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <div className="font-medium text-slate-900">${item.amount.toFixed(2)}</div>
                {item.method === "card" && (
                  <div className="text-xs text-slate-600">Fee: ${(item.amount * 0.031).toFixed(2)}</div>
                )}
              </div>
              <Badge className={`text-xs ${getMethodColor(item.method)}`}>
                <span className="flex items-center gap-1">
                  {getMethodIcon(item.method)}
                  {getMethodLabel(item.method)}
                </span>
              </Badge>
            </div>
          </div>
        ))}
      </div>

      {displayData.length === 0 && (
        <div className="text-center py-8 text-slate-600">
          {searchQuery || methodFilter ? "No recent payments match your filters" : "No recent payments"}
        </div>
      )}
    </div>
  )
}
