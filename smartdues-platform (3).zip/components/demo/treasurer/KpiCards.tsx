"use client"

import { useDemoStore } from "@/lib/demo/mockStore"
import { TrendingUp, TrendingDown, DollarSign, Clock, Users, AlertTriangle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface KpiCardsProps {
  onCardClick?: (cardType: string) => void
}

export function KpiCards({ onCardClick }: KpiCardsProps) {
  const { collections60d } = useDemoStore()

  // Keep goal aligned with your target chart
  const GOAL = 50400

  const totalCollected =
    collections60d && collections60d.length > 0
      ? Math.max(0, Math.round(collections60d[collections60d.length - 1].collected || 0))
      : 0

  const outstanding = Math.max(0, GOAL - totalCollected)
  const collectionRate = GOAL > 0 ? Math.min(99.9, (totalCollected / GOAL) * 100) : 0

  const kpis = {
    totalCollected,
    outstanding,
    collectionRate,
    avgDaysToPay: 21,
    activeMembers: 120,
    failedPayments: 3,
  }

  const cards = [
    {
      key: "collected",
      label: "Total Collected",
      value: `$${kpis.totalCollected.toLocaleString()}`,
      sublabel: `${((totalCollected / Math.max(GOAL, 1)) * 100).toFixed(1)}% of goal`,
      icon: TrendingUp,
      color: "emerald",
      seriesKey: "collected",
    },
    {
      key: "outstanding",
      label: "Outstanding",
      value: `$${kpis.outstanding.toLocaleString()}`,
      sublabel: "10 members",
      icon: TrendingDown,
      color: "red",
      seriesKey: "outstanding",
    },
    {
      key: "members",
      label: "Active Members",
      value: `${kpis.activeMembers}`,
      sublabel: "of 150 total",
      icon: Users,
      color: "sky",
      seriesKey: "members",
    },
    {
      key: "rate",
      label: "Collection Rate",
      value: `${kpis.collectionRate.toFixed(1)}%`,
      sublabel: "vs 85% target",
      icon: DollarSign,
      color: "emerald",
      seriesKey: "rate",
    },
    {
      key: "days",
      label: "Avg Days to Pay",
      value: `${kpis.avgDaysToPay}`,
      sublabel: "days after due",
      icon: Clock,
      color: "orange",
      seriesKey: "days",
    },
    {
      key: "failed",
      label: "Failed Payments (7d)",
      value: `${kpis.failedPayments}`,
      sublabel: "needs attention",
      icon: AlertTriangle,
      color: "red",
      seriesKey: "failed",
    },
  ] as const

  const colorMap: Record<string, { bg: string; value: string; icon: string }> = {
    emerald: { bg: "bg-emerald-100", value: "text-emerald-700", icon: "text-emerald-700" },
    red: { bg: "bg-red-100", value: "text-red-700", icon: "text-red-700" },
    sky: { bg: "bg-sky-100", value: "text-sky-700", icon: "text-sky-700" },
    orange: { bg: "bg-orange-100", value: "text-orange-700", icon: "text-orange-700" },
  }

  const calculateDelta = (type: string): { value: number; isPositive: boolean } => {
    const mockDeltas = {
      collected: 4.2,
      outstanding: -2.1,
      rate: 1.8,
      days: -0.5,
      members: 0.8,
      failed: -1.2,
    }
    const value = mockDeltas[type as keyof typeof mockDeltas] || 0
    return { value: Math.abs(value), isPositive: value > 0 }
  }

  const handleCardClick = (card: (typeof cards)[number]) => {
    onCardClick?.(card.key)
  }

  // LOCK desktop layout to 3 columns → always 2 rows × 3 cards
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3 gap-4">
      {cards.map((card, index) => {
        const Icon = card.icon
        const colors = colorMap[card.color]
        const delta = calculateDelta(card.key)

        return (
          <button
            key={index}
            onClick={() => handleCardClick(card)}
            className="rounded-2xl border border-slate-200 bg-white p-4 text-left shadow-sm transition focus-visible:outline-none"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <p className="text-xs text-slate-600">{card.label}</p>
                  <Badge
                    variant={delta.isPositive ? "default" : "secondary"}
                    className={`text-xs px-1.5 py-0.5 ${delta.isPositive ? "bg-emerald-100 text-emerald-700" : "bg-red-100 text-red-700"}`}
                  >
                    {delta.isPositive ? "+" : "-"}
                    {delta.value}%
                  </Badge>
                </div>
                <p className={`text-xl font-semibold ${colors.value} mb-1`}>{card.value}</p>
                <p className="text-xs text-slate-600">{card.sublabel}</p>
              </div>
              <div className={`w-8 h-8 ${colors.bg} rounded-lg flex items-center justify-center flex-shrink-0`}>
                <Icon className={`w-4 h-4 ${colors.icon}`} />
              </div>
            </div>
          </button>
        )
      })}
    </div>
  )
}
