"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { NewCycleForm } from "@/components/new-cycle-form"
import { toast } from "@/hooks/use-toast"
import { Loader2, Plus, Send } from "lucide-react"

interface DuesCycle {
  id: string
  name: string
  amount: number
  due_date: string
  late_fee_amount: number
  late_fee_days: number
  status: string
  created_at: string
}

interface DuesManagementProps {
  cycles: DuesCycle[]
  organizationId: string
  hasStripeConnect: boolean
}

export function DuesManagement({ cycles: initialCycles, organizationId, hasStripeConnect }: DuesManagementProps) {
  const [cycles, setCycles] = useState(initialCycles)
  const [showNewForm, setShowNewForm] = useState(false)
  const [generatingInvoices, setGeneratingInvoices] = useState<string | null>(null)

  const handleCycleCreated = (newCycle: DuesCycle) => {
    setCycles([newCycle, ...cycles])
    setShowNewForm(false)
    toast({
      title: "Dues cycle created",
      description: "New dues cycle has been created successfully.",
    })
  }

  const handleGenerateInvoices = async (cycleId: string) => {
    setGeneratingInvoices(cycleId)

    try {
      const response = await fetch("/api/dues/generate-invoices", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ cycleId }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate invoices")
      }

      const result = await response.json()

      toast({
        title: "Invoices generated",
        description: `Generated ${result.count} invoices for active members.`,
      })

      // Update cycle status
      setCycles(cycles.map((cycle) => (cycle.id === cycleId ? { ...cycle, status: "active" } : cycle)))
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate invoices. Please try again.",
        variant: "destructive",
      })
    } finally {
      setGeneratingInvoices(null)
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex justify-between items-center">
        <div>
          {!hasStripeConnect && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-4 mb-4">
              <p className="text-orange-800 text-sm">
                <strong>Note:</strong> Connect your Stripe account in settings to receive payments directly. Currently
                using platform account with higher fees.
              </p>
            </div>
          )}
        </div>

        <Button onClick={() => setShowNewForm(true)} className="bg-blue-600 hover:bg-blue-700 text-white">
          <Plus className="w-4 h-4 mr-2" />
          New Cycle
        </Button>
      </div>

      {/* New Cycle Form */}
      {showNewForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create New Dues Cycle</CardTitle>
          </CardHeader>
          <CardContent>
            <NewCycleForm
              organizationId={organizationId}
              onSuccess={handleCycleCreated}
              onCancel={() => setShowNewForm(false)}
            />
          </CardContent>
        </Card>
      )}

      {/* Cycles List */}
      <div className="space-y-4">
        {cycles.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-slate-500">No dues cycles created yet.</p>
              <Button onClick={() => setShowNewForm(true)} variant="outline" className="mt-4">
                Create your first cycle
              </Button>
            </CardContent>
          </Card>
        ) : (
          cycles.map((cycle) => (
            <Card key={cycle.id}>
              <CardContent className="p-6">
                <div className="flex justify-between items-start">
                  <div className="space-y-2">
                    <div className="flex items-center gap-3">
                      <h3 className="text-lg font-semibold text-slate-900">{cycle.name}</h3>
                      <Badge variant={cycle.status === "active" ? "default" : "secondary"}>{cycle.status}</Badge>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="text-slate-500">Amount:</span>
                        <p className="font-medium">{formatCurrency(cycle.amount)}</p>
                      </div>
                      <div>
                        <span className="text-slate-500">Due Date:</span>
                        <p className="font-medium">{formatDate(cycle.due_date)}</p>
                      </div>
                      <div>
                        <span className="text-slate-500">Late Fee:</span>
                        <p className="font-medium">
                          {formatCurrency(cycle.late_fee_amount)} after {cycle.late_fee_days} days
                        </p>
                      </div>
                      <div>
                        <span className="text-slate-500">Created:</span>
                        <p className="font-medium">{formatDate(cycle.created_at)}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    {cycle.status === "draft" && (
                      <Button
                        onClick={() => handleGenerateInvoices(cycle.id)}
                        disabled={generatingInvoices === cycle.id}
                        className="bg-orange-600 hover:bg-orange-700 text-white"
                      >
                        {generatingInvoices === cycle.id ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Send className="w-4 h-4 mr-2" />
                        )}
                        Generate Invoices
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
