"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Copy } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface Member {
  id: string
  first_name: string
  last_name: string
  email: string
  role: string
  paycode: string | null
  created_at: string
}

interface RosterTableProps {
  members: Member[]
  organizationId: string
}

export default function RosterTable({ members, organizationId }: RosterTableProps) {
  const { toast } = useToast()
  const [isGenerating, setIsGenerating] = useState<string | null>(null)

  const generatePayCode = async (memberId: string) => {
    setIsGenerating(memberId)
    try {
      const response = await fetch("/api/members/generate-paycode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ memberId }),
      })

      if (!response.ok) throw new Error("Failed to generate PayCode")

      const { paycode } = await response.json()

      // Update the member in the local state
      window.location.reload() // Simple refresh for now

      toast({
        title: "PayCode Generated",
        description: `New PayCode: ${paycode}`,
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PayCode",
        variant: "destructive",
      })
    } finally {
      setIsGenerating(null)
    }
  }

  const copyQuickPayLink = (paycode: string) => {
    const link = `${window.location.origin}/quick-pay?code=${paycode}`
    navigator.clipboard.writeText(link)
    toast({
      title: "Link Copied",
      description: "Quick Pay link copied to clipboard",
    })
  }

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "president":
        return "bg-purple-100 text-purple-800"
      case "treasurer":
        return "bg-blue-100 text-blue-800"
      case "exec":
        return "bg-green-100 text-green-800"
      case "member":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Member</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                PayCode
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {members.map((member) => (
              <tr key={member.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">
                    {member.first_name} {member.last_name}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-600">{member.email}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <Badge className={getRoleBadgeColor(member.role)}>{member.role}</Badge>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {member.paycode ? (
                    <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono">{member.paycode}</code>
                  ) : (
                    <span className="text-gray-400 text-sm">No PayCode</span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  {member.paycode ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => copyQuickPayLink(member.paycode!)}
                      className="text-blue-600 hover:text-blue-700"
                    >
                      <Copy className="w-3 h-3 mr-1" />
                      Copy Link
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => generatePayCode(member.id)}
                      disabled={isGenerating === member.id}
                      className="text-orange-600 hover:text-orange-700"
                    >
                      {isGenerating === member.id ? "Generating..." : "Generate PayCode"}
                    </Button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {members.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500">No members found. Import a CSV to get started.</p>
        </div>
      )}
    </div>
  )
}
