"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Separator } from "@/components/ui/separator"
import { Calendar, DollarSign, AlertTriangle, CheckCircle } from "lucide-react"
import { QuickPayButton } from "@/components/quick-pay-button"
import { calculateTotalWithFees, type PayMethod } from "@/lib/fees"

interface QuickPayResultsProps {
  memberDues: Array<{
    id: string
    amount_owed: number
    amount_paid: number
    status: string
    dues_cycle: {
      id: string
      name: string
      due_date: string
      late_fee_amount?: number
    }
  }>
  user: {
    id: string
    first_name: string
    last_name: string
    organization: {
      name: string
    }
  }
  payerEmail: string
}

export function QuickPayResults({ memberDues, user, payerEmail }: QuickPayResultsProps) {
  const [selectedMethod, setSelectedMethod] = useState<PayMethod>("card")

  if (memberDues.length === 0) {
    return (
      <Alert className="border-green-200 bg-green-50">
        <CheckCircle className="h-4 w-4 text-green-600" />
        <AlertDescription className="text-green-800">Great news! No outstanding dues.</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="space-y-6">
      {/* Member Info */}
      <div className="text-center pb-4">
        <h3 className="text-xl font-semibold text-gray-900">
          {user.first_name} {user.last_name}
        </h3>
        <p className="text-gray-600">{user.organization.name}</p>
      </div>

      {/* Outstanding Dues */}
      <div className="space-y-4">
        {memberDues.map((dues) => {
          const subtotal = dues.amount_owed - dues.amount_paid
          const isOverdue = new Date(dues.dues_cycle.due_date) < new Date() && dues.status !== "paid"

          // Calculate fees for both methods using the helper
          const cardCalculation = calculateTotalWithFees(subtotal, "card")
          const achCalculation = calculateTotalWithFees(subtotal, "ach")

          return (
            <Card key={dues.id} className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">{dues.dues_cycle.name}</CardTitle>
                  <Badge variant={isOverdue ? "destructive" : "secondary"}>{isOverdue ? "Overdue" : dues.status}</Badge>
                </div>
                <CardDescription className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Due: {new Date(dues.dues_cycle.due_date).toLocaleDateString()}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Method Selection */}
                <div className="flex gap-2 mb-4">
                  <Button
                    variant={selectedMethod === "card" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedMethod("card")}
                    className="flex-1"
                  >
                    Card
                  </Button>
                  <Button
                    variant={selectedMethod === "ach" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedMethod("ach")}
                    className="flex-1"
                  >
                    Bank (ACH)
                  </Button>
                </div>

                {/* Amount Breakdown */}
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Dues Subtotal:</span>
                      <span>${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>Processing Fee:</span>
                      <span>
                        {selectedMethod === "card" ? `$${cardCalculation.processingFee.toFixed(2)}` : "$0.00"}
                      </span>
                    </div>
                    <Separator />
                    <div className="flex justify-between font-semibold">
                      <span>Total:</span>
                      <span>
                        $
                        {selectedMethod === "card" ? cardCalculation.total.toFixed(2) : achCalculation.total.toFixed(2)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Payment Button */}
                <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
                  <QuickPayButton
                    memberDuesId={dues.id}
                    amount={selectedMethod === "card" ? cardCalculation.total : achCalculation.total}
                    payerEmail={payerEmail}
                    memberName={`${user.first_name} ${user.last_name}`}
                    organizationName={user.organization.name}
                    duesName={dues.dues_cycle.name}
                    method={selectedMethod}
                    buttonText={
                      selectedMethod === "card"
                        ? `Pay by Card — $${cardCalculation.total.toFixed(2)}`
                        : `Pay by Bank (ACH) — $${achCalculation.total.toFixed(2)}`
                    }
                  />
                </div>

                {/* Late Fee Warning */}
                {isOverdue && dues.dues_cycle.late_fee_amount && dues.dues_cycle.late_fee_amount > 0 && (
                  <Alert variant="destructive" className="mt-3">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription className="text-sm">
                      This payment is overdue. A late fee of ${dues.dues_cycle.late_fee_amount.toFixed(2)} may apply.
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Fee Disclosure */}
      <Alert className="bg-blue-50 border-blue-200">
        <DollarSign className="h-4 w-4" />
        <AlertDescription className="text-sm">
          Credit Card: 3.1% processing surcharge. ACH/Bank Transfer: No processing surcharge.
        </AlertDescription>
      </Alert>

      {/* Back to Form */}
      <div className="text-center pt-4">
        <Button variant="outline" asChild>
          <a href="/quick-pay">← Make Another Payment</a>
        </Button>
      </div>
    </div>
  )
}
