"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Loader2, CreditCard, Building2 } from "lucide-react"

interface QuickPayButtonProps {
  memberDuesId: string
  amount: number
  payerEmail: string
  memberName: string
  organizationName: string
  duesName: string
  method: "card" | "ach"
  buttonText: string
}

export function QuickPayButton({
  memberDuesId,
  amount,
  payerEmail,
  memberName,
  organizationName,
  duesName,
  method,
  buttonText,
}: QuickPayButtonProps) {
  const [isLoading, setIsLoading] = useState(false)

  const handlePayment = async () => {
    setIsLoading(true)

    try {
      // Call API to create Stripe Checkout session
      const response = await fetch("/api/quick-pay/checkout", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          memberDuesId,
          amount,
          payerEmail,
          memberName,
          organizationName,
          duesName,
          method,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Failed to create payment session")
      }

      // Redirect to Stripe Checkout
      window.location.href = data.url
    } catch (error) {
      console.error("Payment error:", error)
      alert("Failed to start payment process. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const Icon = method === "card" ? CreditCard : Building2

  return (
    <Button
      onClick={handlePayment}
      disabled={isLoading}
      className="w-full h-12 text-lg font-semibold"
      variant={method === "card" ? "default" : "outline"}
    >
      {isLoading ? (
        <>
          <Loader2 className="mr-2 h-5 w-5 animate-spin" />
          Starting payment...
        </>
      ) : (
        <>
          <Icon className="mr-2 h-5 w-5" />
          {buttonText} ${amount.toFixed(2)}
        </>
      )}
    </Button>
  )
}
