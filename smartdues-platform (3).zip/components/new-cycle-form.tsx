"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2 } from "lucide-react"

interface NewCycleFormProps {
  organizationId: string
  onSuccess: (cycle: any) => void
  onCancel: () => void
}

export function NewCycleForm({ organizationId, onSuccess, onCancel }: NewCycleFormProps) {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    due_date: "",
    default_amount: "",
    late_fee_amount: "",
    grace_days: "7",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const response = await fetch("/api/dues/cycles", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          organization_id: organizationId,
          default_amount: Number.parseFloat(formData.default_amount),
          late_fee_amount: Number.parseFloat(formData.late_fee_amount),
          late_fee_days: Number.parseInt(formData.grace_days),
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to create cycle")
      }

      const cycle = await response.json()
      onSuccess(cycle)
    } catch (error) {
      console.error("Error creating cycle:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Cycle Name</Label>
          <Input
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="e.g., Fall 2024 Dues"
            required
          />
        </div>

        <div>
          <Label htmlFor="due_date">Due Date</Label>
          <Input id="due_date" name="due_date" type="date" value={formData.due_date} onChange={handleChange} required />
        </div>

        <div>
          <Label htmlFor="default_amount">Default Amount ($)</Label>
          <Input
            id="default_amount"
            name="default_amount"
            type="number"
            step="0.01"
            min="0"
            value={formData.default_amount}
            onChange={handleChange}
            placeholder="150.00"
            required
          />
        </div>

        <div>
          <Label htmlFor="late_fee_amount">Late Fee Amount ($)</Label>
          <Input
            id="late_fee_amount"
            name="late_fee_amount"
            type="number"
            step="0.01"
            min="0"
            value={formData.late_fee_amount}
            onChange={handleChange}
            placeholder="25.00"
            required
          />
        </div>

        <div>
          <Label htmlFor="grace_days">Grace Period (days)</Label>
          <Input
            id="grace_days"
            name="grace_days"
            type="number"
            min="0"
            value={formData.grace_days}
            onChange={handleChange}
            required
          />
        </div>
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="submit" disabled={loading} className="bg-blue-600 hover:bg-blue-700 text-white">
          {loading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
          Create Cycle
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
      </div>
    </form>
  )
}
