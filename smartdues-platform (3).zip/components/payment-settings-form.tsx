"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/hooks/use-toast"

interface PaymentSettings {
  cardFeePercent: number
  achFeePercent: number
  achFeeCap: number
}

interface PaymentSettingsFormProps {
  organizationId: string
  initialSettings: PaymentSettings
}

export function PaymentSettingsForm({ organizationId, initialSettings }: PaymentSettingsFormProps) {
  const [settings, setSettings] = useState<PaymentSettings>(initialSettings)
  const [isLoading, setIsLoading] = useState(false)
  const { toast } = useToast()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      const response = await fetch("/api/settings/payments", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          organizationId,
          cardFeePercent: settings.cardFeePercent / 100, // Convert to decimal
          achFeePercent: settings.achFeePercent / 100,
          achFeeCap: Math.round(settings.achFeeCap * 100), // Convert to cents
        }),
      })

      if (!response.ok) {
        throw new Error("Failed to update settings")
      }

      toast({
        title: "Settings Updated",
        description: "Payment settings have been successfully updated.",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update payment settings. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Processing Fees</CardTitle>
          <CardDescription>
            Configure the processing fees charged to members for different payment methods
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="cardFee">Card Fee Percentage</Label>
              <div className="relative">
                <Input
                  id="cardFee"
                  type="number"
                  step="0.1"
                  min="0"
                  max="10"
                  value={settings.cardFeePercent}
                  onChange={(e) =>
                    setSettings((prev) => ({
                      ...prev,
                      cardFeePercent: Number.parseFloat(e.target.value) || 0,
                    }))
                  }
                  className="pr-8"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500">%</span>
              </div>
              <p className="text-sm text-slate-600">Default: 3.1% for credit/debit cards</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="achFee">ACH Fee Percentage</Label>
              <div className="relative">
                <Input
                  id="achFee"
                  type="number"
                  step="0.1"
                  min="0"
                  max="5"
                  value={settings.achFeePercent}
                  onChange={(e) =>
                    setSettings((prev) => ({
                      ...prev,
                      achFeePercent: Number.parseFloat(e.target.value) || 0,
                    }))
                  }
                  className="pr-8"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500">%</span>
              </div>
              <p className="text-sm text-slate-600">Default: 1.0% for bank transfers</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="achCap">ACH Fee Cap</Label>
            <div className="relative max-w-xs">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500">$</span>
              <Input
                id="achCap"
                type="number"
                step="0.50"
                min="0"
                max="50"
                value={settings.achFeeCap}
                onChange={(e) =>
                  setSettings((prev) => ({
                    ...prev,
                    achFeeCap: Number.parseFloat(e.target.value) || 0,
                  }))
                }
                className="pl-8"
              />
            </div>
            <p className="text-sm text-slate-600">Maximum fee for ACH payments (default: $5.00)</p>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-200">
            <p className="text-sm text-slate-600">
              <strong>Available payment methods:</strong> Credit/debit cards and ACH bank transfers
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button type="submit" disabled={isLoading} className="bg-blue-600 hover:bg-blue-700 text-white">
          {isLoading ? "Saving..." : "Save Settings"}
        </Button>
      </div>
    </form>
  )
}
