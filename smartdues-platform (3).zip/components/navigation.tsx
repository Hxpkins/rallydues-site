"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"

export function Navigation() {
  const pathname = usePathname()

  const isActive = (path: string) => pathname === path

  return (
    <nav className="hidden md:flex items-center space-x-8">
      <Link
        href="/"
        className={`text-sm transition-colors ${
          isActive("/") ? "text-[var(--primary)] font-medium" : "text-[var(--subtext)] hover:text-[var(--text)]"
        }`}
      >
        Home
      </Link>
      <Link
        href="/pricing"
        className={`text-sm transition-colors ${
          isActive("/pricing") ? "text-[var(--primary)] font-medium" : "text-[var(--subtext)] hover:text-[var(--text)]"
        }`}
      >
        Pricing
      </Link>
      <Link
        href="/demo"
        className={`text-sm transition-colors ${
          isActive("/demo") ? "text-[var(--primary)] font-medium" : "text-[var(--subtext)] hover:text-[var(--text)]"
        }`}
      >
        Demo
      </Link>
      <Link
        href="/contact"
        className={`text-sm transition-colors ${
          isActive("/contact") ? "text-[var(--primary)] font-medium" : "text-[var(--subtext)] hover:text-[var(--text)]"
        }`}
      >
        Contact
      </Link>
    </nav>
  )
}
