"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Loader2, CreditCard } from "lucide-react"

export function QuickPayForm() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    paycode: "",
    lastname: "",
    email: "",
  })
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)

    try {
      // Validate form data
      if (!formData.paycode || !formData.lastname || !formData.email) {
        throw new Error("All fields are required")
      }

      if (formData.paycode.length !== 4) {
        throw new Error("PayCode must be exactly 4 characters")
      }

      if (!formData.email.includes("@")) {
        throw new Error("Please enter a valid email address")
      }

      // Navigate to results page with search params
      const params = new URLSearchParams({
        paycode: formData.paycode.toUpperCase(),
        lastname: formData.lastname.trim(),
        email: formData.email.trim(),
      })

      router.push(`/quick-pay?${params.toString()}`)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  const handleInputChange = (field: keyof typeof formData) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData((prev) => ({
      ...prev,
      [field]: e.target.value,
    }))
    // Clear error when user starts typing
    if (error) setError("")
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <div className="space-y-4">
        <div>
          <Label htmlFor="paycode" className="text-base font-medium">
            PayCode
          </Label>
          <Input
            id="paycode"
            type="text"
            placeholder="Enter your organization's custom PayCode"
            value={formData.paycode}
            onChange={handleInputChange("paycode")}
            maxLength={4}
            className="mt-1 text-lg h-12"
            disabled={isLoading}
          />
          <p className="text-sm text-gray-500 mt-1">Ask your Treasurer to provide this to you</p>
        </div>

        <div>
          <Label htmlFor="lastname" className="text-base font-medium">
            Last Name
          </Label>
          <Input
            id="lastname"
            type="text"
            placeholder="Enter your last name"
            value={formData.lastname}
            onChange={handleInputChange("lastname")}
            className="mt-1 text-lg h-12"
            disabled={isLoading}
          />
          <p className="text-sm text-gray-500 mt-1">Use the name registered with your organization</p>
        </div>

        <div>
          <Label htmlFor="email" className="text-base font-medium">
            Email Address
          </Label>
          <Input
            id="email"
            type="email"
            placeholder="Enter your email address"
            value={formData.email}
            onChange={handleInputChange("email")}
            className="mt-1 text-lg h-12"
            disabled={isLoading}
          />
          <p className="text-sm text-gray-500 mt-1">We'll send your payment confirmation here</p>
        </div>
      </div>

      <div className="border rounded-lg p-4 bg-slate-50 border-transparent">
        <Button
          type="submit"
          className="w-full inline-flex items-center rounded-lg bg-gray-900 text-white px-4 py-2.5 shadow-sm hover:bg-gray-800 h-12 text-lg font-semibold"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Looking up your dues...
            </>
          ) : (
            <>
              <CreditCard className="mr-2 h-5 w-5" />
              View My Dues
            </>
          )}
        </Button>
      </div>
    </form>
  )
}
