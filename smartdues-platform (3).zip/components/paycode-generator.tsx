"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Plus, RefreshCw, Copy, Check } from "lucide-react"

export function PayCodeGenerator() {
  const [isOpen, setIsOpen] = useState(false)
  const [generatedCode, setGeneratedCode] = useState("")
  const [copied, setCopied] = useState(false)

  const generatePayCode = () => {
    // Generate a random 4-character code
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    let result = ""
    for (let i = 0; i < 4; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setGeneratedCode(result)
    setCopied(false)
  }

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(generatedCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Generate PayCode
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Generate PayCode</DialogTitle>
          <DialogDescription>Create a unique 4-character PayCode for Quick Pay access.</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="member-select">Select Member</Label>
            <Input id="member-select" placeholder="Search and select member..." className="mt-1" />
          </div>

          <div className="text-center space-y-4">
            {generatedCode ? (
              <div className="space-y-3">
                <div>
                  <p className="text-sm text-muted-foreground mb-2">Generated PayCode:</p>
                  <Badge variant="secondary" className="text-2xl font-mono px-4 py-2">
                    {generatedCode}
                  </Badge>
                </div>
                <div className="flex space-x-2">
                  <Button variant="outline" onClick={copyToClipboard} className="flex-1 bg-transparent">
                    {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                    {copied ? "Copied!" : "Copy Code"}
                  </Button>
                  <Button variant="outline" onClick={generatePayCode}>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Regenerate
                  </Button>
                </div>
              </div>
            ) : (
              <Button onClick={generatePayCode} className="w-full">
                <Plus className="w-4 h-4 mr-2" />
                Generate PayCode
              </Button>
            )}
          </div>

          {generatedCode && (
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => setIsOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={() => setIsOpen(false)} className="flex-1">
                Assign PayCode
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
