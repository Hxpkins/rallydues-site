"use client"

import { useActionState } from "react"
import { useFormStatus } from "react-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, AlertCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { signUp } from "@/lib/auth-actions"
import { isSupabaseConfigured } from "@/lib/supabase/client"

function SubmitButton() {
  const { pending } = useFormStatus()

  return (
    <Button
      type="submit"
      disabled={pending || !isSupabaseConfigured}
      className="w-full bg-[var(--accent)] hover:brightness-110 text-white rounded-lg px-4 py-2.5 bg-blue-600"
    >
      {pending ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Creating account...
        </>
      ) : (
        "Start Free Trial"
      )}
    </Button>
  )
}

export function SignUpForm() {
  const router = useRouter()
  const [state, formAction] = useActionState(signUp, null)

  // Handle successful signup by redirecting
  useEffect(() => {
    if (state?.success && state?.redirect) {
      router.push("/app/home")
    }
  }, [state, router])

  return (
    <div className="space-y-6">
      {!isSupabaseConfigured && (
        <div className="bg-orange-50 border border-orange-200 text-orange-800 px-4 py-3 rounded-lg flex items-start space-x-2">
          <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium">Authentication not configured</p>
            <p className="text-sm">Supabase environment variables are missing. Please contact support.</p>
          </div>
        </div>
      )}

      <form action={formAction} className="space-y-4">
        {state?.error && (
          <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">{state.error}</div>
        )}

        {state?.success && !state?.redirect && (
          <div className="bg-green-50 border border-green-200 text-green-800 px-4 py-3 rounded-lg">{state.success}</div>
        )}

        <div className="space-y-2">
          <Label htmlFor="organizationName" className="text-[var(--text)]">
            Organization Name
          </Label>
          <Input
            id="organizationName"
            name="organizationName"
            type="text"
            placeholder="Alpha Beta Gamma"
            required
            className="bg-white border-[var(--border)] text-[var(--text)] placeholder:text-[var(--subtext)]"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="university" className="text-[var(--text)]">
            University <span className="text-[var(--subtext)] font-normal">(optional)</span>
          </Label>
          <Input
            id="university"
            name="university"
            type="text"
            placeholder="Arizona State University"
            className="bg-white border-[var(--border)] text-[var(--text)] placeholder:text-[var(--subtext)]"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email" className="text-[var(--text)]">
            Your Email Address
          </Label>
          <Input
            id="email"
            name="email"
            type="email"
            placeholder="treasurer@example.com"
            required
            className="bg-white border-[var(--border)] text-[var(--text)] placeholder:text-[var(--subtext)]"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password" className="text-[var(--text)]">
            Password
          </Label>
          <Input
            id="password"
            name="password"
            type="password"
            required
            className="bg-white border-[var(--border)] text-[var(--text)]"
          />
        </div>

        <SubmitButton />

        <p className="text-xs text-[var(--subtext)] text-center">
          By creating an account, you agree to our Terms of Service and Privacy Policy.
        </p>
      </form>
    </div>
  )
}
