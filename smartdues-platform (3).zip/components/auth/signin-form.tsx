"use client"

import { useActionState } from "react"
import { useFormStatus } from "react-dom"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Loader2, AlertCircle } from "lucide-react"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { signIn } from "@/lib/auth-actions"
import { isSupabaseConfigured } from "@/lib/supabase/client"

function SubmitButton() {
  const { pending } = useFormStatus()

  return (
    <Button
      type="submit"
      disabled={pending || !isSupabaseConfigured}
      className="w-full bg-[var(--accent)] hover:brightness-110 text-white rounded-lg px-4 py-2.5 bg-blue-600"
    >
      {pending ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Signing in...
        </>
      ) : (
        "Sign In"
      )}
    </Button>
  )
}

export function SignInForm() {
  const router = useRouter()
  const [state, formAction] = useActionState(signIn, null)

  // Handle successful login by redirecting
  useEffect(() => {
    if (state?.success) {
      router.push("/app/home")
    }
  }, [state, router])

  return (
    <div className="space-y-6">
      {!isSupabaseConfigured && (
        <div className="bg-orange-50 border border-orange-200 text-orange-800 px-4 py-3 rounded-lg flex items-start space-x-2">
          <AlertCircle className="w-5 h-5 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium">Authentication not configured</p>
            <p className="text-sm">Supabase environment variables are missing. Please contact support.</p>
          </div>
        </div>
      )}

      <form action={formAction} className="space-y-4">
        {state?.error && (
          <div className="bg-red-50 border border-red-200 text-red-800 px-4 py-3 rounded-lg">{state.error}</div>
        )}

        <div className="space-y-2">
          <Label htmlFor="email" className="text-[var(--text)]">
            Email address
          </Label>
          <Input
            id="email"
            name="email"
            type="email"
            placeholder="you@example.com"
            required
            className="bg-white border-[var(--border)] text-[var(--text)] placeholder:text-[var(--subtext)]"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="password" className="text-[var(--text)]">
            Password
          </Label>
          <Input
            id="password"
            name="password"
            type="password"
            required
            className="bg-white border-[var(--border)] text-[var(--text)]"
          />
        </div>

        <SubmitButton />
      </form>
    </div>
  )
}
